#Requires -Version 5.1
<#
.SYNOPSIS
    Collects read-only Exchange Online evidence for hybrid mailbox moves (endpoint tests, batches, move reports,
    failures by layer, Exchange Online IP ranges) and writes an HTML + CSV report.

.DESCRIPTION
    Run on the admin workstation (PowerShell 7) with Exchange Online access. It answers, from Microsoft's side:

      1. Endpoint         Every ExchangeRemoteMove migration endpoint (RemoteServer, saved user name, concurrency).
      2. Endpoint tests   Test-MigrationServerAvailability -Endpoint <name>  -> uses the credentials SAVED in the endpoint.
                          With -TestTypedCredential it also tests with a credential you type. Saved = fail and
                          typed = pass proves the saved password is wrong or old.
      3. Batches / users  Batch and migration-user status, Data Consistency Score, skipped items awaiting approval.
      4. Move reports     Get-MoveRequestStatistics -IncludeReport per user: failures, report entries, full XML for
                          Microsoft Support (optionally with -DiagnosticInfo).
      5. Failure layers   Each failure message classified as Network/firewall, TLS/certificate, Authentication,
                          MRSProxy, IIS, capacity, data - with what to check next and the Microsoft article.
      6. IP ranges        Current Exchange Online IP ranges from the Microsoft 365 IP Address and URL web service, for
                          the firewall allow list (and for Get-HybridMoveOnPremEvidence.ps1 -ExoIpListPath).

    Read-only: changes nothing in Exchange Online. The endpoint tests only open a test connection.
    Cannot see: the on-premises servers, IIS, the firewall or the domain controllers (use the other two scripts).

    Sources (read 2026-10-16):
      https://learn.microsoft.com/powershell/module/exchangepowershell/test-migrationserveravailability  (Example 4: -Endpoint uses stored settings)
      https://learn.microsoft.com/exchange/hybrid-deployment-prerequisites
      https://learn.microsoft.com/microsoft-365/enterprise/additional-office365-ip-addresses-and-urls  (row 6: mailbox migration inbound)
      https://learn.microsoft.com/microsoft-365/enterprise/microsoft-365-ip-web-service
      https://learn.microsoft.com/exchange/mailbox-migration/track-prevent-data-loss-dcs

.PARAMETER EmailAddress
    One or more users to analyse. If omitted, uses -BatchName, otherwise all migration users not Completed (up to -MaxUsers).

.PARAMETER BatchName
    One or more migration batches whose users are analysed.

.PARAMETER MaxUsers
    Upper limit of users analysed when neither -EmailAddress nor -BatchName is given. Default 50.

.PARAMETER TestTypedCredential
    Also runs Test-MigrationServerAvailability with a credential you type (DOMAIN\user), against each endpoint's RemoteServer.

.PARAMETER IncludeVerboseDiagnostics
    Adds -DiagnosticInfo 'showtimeslots, showtimeline, verbose' to the move report export (bigger XML, for Microsoft Support).

.PARAMETER SkipIpList
    Does not download the Exchange Online IP ranges.

.PARAMETER EvidencePath
    Case evidence folder. When given, results go to <EvidencePath>\Cloud\Get-HybridMoveCloudEvidence\... (the layout
    Get-HybridMoveVerdict.ps1 -EvidencePath reads) and -OutputPath is ignored. Run on the admin workstation.

.PARAMETER OutputPath
    Root output folder. Default C:\Scripts\Cannes. Results go to <OutputPath>\Get-HybridMoveCloudEvidence\<timestamp>\.

.EXAMPLE
    .\Get-HybridMoveCloudEvidence.ps1 -EmailAddress user@contoso.com
    Endpoint tests with the saved credentials, the user's move report and failures by layer, and the IP ranges.

.EXAMPLE
    .\Get-HybridMoveCloudEvidence.ps1 -EmailAddress user@contoso.com -TestTypedCredential -IncludeVerboseDiagnostics
    Adds a test with a typed credential and a verbose move report for Microsoft Support.

.OUTPUTS
    Report-<ts>.html, Checks-<ts>.csv, one CSV per data set, MoveReport-UserNN-<ts>.xml, ExoIpRanges-<ts>.csv; log in ...\Logs\.
    Exit codes: 0 all collection steps ran, 1 one or more steps failed (see NotAssessed rows), 2 could not run.

.NOTES
    Owner: Carlos Annes (TakeItToCloud)
    Version: 1.0.4
    Created: 2026-10-16
    Last updated: 2026-10-19
    Requires: Windows PowerShell 5.1 or PowerShell 7 (5.1 supported so it runs where PowerShell 7 is not installed), ExchangeOnlineManagement 3.0.0+, Exchange Online role that can read migrations and move
              requests (e.g. Exchange Administrator, or a role group with Move Mailboxes / View-Only Recipients),
              outbound HTTPS to endpoints.office.com for the IP list.
#>
[CmdletBinding()]
param(
    [ValidatePattern('^[^@\s]+@[^@\s]+\.[^@\s]+$')][string[]]$EmailAddress,
    [string[]]$BatchName,
    [ValidateRange(1, 1000)][int]$MaxUsers = 50,
    [switch]$TestTypedCredential,
    [switch]$IncludeVerboseDiagnostics,
    [switch]$SkipIpList,
    [string]$EvidencePath,
    [string]$OutputPath = 'C:\Scripts\Cannes'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# Windows PowerShell 5.1 may not offer TLS 1.2 by default; the PowerShell Gallery and endpoints.office.com require it.
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

# -EvidencePath sends the results to <EvidencePath>\Cloud (case evidence layout read by Get-HybridMoveVerdict.ps1).
$OutputPathNote = ''
if ($EvidencePath) {
    if ($PSBoundParameters.ContainsKey('OutputPath')) { $OutputPathNote = "-EvidencePath given: -OutputPath '$OutputPath' ignored." }
    $OutputPath = Join-Path $EvidencePath 'Cloud'
}
# ---- Configuration --------------------------------------------------------------------------------
$ScriptName    = 'Get-HybridMoveCloudEvidence'
$ScriptVersion = '1.0.4'
$Stamp         = Get-Date -Format 'yyyyMMdd-HHmmss'
$RunDir        = Join-Path (Join-Path $OutputPath $ScriptName) $Stamp
$LogDir        = Join-Path (Join-Path $OutputPath $ScriptName) 'Logs'
$LogFile       = Join-Path $LogDir "$ScriptName-$Stamp.log"
$StartRun      = Get-Date
$ExitCode      = 0
$Script:Checks = [System.Collections.Generic.List[object]]::new()
$Script:Data   = [ordered]@{}
$Script:StepOk = 0; $Script:StepFailed = 0

# https://learn.microsoft.com/powershell/exchange/exchange-online-powershell-v2 (read 2026-10-16)
$RequiredModules = @( @{ Name = 'ExchangeOnlineManagement'; MinimumVersion = [version]'3.0.0' } )

# Microsoft 365 IP Address and URL web service (read 2026-10-16).
$IpServiceUri = 'https://endpoints.office.com/endpoints/Worldwide?ServiceAreas=Exchange&ClientRequestId={0}'

# Failure message -> layer. First match wins. Volatile knowledge kept in one table.
$FailurePatterns = @(
    @{ Layer = 'TLS / certificate'; Pattern = 'trust relationship|remote certificate|SSL/TLS secure channel|certificate'
       Meaning = 'Exchange Online does not trust the certificate presented for the MRSProxy name.'
       Next = 'On-prem report: "Certificate IIS serves" and "TLS probe". If a firewall terminates TLS, check the certificate it presents.'
       Ref = 'https://learn.microsoft.com/exchange/certificate-requirements' }
    @{ Layer = 'Authentication'; Pattern = 'unauthorized with client authentication scheme|\(401\)|401 Unauthorized|Access is denied'
       Meaning = 'Connection and TLS work; the sign-in to /EWS/mrsproxy.svc is rejected.'
       Next = 'Endpoint test with saved credentials (this report); DC report 4776 status; on-prem IIS 401.1 and Security 4625; Extended Protection vs a TLS-terminating firewall.'
       Ref = 'https://learn.microsoft.com/troubleshoot/exchange/move-or-migrate-mailboxes/troubleshoot-migration-issues-in-exchange-hybrid' }
    @{ Layer = 'MRSProxy'; Pattern = 'forbidden|\(403\)|MRS proxy service is disabled'
       Meaning = 'MRSProxy is disabled (or blocked) on the server that received the call.'
       Next = 'On-prem report: MRSProxyEnabled on every published server; ASP.NET 1309 events.'
       Ref = 'https://learn.microsoft.com/troubleshoot/exchange/move-mailboxes/remote-server-returned-error-403-forbidden' }
    @{ Layer = 'IIS'; Pattern = '\(405\)|Exception has been thrown by the target'
       Meaning = 'IIS cannot run the service (svc-Integrated handler missing).'
       Next = 'On-prem report: "svc-Integrated handler mapping on EWS".'
       Ref = 'https://learn.microsoft.com/troubleshoot/exchange/move-mailboxes/hybrid-deployment-errors' }
    @{ Layer = 'MRSProxy capacity'; Pattern = 'maximum number of active MRS connections'
       Meaning = 'Too many concurrent MRSProxy connections on the on-prem server.'
       Next = 'Lower endpoint concurrency or raise the MRSProxy connection limit (see article).'
       Ref = 'https://learn.microsoft.com/troubleshoot/exchange/move-mailboxes/mailbox-migration-reached-maximum-number' }
    @{ Layer = 'Network / firewall'; Pattern = 'timed out|timeout|unable to connect|could not be completed|no such host|actively refused|underlying connection was closed|connection was forcibly closed|name could not be resolved'
       Meaning = 'Exchange Online cannot reach, or keep, a connection to the published endpoint.'
       Next = 'Firewall allow list (ExoIpRanges CSV), NAT target, IDS/flood protection, idle timeout; on-prem IIS log shows whether calls arrive.'
       Ref = 'https://learn.microsoft.com/exchange/hybrid-deployment-prerequisites' }
    @{ Layer = 'Job gave up'; Pattern = 'TooManyTransientFailureRetries'
       Meaning = 'The job stopped after too many transient errors; the cause is the most common failure listed with it.'
       Next = 'Fix that underlying failure, then retry the batch (Start-MigrationBatch).'
       Ref = 'https://learn.microsoft.com/powershell/module/exchangepowershell/complete-migrationbatch' }
    @{ Layer = 'Data'; Pattern = 'skipped item|DataConsistency|corrupt|large item'
       Meaning = 'Item-level data issue; may need skipped-item approval.'
       Next = 'Review SkippedItems CSV, then Set-MigrationUser -ApproveSkippedItems if acceptable.'
       Ref = 'https://learn.microsoft.com/exchange/mailbox-migration/track-prevent-data-loss-dcs' }
)

# ---- Helpers --------------------------------------------------------------------------------------
function Write-Log {
    <# .SYNOPSIS Writes one timestamped line to the log file and the console. #>
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidOverwritingBuiltInCmdlets', '', Justification = 'House rule names the helper Write-Log.')]
    param([ValidateSet('INFO', 'WARN', 'ERROR', 'DEBUG')][string]$Level = 'INFO', [Parameter(Mandatory)][string]$Message)
    $line = '{0} [{1}] {2}' -f (Get-Date -Format 'o'), $Level, $Message
    Add-Content -Path $LogFile -Value $line -Encoding utf8
    Write-Information -MessageData $line -InformationAction Continue
}

function Write-ErrorDetail {
    <# .SYNOPSIS Logs a caught error with step, item, message, type, position and stack. #>
    param([Parameter(Mandatory)]$ErrorRecord, [Parameter(Mandatory)][string]$Step, [string]$Item = '')
    Write-Log ERROR "Step: $Step | Item: $Item"
    Write-Log ERROR "Message: $($ErrorRecord.Exception.Message)"
    Write-Log ERROR "Type: $($ErrorRecord.Exception.GetType().FullName)"
    Write-Log ERROR "Position: $($ErrorRecord.InvocationInfo.PositionMessage)"
    Write-Log ERROR "Stack: $($ErrorRecord.ScriptStackTrace)"
}

function Add-Check {
    <# .SYNOPSIS Adds one finding row: Pass | Warn | Fail | Info | NotAssessed. #>
    param([string]$Area, [string]$Check, [ValidateSet('Pass', 'Warn', 'Fail', 'Info', 'NotAssessed')][string]$Status, [string]$Detail, [string]$Reference = '')
    $Script:Checks.Add([pscustomobject]@{ Area = $Area; Check = $Check; Status = $Status; Detail = $Detail; Reference = $Reference })
}

function Add-Data {
    <# .SYNOPSIS Stores a data set for the HTML report and exports it to CSV. #>
    param([Parameter(Mandatory)][string]$Name, [AllowNull()]$Rows)
    $list = @($Rows | Where-Object { $null -ne $_ })
    $Script:Data[$Name] = $list
    if ($list.Count -gt 0) {
        $file = Join-Path $RunDir (($Name -replace '[^A-Za-z0-9]+', '-') + "-$Stamp.csv")
        $list | Export-Csv -Path $file -NoTypeInformation -Encoding utf8
        Write-Log INFO "$Name : $($list.Count) row(s) -> $file"
    } else { Write-Log INFO "$Name : 0 rows" }
}

function Invoke-Step {
    <# .SYNOPSIS Runs one collection step in its own try/catch; a failure becomes a NotAssessed row. #>
    param([Parameter(Mandatory)][string]$Name, [Parameter(Mandatory)][scriptblock]$Body)
    Write-Log INFO "STEP start: $Name"
    try { & $Body; $Script:StepOk++; Write-Log INFO "STEP end: $Name" }
    catch {
        $Script:StepFailed++
        Write-ErrorDetail -ErrorRecord $_ -Step $Name
        Add-Check -Area $Name -Check 'Collection step' -Status NotAssessed -Detail "Step failed: $($_.Exception.Message)"
    }
}

function Get-Prop {
    <# .SYNOPSIS Returns a property value as text, or 'NotAssessed' when absent (never invents a value). #>
    param($InputObject, [Parameter(Mandatory)][string]$Name)
    if ($null -eq $InputObject -or -not $InputObject.PSObject.Properties[$Name]) { return 'NotAssessed' }
    $v = $InputObject.$Name
    if ($null -eq $v) { return '' }
    if ($v -is [System.Collections.IEnumerable] -and $v -isnot [string]) { return (@($v) | ForEach-Object { "$_" }) -join ', ' }
    return "$v"
}

function Format-EnumText {
    <# .SYNOPSIS Marks a value that came back as a bare number, so it is not mistaken for a count or score. #>
    param([string]$Value)
    if ($Value -match '^\d+$') { return "$Value (numeric code; see EAC for the name)" } else { return $Value }
}

function Get-FailureLayer {
    <# .SYNOPSIS Classifies a failure message using the FailurePatterns table. #>
    param([string]$Message)
    foreach ($p in $FailurePatterns) { if ($Message -match $p.Pattern) { return $p } }
    return @{ Layer = 'Unclassified'; Meaning = 'No known pattern; read the message and the move report.'; Next = 'Open the MoveReport XML or send it to Microsoft Support.'; Ref = '' }
}

function Test-RequiredModule {
    <# .SYNOPSIS Checks required modules; offers a CurrentUser install only in an interactive session. #>
    $interactive = [Environment]::UserInteractive -and -not ([Environment]::GetCommandLineArgs() -match '^-NonI')
    foreach ($m in $RequiredModules) {
        $found = Get-Module -ListAvailable -Name $m.Name | Where-Object Version -GE $m.MinimumVersion
        if ($found) { Write-Log INFO "Module $($m.Name) $(($found | Sort-Object Version -Descending)[0].Version) OK"; continue }
        $hasPsrg = [bool](Get-Command Install-PSResource -ErrorAction SilentlyContinue)   # PSResourceGet is often missing on Windows PowerShell 5.1
        $cmd = if ($hasPsrg) { "Install-PSResource -Name $($m.Name) -Version '[$($m.MinimumVersion),)' -Scope CurrentUser" } else { "Install-Module -Name $($m.Name) -MinimumVersion $($m.MinimumVersion) -Scope CurrentUser" }
        if (-not $interactive) { Write-Log ERROR "Module $($m.Name) >= $($m.MinimumVersion) missing. Run: $cmd"; return $false }
        if ((Read-Host "Install $($m.Name) for the current user now? [Y/N]") -notmatch '^[Yy]') { Write-Log ERROR "Operator declined install of $($m.Name)"; return $false }
        Write-Log INFO "Installing: $cmd"
        if ($hasPsrg) { Install-PSResource -Name $m.Name -Version "[$($m.MinimumVersion),)" -Scope CurrentUser -TrustRepository } else { Install-Module -Name $m.Name -MinimumVersion $m.MinimumVersion -Scope CurrentUser -Force }
        Write-Log INFO "Installed $($m.Name)"
    }
    $true
}

function Export-HtmlReport {
    <# .SYNOPSIS Writes a self-contained HTML report: summary checks first, then every data set. #>
    param([string]$Path, [string]$Title, [string]$Subtitle)
    $enc = { param($s) [System.Net.WebUtility]::HtmlEncode("$s") }
    $order = @{ Fail = 0; Warn = 1; NotAssessed = 2; Info = 3; Pass = 4 }
    $rows = foreach ($c in ($Script:Checks | Sort-Object { $order[$_.Status] }, Area)) {
        $refCell = if ($c.Reference) { "<a href='$(& $enc $c.Reference)'>doc</a>" } else { '' }
        "<tr class='$($c.Status.ToLower())'><td>$(& $enc $c.Status)</td><td>$(& $enc $c.Area)</td><td>$(& $enc $c.Check)</td><td>$(& $enc $c.Detail)</td><td>$refCell</td></tr>"
    }
    $counts = ($Script:Checks | Group-Object Status | ForEach-Object { "$($_.Name): $($_.Count)" }) -join ' &middot; '
    $sections = foreach ($k in $Script:Data.Keys) {
        $d = @($Script:Data[$k])
        if ($d.Count -eq 0) { "<h2>$(& $enc $k)</h2><p class='muted'>No rows.</p>" }
        else { "<h2>$(& $enc $k) <span class='muted'>($($d.Count))</span></h2><div class='wrap'>" + (($d | Select-Object -First 2000 | ConvertTo-Html -Fragment) -join "`n") + '</div>' }
    }
    $html = @"
<!doctype html><html><head><meta charset="utf-8"><title>$(& $enc $Title)</title>
<style>
body{font-family:Segoe UI,Arial,sans-serif;margin:24px;color:#1b1b1b;background:#fff}
h1{margin:0 0 4px}h2{margin-top:28px;border-bottom:1px solid #ddd;padding-bottom:4px}
.muted{color:#666;font-weight:normal;font-size:.9em}.wrap{overflow-x:auto}
table{border-collapse:collapse;width:100%;font-size:12px}th,td{border:1px solid #ddd;padding:4px 6px;text-align:left;vertical-align:top}
th{background:#f3f3f3;position:sticky;top:0}
tr.fail td:first-child{background:#f8d7da;font-weight:bold}tr.warn td:first-child{background:#fff3cd;font-weight:bold}
tr.pass td:first-child{background:#d1e7dd}tr.notassessed td:first-child{background:#e2e3e5}tr.info td:first-child{background:#cfe2ff}
</style></head><body>
<h1>$(& $enc $Title)</h1><p class="muted">$(& $enc $Subtitle)</p><p>$counts</p>
<h2>Findings</h2><table><tr><th>Status</th><th>Area</th><th>Check</th><th>Detail</th><th>Ref</th></tr>
$($rows -join "`n")
</table>
$($sections -join "`n")
</body></html>
"@
    Set-Content -Path $Path -Value $html -Encoding utf8
}

# ---- Main -----------------------------------------------------------------------------------------
foreach ($dir in @($RunDir, $LogDir)) {
    if (-not (Test-Path $dir)) { Write-Information "Folder $dir is missing - creating it." -InformationAction Continue; New-Item -ItemType Directory -Path $dir -Force | Out-Null }
}
Write-Information "Log file: $LogFile" -InformationAction Continue
Write-Log INFO "$ScriptName $ScriptVersion | Start $($StartRun.ToString('o')) | User $env:USERNAME | Computer $env:COMPUTERNAME | PS $($PSVersionTable.PSVersion)"
Write-Log INFO ("Parameters: " + (($PSBoundParameters.GetEnumerator() | ForEach-Object { "$($_.Key)=$($_.Value -join ',')" }) -join ' | '))
Write-Log INFO "Run folder: $RunDir"
if ($OutputPathNote) { Write-Log WARN $OutputPathNote }

try {
    if (-not (Test-RequiredModule)) { $ExitCode = 2; throw 'Required module check failed (see log above).' }
    Import-Module ExchangeOnlineManagement -MinimumVersion $RequiredModules[0].MinimumVersion
    Write-Log INFO 'Checking Exchange Online connection'
    if (-not (Get-ConnectionInformation | Where-Object State -EQ 'Connected')) { Connect-ExchangeOnline -ShowBanner:$false -ErrorAction Stop }
    Write-Log INFO 'Connected to Exchange Online'

    # 1-2. Endpoints and endpoint tests ----------------------------------------------------------------
    $Script:Endpoints = @()
    Invoke-Step -Name 'Migration endpoints' -Body {
        $Script:Endpoints = @(Get-MigrationEndpoint -ErrorAction Stop | Where-Object { (Get-Prop $_ 'EndpointType') -eq 'ExchangeRemoteMove' })
        Add-Data 'Migration endpoints (ExchangeRemoteMove)' ($Script:Endpoints | ForEach-Object {
            [pscustomobject]@{ Identity = Get-Prop $_ 'Identity'; RemoteServer = Get-Prop $_ 'RemoteServer'; Username = Get-Prop $_ 'Username'
                MaxConcurrentMigrations = Get-Prop $_ 'MaxConcurrentMigrations'; MaxConcurrentIncrementalSyncs = Get-Prop $_ 'MaxConcurrentIncrementalSyncs' } })
        Add-Check -Area 'Endpoint' -Check 'ExchangeRemoteMove endpoints' -Status $(if ($Script:Endpoints.Count -ge 1) { 'Info' } else { 'Fail' }) -Detail ("$($Script:Endpoints.Count) endpoint(s): " + (($Script:Endpoints | ForEach-Object { "$(Get-Prop $_ 'Identity') -> $(Get-Prop $_ 'RemoteServer') as $(Get-Prop $_ 'Username')" }) -join '; '))
    }

    $Script:StoredResult = @{}
    Invoke-Step -Name 'Endpoint test with SAVED credentials' -Body {
        $rows = foreach ($ep in $Script:Endpoints) {
            $id = Get-Prop $ep 'Identity'
            try {
                $t = Test-MigrationServerAvailability -Endpoint $id -ErrorAction Stop
                $res = Get-Prop $t 'Result'; $Script:StoredResult[$id] = $res
                [pscustomobject]@{ Endpoint = $id; Credentials = 'Saved in endpoint'; Result = $res; Message = Get-Prop $t 'Message'; ErrorDetail = Get-Prop $t 'ErrorDetail' }
            } catch {
                Write-ErrorDetail -ErrorRecord $_ -Step 'Test-MigrationServerAvailability -Endpoint' -Item $id
                $Script:StoredResult[$id] = 'Failed'
                [pscustomobject]@{ Endpoint = $id; Credentials = 'Saved in endpoint'; Result = 'Failed'; Message = $_.Exception.Message; ErrorDetail = '' }
            }
        }
        Add-Data 'Endpoint test - saved credentials' $rows
        foreach ($r in @($rows)) {
            $ok = $r.Result -eq 'Success'
            $layer = if ($ok) { '' } else { (Get-FailureLayer "$($r.Message) $($r.ErrorDetail)").Layer }
            Add-Check -Area 'Endpoint' -Check "Saved credentials work ($($r.Endpoint))" -Status $(if ($ok) { 'Pass' } else { 'Fail' }) -Detail $(if ($ok) { 'Exchange Online reached MRSProxy and signed in with the credentials saved in the endpoint.' } else { "Layer: $layer. $($r.Message) $($r.ErrorDetail)" }) -Reference 'https://learn.microsoft.com/powershell/module/exchangepowershell/test-migrationserveravailability'
        }
    }

    if ($TestTypedCredential) {
        Invoke-Step -Name 'Endpoint test with TYPED credentials' -Body {
            $cred = Get-Credential -Message 'On-premises account for the migration endpoint, as DOMAIN\user. The password is not logged.'
            if (-not $cred) { Add-Check -Area 'Endpoint' -Check 'Typed credential test' -Status NotAssessed -Detail 'No credential entered.'; return }
            Write-Log INFO "Typed credential test as $($cred.UserName) (password <redacted>)"
            $rows = foreach ($ep in $Script:Endpoints) {
                $id = Get-Prop $ep 'Identity'; $srv = Get-Prop $ep 'RemoteServer'
                try {
                    $t = Test-MigrationServerAvailability -ExchangeRemoteMove -RemoteServer $srv -Credentials $cred -ErrorAction Stop
                    [pscustomobject]@{ Endpoint = $id; RemoteServer = $srv; Credentials = "Typed ($($cred.UserName))"; Result = Get-Prop $t 'Result'; Message = Get-Prop $t 'Message'; ErrorDetail = Get-Prop $t 'ErrorDetail' }
                } catch { [pscustomobject]@{ Endpoint = $id; RemoteServer = $srv; Credentials = "Typed ($($cred.UserName))"; Result = 'Failed'; Message = $_.Exception.Message; ErrorDetail = '' } }
            }
            Add-Data 'Endpoint test - typed credentials' $rows
            foreach ($r in @($rows)) {
                $saved = $Script:StoredResult[$r.Endpoint]
                if ($r.Result -eq 'Success' -and $saved -ne 'Success') {
                    Add-Check -Area 'Endpoint' -Check "Saved vs typed credentials ($($r.Endpoint))" -Status Fail -Detail "Typed credentials work, saved ones do not: the password saved in the endpoint is wrong or old. Update it: Set-MigrationEndpoint -Identity '$($r.Endpoint)' -Credentials (Get-Credential)."
                } elseif ($r.Result -eq 'Success') {
                    Add-Check -Area 'Endpoint' -Check "Saved vs typed credentials ($($r.Endpoint))" -Status Pass -Detail 'Both work.'
                } else {
                    $layer = (Get-FailureLayer "$($r.Message) $($r.ErrorDetail)").Layer
                    if ($saved -eq 'Success') {
                        Add-Check -Area 'Endpoint' -Check "Saved vs typed credentials ($($r.Endpoint))" -Status Warn -Detail "Saved credentials work; the typed ones fail ($layer). The password or account you typed differs from the one saved in the endpoint (typo?). The endpoint itself is fine."
                    } else {
                        Add-Check -Area 'Endpoint' -Check "Typed credentials ($($r.Endpoint))" -Status Fail -Detail "Layer: $layer. Saved credentials fail too, so the cause is not only the saved password. $($r.Message)"
                    }
                }
            }
        }
    }

    Invoke-Step -Name 'Accepted domains' -Body {
        $routing = @(Get-AcceptedDomain -ErrorAction Stop | Where-Object { "$($_.DomainName)" -like '*.mail.onmicrosoft.com' })
        Add-Check -Area 'Tenant' -Check 'Routing domain (*.mail.onmicrosoft.com)' -Status $(if ($routing.Count -eq 1) { 'Pass' } else { 'Warn' }) -Detail (($routing | ForEach-Object { "$($_.DomainName)" }) -join ', ')
    }

    # 3. Batches and users -------------------------------------------------------------------------
    $Script:Users = @()
    Invoke-Step -Name 'Migration batches' -Body {
        # The list call can return enum values as numbers (seen in the lab 2026-10-17: Status 4, MigrationType 16);
        # reading each batch by identity returns the names, so list first and then read one by one.
        $ids = @(Get-MigrationBatch -ErrorAction Stop | ForEach-Object { "$($_.Identity)" } | Where-Object { -not $BatchName -or $_ -in $BatchName })
        Add-Data 'Migration batches' ($ids | ForEach-Object {
            $b = Get-MigrationBatch -Identity $_ -ErrorAction Stop
            [pscustomobject]@{ Identity = Get-Prop $b 'Identity'; Status = Format-EnumText (Get-Prop $b 'Status'); MigrationType = Format-EnumText (Get-Prop $b 'MigrationType'); TotalCount = Get-Prop $b 'TotalCount'
                SyncedCount = Get-Prop $b 'SyncedCount'; FailedCount = Get-Prop $b 'FailedCount'; DataConsistencyScore = Format-EnumText (Get-Prop $b 'DataConsistencyScore')
                SourceEndpoint = Get-Prop $b 'SourceEndpoint'; CreationDateTime = Get-Prop $b 'CreationDateTime'; NotificationEmails = Get-Prop $b 'NotificationEmails' } })
        if ($EmailAddress) { $Script:Users = @($EmailAddress) }
        elseif ($BatchName) { $Script:Users = @(foreach ($b in $BatchName) { Get-MigrationUser -BatchId $b -ErrorAction Stop | ForEach-Object { "$($_.Identity)" } }) }
        else {
            $Script:Users = @(foreach ($id in @(Get-MigrationUser -ResultSize Unlimited -ErrorAction Stop | ForEach-Object { "$($_.Identity)" })) {
                if ((Get-Prop (Get-MigrationUser -Identity $id -ErrorAction Stop) 'Status') -ne 'Completed') { $id }
            }) | Select-Object -First $MaxUsers
            $Script:Users = @($Script:Users)
        }
        $detail = if ($Script:Users.Count) { "$($Script:Users.Count): $($Script:Users -join ', ')" } else { 'None: no migration user outside Completed. Use -EmailAddress or -BatchName to include completed users.' }
        Add-Check -Area 'Users' -Check 'Users analysed' -Status Info -Detail $detail
    }

    # 4-5. Per-user move reports and failure layers ---------------------------------------------------
    $summary = [System.Collections.Generic.List[object]]::new(); $failures = [System.Collections.Generic.List[object]]::new()
    $entries = [System.Collections.Generic.List[object]]::new(); $skipped = [System.Collections.Generic.List[object]]::new()
    $n = 0
    foreach ($u in $Script:Users) {
        $n++; $tag = 'User{0:D2}' -f $n
        Invoke-Step -Name "Move evidence $tag ($u)" -Body {
            $mu = Get-MigrationUser -Identity $u -ErrorAction Stop
            $ms = Get-MigrationUserStatistics -Identity $u -IncludeReport -IncludeSkippedItems -ErrorAction Stop
            $rcp = $null; try { $rcp = Get-Recipient -Identity $u -ErrorAction Stop } catch { Write-Log WARN "Get-Recipient $u : $($_.Exception.Message)" }
            $guids = $null
            try { $guids = if ((Get-Prop $rcp 'RecipientTypeDetails') -match 'Mailbox$') { Get-Mailbox -Identity $u -ErrorAction Stop } else { Get-MailUser -Identity $u -ErrorAction Stop } } catch { Write-Log WARN "GUID lookup $u : $($_.Exception.Message)" }
            $mvArgs = @{ Identity = $u; IncludeReport = $true; ErrorAction = 'Stop' }
            if ($IncludeVerboseDiagnostics) { $mvArgs.DiagnosticInfo = 'showtimeslots, showtimeline, verbose' }
            $mv = $null; try { $mv = Get-MoveRequestStatistics @mvArgs } catch { Write-Log WARN "No move request statistics for $u : $($_.Exception.Message)" }
            if ($mv) { $xml = Join-Path $RunDir "MoveReport-$tag-$Stamp.xml"; $mv | Export-Clixml -Path $xml -Depth 10; Write-Log INFO "Move report XML for $u -> $xml" }

            $row = [pscustomobject]@{ Tag = $tag; EmailAddress = $u; BatchId = Get-Prop $mu 'BatchId'; MigrationStatus = Get-Prop $mu 'Status'; MoveStatus = Format-EnumText (Get-Prop $mv 'Status'); StatusDetail = Format-EnumText (Get-Prop $mv 'StatusDetail')
                PercentComplete = Get-Prop $mv 'PercentComplete'; DataConsistencyScore = Get-Prop $mu 'DataConsistencyScore'; HasUnapprovedSkippedItems = Get-Prop $mu 'HasUnapprovedSkippedItems'
                SkippedItemCount = Get-Prop $ms 'SkippedItemCount'; TotalMailboxSize = Get-Prop $mv 'TotalMailboxSize'; TotalArchiveSize = Get-Prop $mv 'TotalArchiveSize'; BytesTransferred = Get-Prop $mv 'BytesTransferred'
                LastSuccessfulSync = Get-Prop $mv 'LastSuccessfulSyncTimestamp'; RecipientTypeDetails = Get-Prop $rcp 'RecipientTypeDetails'; ExchangeGuid = Get-Prop $guids 'ExchangeGuid'; ArchiveGuid = Get-Prop $guids 'ArchiveGuid'
                Error = Get-Prop $ms 'Error' }
            $summary.Add($row)

            $rep = if ($mv -and $mv.PSObject.Properties['Report']) { $mv.Report } else { $null }
            $f = @(if ($rep -and $rep.PSObject.Properties['Failures']) { $rep.Failures })
            foreach ($x in $f) {
                $msg = "$(Get-Prop $x 'Message')"; $l = Get-FailureLayer $msg
                $failures.Add([pscustomobject]@{ Tag = $tag; EmailAddress = $u; Timestamp = Get-Prop $x 'Timestamp'; FailureType = Get-Prop $x 'FailureType'; FailureSide = Get-Prop $x 'FailureSide'; Layer = $l.Layer; Message = $msg })
            }
            foreach ($e in @(if ($rep -and $rep.PSObject.Properties['Entries']) { $rep.Entries })) {
                $entries.Add([pscustomobject]@{ Tag = $tag; CreationTime = Get-Prop $e 'CreationTime'; Type = Get-Prop $e 'Type'; Message = "$(Get-Prop $e 'Message')" })
            }
            foreach ($s in @(if ($ms.PSObject.Properties['SkippedItems']) { $ms.SkippedItems })) {
                $skipped.Add([pscustomobject]@{ Tag = $tag; Subject = Get-Prop $s 'Subject'; Sender = Get-Prop $s 'Sender'; DateSent = Get-Prop $s 'DateSent'; Kind = Get-Prop $s 'Kind'; FolderName = Get-Prop $s 'FolderName'; ScoringClassifications = Get-Prop $s 'ScoringClassifications' })
            }

            # Findings for this user.
            $st = $row.MigrationStatus
            $status = switch -Regex ($st) { '^Failed' { 'Fail' } '^(Synced|Completed)' { 'Pass' } default { 'Info' } }
            Add-Check -Area "User $tag" -Check "Migration status ($u)" -Status $status -Detail "Status $st | move $($row.MoveStatus) / $($row.StatusDetail) | $($row.PercentComplete)% | error: $($row.Error)"
            if ($row.DataConsistencyScore -match 'Investigate|Poor') { Add-Check -Area "User $tag" -Check 'Data Consistency Score' -Status $(if ($row.DataConsistencyScore -eq 'Poor') { 'Fail' } else { 'Warn' }) -Detail "$($row.DataConsistencyScore). Investigate: approve skipped items; Poor: contact Microsoft Support." -Reference 'https://learn.microsoft.com/exchange/mailbox-migration/track-prevent-data-loss-dcs' }
            if ($row.HasUnapprovedSkippedItems -eq 'True') { Add-Check -Area "User $tag" -Check 'Skipped items awaiting approval' -Status Warn -Detail 'Review the SkippedItems CSV, then Set-MigrationUser -ApproveSkippedItems.' }
            if ($row.ArchiveGuid -match '^0{8}-') { Add-Check -Area "User $tag" -Check 'ArchiveGuid on cloud object' -Status Info -Detail 'Empty ArchiveGuid: an on-prem archive will not move with this user.' }
            if ($f.Count -gt 0) {
                $byLayer = $failures | Where-Object Tag -EQ $tag | Group-Object Layer | Sort-Object Count -Descending
                $top = $byLayer[0]; $p = Get-FailureLayer ($top.Group[-1].Message)
                Add-Check -Area "User $tag" -Check "Most common failure layer ($u)" -Status Fail -Detail "$($top.Name) x$($top.Count) of $($f.Count); last at $($top.Group[-1].Timestamp). $($p.Meaning) Next: $($p.Next)" -Reference $p.Ref
            }
        }
    }
    Add-Data 'Move summary per user' $summary
    Add-Data 'Move failures (classified)' $failures
    if ($failures.Count -gt 0) {
        Add-Data 'Failures by layer' ($failures | Group-Object Tag, Layer | ForEach-Object {
            $g = $_.Group; [pscustomobject]@{ Tag = $g[0].Tag; EmailAddress = $g[0].EmailAddress; Layer = $g[0].Layer; Count = $_.Count; First = $g[0].Timestamp; Last = $g[-1].Timestamp; LastMessage = $g[-1].Message } })
    }
    Add-Data 'Move report entries' $entries
    Add-Data 'Skipped items' $skipped

    # 6. Exchange Online IP ranges -----------------------------------------------------------------
    if (-not $SkipIpList) {
        Invoke-Step -Name 'Exchange Online IP ranges' -Body {
            $uri = $IpServiceUri -f [guid]::NewGuid()
            # PowerShell 7 returns a JSON array as one object; assign first, then enumerate.
            $resp = Invoke-RestMethod -Uri $uri -TimeoutSec 60 -ErrorAction Stop
            $sets = @($resp | ForEach-Object { $_ })
            if ($sets.Count -eq 0) { throw 'The Microsoft 365 IP web service returned no endpoint sets.' }
            $rows = foreach ($s in $sets) {
                if (-not $s.PSObject.Properties['ips']) { continue }
                foreach ($ip in $s.ips) {
                    [pscustomobject]@{ Id = $s.id; ServiceArea = $s.serviceArea; Category = Get-Prop $s 'category'; Required = Get-Prop $s 'required'; TcpPorts = Get-Prop $s 'tcpPorts'
                        Family = $(if ($ip -match ':') { 'IPv6' } else { 'IPv4' }); Ip = $ip; Urls = Get-Prop $s 'urls' }
                }
            }
            $rows = @($rows)
            $csv = Join-Path $RunDir "ExoIpRanges-$Stamp.csv"
            $rows | Export-Csv -Path $csv -NoTypeInformation -Encoding utf8
            $Script:Data['Exchange Online IP ranges'] = $rows
            Write-Log INFO "Exchange Online IP ranges: $($rows.Count) -> $csv"
            Add-Check -Area 'Firewall' -Check 'Exchange Online source IP ranges for inbound 443' -Status Info -Detail "$(@($rows | Where-Object { $_.Family -eq 'IPv4' -and $_.ServiceArea -eq 'Exchange' }).Count) IPv4 + $(@($rows | Where-Object { $_.Family -eq 'IPv6' -and $_.ServiceArea -eq 'Exchange' }).Count) IPv6 ranges with ServiceArea=Exchange in $csv (other rows are dependencies). Microsoft: when restricting inbound to MRSProxy, permit the IP addresses in the Exchange Online table. Give this file to the network team and compare with the firewall rule." -Reference 'https://learn.microsoft.com/microsoft-365/enterprise/additional-office365-ip-addresses-and-urls'
        }
    }
}
catch {
    Write-ErrorDetail -ErrorRecord $_ -Step 'Fatal'
    if ($ExitCode -eq 0) { $ExitCode = 2 }
}
finally {
    try {
        $html = Join-Path $RunDir "Report-$Stamp.html"
        $Script:Checks | Export-Csv -Path (Join-Path $RunDir "Checks-$Stamp.csv") -NoTypeInformation -Encoding utf8
        Export-HtmlReport -Path $html -Title 'Hybrid move evidence - Exchange Online' -Subtitle "$ScriptName $ScriptVersion | run $($StartRun.ToString('yyyy-MM-dd HH:mm')) | move report times are UTC"
        Write-Log INFO "HTML report: $html"
    } catch { Write-ErrorDetail -ErrorRecord $_ -Step 'Write report'; if ($ExitCode -eq 0) { $ExitCode = 1 } }
    if ($ExitCode -eq 0 -and $Script:StepFailed -gt 0) { $ExitCode = 1 }
    $c = $Script:Checks; $end = Get-Date
    Write-Log INFO ("End $($end.ToString('o')) | Duration $([int]($end - $StartRun).TotalSeconds)s | steps ok $($Script:StepOk) / failed $($Script:StepFailed) | findings Fail $(@($c | Where-Object Status -EQ 'Fail').Count), Warn $(@($c | Where-Object Status -EQ 'Warn').Count), NotAssessed $(@($c | Where-Object Status -EQ 'NotAssessed').Count) | Exit code $ExitCode")
    Write-Information "Log file: $LogFile" -InformationAction Continue
}
exit $ExitCode
