@{
    # Case settings read by Invoke-HybridMoveCollection.ps1 (parameters given on the command line win).
    # Contains no passwords. Keep this file with the case, not in a public repository.

    HybridHostName  = 'hybrid1.bancocarregosa.com'   # RemoteServer of the migration endpoint
    EndpointAccount = 'LJC\administrator'            # account saved in the migration endpoint (DOMAIN\user)
    MigratingMailbox = 'MariaCandida@bancocarregosa.com'  # mailbox being moved (optional; on-prem mailbox details)
    PublicIp        = '88.157.207.218'               # public IP of the hybrid name (optional)
    StartTime       = '2026-10-19 20:40'             # local time the last migration batch was started
    # EndTime       = '2026-10-19 22:00'             # optional; default = now
}
