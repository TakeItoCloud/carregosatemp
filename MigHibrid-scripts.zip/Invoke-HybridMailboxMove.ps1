#Requires -Version 5.1
<#
.SYNOPSIS
    Starts, monitors, troubleshoots and completes a hybrid onboarding move (primary + archive) of one mailbox to Exchange Online.

.DESCRIPTION
    One script, one mailbox, driven by -Action:
      Start          Pre-flight checks, then New-MigrationBatch (remote move, primary AND archive, no auto-complete).
      Status         Read-only. Batch, migration user and move statistics, plus a suggested next step. Safe to run daily.
      Errors         Read-only. Exports the move report failures, skipped items and a full XML for Microsoft Support.
      ApproveSkipped Set-MigrationUser -ApproveSkippedItems (needed when the Data Consistency Score is 'Investigate').
      Complete       Complete-MigrationBatch (final incremental sync and cut-over).
      Retry          Start-MigrationBatch on the existing batch (retries a failed user in Exchange Online).

    Start, ApproveSkipped, Complete and Retry change Exchange Online and need -Apply; without it they only report what they would do.
    They also honour -WhatIf / -Confirm.

    BadItemLimit / LargeItemLimit are deliberately NOT used: both are deprecated in Exchange Online. Completion is governed
    by the Data Consistency Score and skipped-item approval instead.
    Source: https://learn.microsoft.com/powershell/module/exchangepowershell/new-migrationbatch (read 2026-10-15)
    Source: https://learn.microsoft.com/exchange/mailbox-migration/track-prevent-data-loss-dcs (read 2026-10-15)

    Cannot see: the on-premises side (MRSProxy health, on-prem mailbox sizes) or license assignment (needs Microsoft Graph).
    Those are reported as NotAssessed.

.PARAMETER Action
    Start | Status | Errors | ApproveSkipped | Complete | Retry.

.PARAMETER EmailAddress
    The user's routable SMTP address as it exists on the Exchange Online mail user. A .local address is rejected.

.PARAMETER BatchName
    Migration batch name. Default: Onboard-<local part of EmailAddress>.

.PARAMETER SourceEndpoint
    ExchangeRemoteMove migration endpoint. If omitted, the script uses the only one in the tenant and stops if there are zero or several.

.PARAMETER TargetDeliveryDomain
    Routing domain (<tenant>.mail.onmicrosoft.com). If omitted, the script uses the only matching accepted domain and stops if ambiguous.

.PARAMETER NotificationEmails
    Optional addresses that receive the migration service's status reports.

.PARAMETER Apply
    Required for actions that change Exchange Online. Without it those actions run in report mode.

.PARAMETER OutputPath
    Root output folder. Default C:\Scripts\Cannes. Files go to <OutputPath>\Invoke-HybridMailboxMove\ and logs to ...\Logs\.

.EXAMPLE
    .\Invoke-HybridMailboxMove.ps1 -Action Start -EmailAddress user@contoso.com
    Report mode: runs pre-flight checks and shows the batch it would create. Changes nothing.

.EXAMPLE
    .\Invoke-HybridMailboxMove.ps1 -Action Start -EmailAddress user@contoso.com -NotificationEmails admin@contoso.com -Apply

.EXAMPLE
    .\Invoke-HybridMailboxMove.ps1 -Action Status -EmailAddress user@contoso.com

.EXAMPLE
    .\Invoke-HybridMailboxMove.ps1 -Action Errors -EmailAddress user@contoso.com

.EXAMPLE
    .\Invoke-HybridMailboxMove.ps1 -Action Complete -EmailAddress user@contoso.com -Apply

.OUTPUTS
    PSCustomObject per action. Files: Status-<ts>.csv, MoveFailures-<ts>.csv, SkippedItems-<ts>.csv,
    MoveReport-<ts>.xml, and the run log.

.NOTES
    Owner: Carlos Annes (TakeItToCloud)
    Version: 1.1.2
    Created: 2026-10-15
    Last updated: 2026-10-19
    Requires: Windows PowerShell 5.1 or PowerShell 7 (5.1 supported so it runs where PowerShell 7 is not installed), ExchangeOnlineManagement 3.0.0+, Exchange Online role with Move Mailboxes (e.g. Exchange Administrator).
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory)][ValidateSet('Start', 'Status', 'Errors', 'ApproveSkipped', 'Complete', 'Retry')][string]$Action,
    [Parameter(Mandatory)][ValidatePattern('^[^@\s]+@[^@\s]+\.[^@\s]+$')][string]$EmailAddress,
    [string]$BatchName,
    [string]$SourceEndpoint,
    [string]$TargetDeliveryDomain,
    [string[]]$NotificationEmails,
    [switch]$Apply,
    [string]$OutputPath = 'C:\Scripts\Cannes'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# Windows PowerShell 5.1 may not offer TLS 1.2 by default; the PowerShell Gallery and endpoints.office.com require it.
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

# ---- Configuration --------------------------------------------------------------------------------
$ScriptName    = 'Invoke-HybridMailboxMove'
$ScriptVersion = '1.1.2'
# ExchangeOnlineManagement 3.x = REST-based module. https://learn.microsoft.com/powershell/exchange/exchange-online-powershell-v2 (read 2026-10-15)
$RequiredModules = @(
    @{ Name = 'ExchangeOnlineManagement'; MinimumVersion = [version]'3.0.0' }
)
$Stamp     = Get-Date -Format 'yyyyMMdd-HHmmss'
$WorkDir   = Join-Path $OutputPath $ScriptName
$LogDir    = Join-Path $WorkDir 'Logs'
$LogFile   = Join-Path $LogDir "$ScriptName-$Stamp.log"
$StartTime = Get-Date
$ExitCode  = 0
if (-not $BatchName) { $BatchName = 'Onboard-' + $EmailAddress.Split('@')[0] }

# ---- Helpers --------------------------------------------------------------------------------------
function Write-Log {
    <# .SYNOPSIS Writes one timestamped line to the log file and the console. #>
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidOverwritingBuiltInCmdlets', '', Justification = 'House rule names the helper Write-Log; no Write-Log cmdlet ships in PowerShell 7 on this host.')]
    param([ValidateSet('INFO', 'WARN', 'ERROR', 'DEBUG')][string]$Level = 'INFO', [Parameter(Mandatory)][string]$Message)
    $line = '{0} [{1}] {2}' -f (Get-Date -Format 'o'), $Level, $Message
    Add-Content -Path $LogFile -Value $line -Encoding utf8
    Write-Information -MessageData $line -InformationAction Continue
}

function Write-ErrorDetail {
    <# .SYNOPSIS Logs a caught error with step, item, message, type, position and stack. #>
    param([Parameter(Mandatory)]$ErrorRecord, [Parameter(Mandatory)][string]$Step, [string]$Item = $EmailAddress)
    Write-Log ERROR "Step: $Step | Item: $Item"
    Write-Log ERROR "Message: $($ErrorRecord.Exception.Message)"
    Write-Log ERROR "Type: $($ErrorRecord.Exception.GetType().FullName)"
    Write-Log ERROR "Position: $($ErrorRecord.InvocationInfo.PositionMessage)"
    Write-Log ERROR "Stack: $($ErrorRecord.ScriptStackTrace)"
}

function Get-Prop {
    <# .SYNOPSIS Returns a property value, or 'NotAssessed' when the object or property is absent (never invents a value). #>
    param($InputObject, [Parameter(Mandatory)][string]$Name)
    if ($null -eq $InputObject -or -not $InputObject.PSObject.Properties[$Name]) { return 'NotAssessed' }
    $v = $InputObject.$Name
    if ($null -eq $v) { return 'NotAssessed' } else { return $v }
}

function Invoke-Optional {
    <# .SYNOPSIS Runs a lookup that may legitimately find nothing; returns $null instead of throwing, and logs why. #>
    param([Parameter(Mandatory)][scriptblock]$ScriptBlock, [Parameter(Mandatory)][string]$What)
    try { & $ScriptBlock } catch { Write-Log INFO "$What not found: $($_.Exception.Message.TrimStart('|'))"; $null }
}

function Get-NextStep {
    <#
    .SYNOPSIS Suggests the operator's next action from the migration state.
    .PARAMETER Status Migration user status (Syncing, Synced, Failed, Completed, ...).
    .PARAMETER DataConsistencyScore Perfect | Good | Investigate | Poor | NotAssessed.
    .PARAMETER HasUnapprovedSkippedItems True when skipped items are waiting for approval.
    #>
    param([string]$Status, [string]$DataConsistencyScore, [string]$HasUnapprovedSkippedItems)
    # TODO(human): return one short string telling the operator what to run next.
    return 'NotAssessed - next-step rules not written yet'
}

function Test-RequiredModule {
    <# .SYNOPSIS Checks required modules; offers a CurrentUser install only in an interactive session. #>
    $interactive = [Environment]::UserInteractive -and -not ([Environment]::GetCommandLineArgs() -match '^-NonI')
    foreach ($m in $RequiredModules) {
        $found = Get-Module -ListAvailable -Name $m.Name | Where-Object Version -GE $m.MinimumVersion
        if ($found) { Write-Log INFO "Module $($m.Name) $(($found | Sort-Object Version -Descending)[0].Version) OK"; continue }
        $hasPsrg = [bool](Get-Command Install-PSResource -ErrorAction SilentlyContinue)   # PSResourceGet is often missing on Windows PowerShell 5.1
        $cmd = if ($hasPsrg) { "Install-PSResource -Name $($m.Name) -Version '[$($m.MinimumVersion),)' -Scope CurrentUser" } else { "Install-Module -Name $($m.Name) -MinimumVersion $($m.MinimumVersion) -Scope CurrentUser" }
        if (-not $interactive) { Write-Log ERROR "Module $($m.Name) >= $($m.MinimumVersion) missing. Run: $cmd"; return $false }
        if ((Read-Host "Install $($m.Name) for the current user now? [Y/N]") -notmatch '^[Yy]') { Write-Log ERROR "Operator declined install of $($m.Name)"; return $false }
        Write-Log INFO "Installing: $cmd"
        if ($hasPsrg) { Install-PSResource -Name $m.Name -Version "[$($m.MinimumVersion),)" -Scope CurrentUser -TrustRepository } else { Install-Module -Name $m.Name -MinimumVersion $m.MinimumVersion -Scope CurrentUser -Force }
        Write-Log INFO "Installed $($m.Name)"
    }
    $true
}

function Export-Result {
    <# .SYNOPSIS Exports objects to a timestamped CSV in the work folder and logs the path and count. #>
    param([Parameter(Mandatory)][AllowNull()]$Data, [Parameter(Mandatory)][string]$Prefix)
    $rows = @($Data | Where-Object { $null -ne $_ })
    $path = Join-Path $WorkDir "$Prefix-$Stamp.csv"
    if ($rows.Count -eq 0) { Write-Log INFO "$Prefix : 0 rows, no file written"; return }
    $rows | Export-Csv -Path $path -NoTypeInformation -Encoding utf8
    Write-Log INFO "$Prefix : $($rows.Count) row(s) -> $path"
}

# ---- Main -----------------------------------------------------------------------------------------
$created = @()
foreach ($dir in @($WorkDir, $LogDir)) {
    if (-not (Test-Path $dir)) { Write-Information "Folder $dir is missing - creating it." -InformationAction Continue; New-Item -ItemType Directory -Path $dir -Force | Out-Null; $created += $dir }
}
Write-Information "Log file: $LogFile" -InformationAction Continue
Write-Log INFO "$ScriptName $ScriptVersion | Start $($StartTime.ToString('o')) | User $env:USERNAME | Computer $env:COMPUTERNAME | PS $($PSVersionTable.PSVersion)"
Write-Log INFO ("Parameters: " + (($PSBoundParameters.GetEnumerator() | ForEach-Object { "$($_.Key)=$($_.Value -join ',')" }) -join ' | '))
foreach ($dir in $created) { Write-Log INFO "Created missing folder $dir" }

try {
    if ($EmailAddress -match '\.local$') { $ExitCode = 2; throw "EmailAddress '$EmailAddress' is a non-routable .local address. Use the user's SMTP address as it exists in Exchange Online." }
    if (-not (Test-RequiredModule)) { $ExitCode = 2; throw 'Required module check failed (see log above).' }
    Import-Module ExchangeOnlineManagement -MinimumVersion $RequiredModules[0].MinimumVersion

    Write-Log INFO 'Checking Exchange Online connection'
    if (-not (Get-ConnectionInformation | Where-Object State -EQ 'Connected')) { Connect-ExchangeOnline -ShowBanner:$false }
    Write-Log INFO 'Connected to Exchange Online'

    switch ($Action) {
        'Start' {
            Write-Log INFO 'Pre-flight: mail user, GUIDs, existing moves, endpoint, delivery domain'
            $mu = Invoke-Optional { Get-MailUser -Identity $EmailAddress -ErrorAction Stop } 'Mail user'
            if (-not $mu) { $ExitCode = 2; throw "No Exchange Online mail user for $EmailAddress. Check Entra Connect sync." }
            if ($mu.ExchangeGuid -eq [guid]::Empty) { $ExitCode = 2; throw 'Mail user ExchangeGuid is empty; the on-prem msExchMailboxGuid has not synced.' }
            if ($mu.ArchiveGuid -eq [guid]::Empty) { $ExitCode = 2; throw 'Mail user ArchiveGuid is empty; the on-prem archive would NOT move. Check msExchArchiveGUID sync.' }
            Write-Log INFO "Mail user OK. ExchangeGuid $($mu.ExchangeGuid) | ArchiveGuid $($mu.ArchiveGuid)"
            if (Invoke-Optional { Get-MigrationUser -Identity $EmailAddress -ErrorAction Stop } 'Existing migration user (expected)') { $ExitCode = 2; throw "$EmailAddress is already in a migration batch. Use -Action Status." }
            $old = Invoke-Optional { Get-MigrationBatch -Identity $BatchName -ErrorAction Stop } 'Existing batch (expected)'
            if ($old) { $ExitCode = 2; throw "Batch '$BatchName' already exists (status $($old.Status)). If it is Removing, wait a few minutes and run again; otherwise Remove-MigrationBatch it or pass -BatchName." }

            if (-not $SourceEndpoint) {
                $eps = @(Get-MigrationEndpoint -ErrorAction Stop | Where-Object EndpointType -EQ 'ExchangeRemoteMove')
                if ($eps.Count -ne 1) { $ExitCode = 2; throw "Found $($eps.Count) ExchangeRemoteMove endpoints. Pass -SourceEndpoint." }
                $SourceEndpoint = $eps[0].Identity
            }
            if (-not $TargetDeliveryDomain) {
                $tdd = @(Get-AcceptedDomain -ErrorAction Stop | Where-Object DomainName -Like '*.mail.onmicrosoft.com')
                if ($tdd.Count -ne 1) { $ExitCode = 2; throw "Found $($tdd.Count) *.mail.onmicrosoft.com domains. Pass -TargetDeliveryDomain." }
                $TargetDeliveryDomain = $tdd[0].DomainName
            }
            Write-Log INFO "Endpoint: $SourceEndpoint | TargetDeliveryDomain: $TargetDeliveryDomain | License: NotAssessed (needs Graph)"

            # Primary AND archive move by default (no -PrimaryOnly / -ArchiveOnly). No -AutoComplete: the batch holds at Synced.
            $batchArgs = @{
                Name                 = $BatchName
                SourceEndpoint       = $SourceEndpoint
                TargetDeliveryDomain = $TargetDeliveryDomain
                CSVData              = [Text.Encoding]::UTF8.GetBytes("EmailAddress`r`n$EmailAddress")
                AutoStart            = $true
            }
            if ($NotificationEmails) { $batchArgs.NotificationEmails = $NotificationEmails }
            if (-not $Apply) { Write-Log INFO "REPORT MODE: would run New-MigrationBatch -Name $BatchName (primary+archive, AutoStart, no AutoComplete). Add -Apply to run."; break }
            if ($PSCmdlet.ShouldProcess($EmailAddress, "New-MigrationBatch $BatchName")) {
                $b = New-MigrationBatch @batchArgs -ErrorAction Stop
                if (-not $b) { throw 'New-MigrationBatch returned nothing. Check Get-MigrationBatch before re-running.' }
                Write-Log INFO "Batch $($b.Identity) created, status $($b.Status)"
            }
        }
        'Status' {
            $batch = Invoke-Optional { Get-MigrationBatch -Identity $BatchName -ErrorAction Stop } 'Migration batch'
            $mUser = Invoke-Optional { Get-MigrationUser -Identity $EmailAddress -ErrorAction Stop } 'Migration user'
            $mStat = Invoke-Optional { Get-MigrationUserStatistics -Identity $EmailAddress -ErrorAction Stop } 'Migration user statistics'
            $move  = Invoke-Optional { Get-MoveRequestStatistics -Identity $EmailAddress -ErrorAction Stop } 'Move request statistics'
            if (-not $mUser) { $ExitCode = 1; throw "No migration user for $EmailAddress - nothing to report. Was -Action Start run with -Apply?" }
            $result = [pscustomobject]@{
                CheckedAt                 = Get-Date -Format 's'
                BatchName                 = $BatchName
                BatchStatus               = Get-Prop $batch 'Status'
                UserStatus                = Get-Prop $mUser 'Status'
                StatusDetail              = Get-Prop $move 'StatusDetail'
                PercentComplete           = Get-Prop $move 'PercentComplete'
                TotalMailboxSize          = "$(Get-Prop $move 'TotalMailboxSize')"
                TotalArchiveSize          = "$(Get-Prop $move 'TotalArchiveSize')"
                BytesTransferred          = "$(Get-Prop $move 'BytesTransferred')"
                SyncedItemCount           = Get-Prop $mStat 'SyncedItemCount'
                SkippedItemCount          = Get-Prop $mStat 'SkippedItemCount'
                DataConsistencyScore      = Get-Prop $mUser 'DataConsistencyScore'
                HasUnapprovedSkippedItems = Get-Prop $mUser 'HasUnapprovedSkippedItems'
                LastSuccessfulSync        = Get-Prop $move 'LastSuccessfulSyncTimestamp'
                Error                     = "$(Get-Prop $mStat 'Error')"
                NextStep                  = $null
            }
            $result.NextStep = Get-NextStep -Status $result.UserStatus -DataConsistencyScore $result.DataConsistencyScore -HasUnapprovedSkippedItems $result.HasUnapprovedSkippedItems
            Export-Result -Data $result -Prefix 'Status'
            Write-Log INFO "Status $($result.UserStatus) | $($result.PercentComplete)% | DCS $($result.DataConsistencyScore) | Next: $($result.NextStep)"
            if ($result.UserStatus -eq 'Failed') { $ExitCode = 1 }
            $result | Format-List
        }
        'Errors' {
            $mStat = Get-MigrationUserStatistics -Identity $EmailAddress -IncludeReport -IncludeSkippedItems -ErrorAction Stop
            # Get-MigrationUserStatistics can return Status as a number; Get-MigrationUser returns the name.
            $mUser = Invoke-Optional { Get-MigrationUser -Identity $EmailAddress -ErrorAction Stop } 'Migration user'
            Write-Log INFO "Migration user status $(Get-Prop $mUser 'Status') | Error: $(Get-Prop $mStat 'Error')"
            Export-Result -Data ($mStat.SkippedItems | Select-Object Subject, Sender, DateSent, ScoringClassifications) -Prefix 'SkippedItems'
            # DiagnosticInfo values as used in Microsoft's troubleshooting guidance for move reports.
            # https://learn.microsoft.com/troubleshoot/exchange/move-or-migrate-mailboxes/transientexception-errors-when-moving-mailboxes (read 2026-10-15)
            $move = Invoke-Optional { Get-MoveRequestStatistics -Identity $EmailAddress -IncludeReport -DiagnosticInfo 'showtimeslots, showtimeline, verbose' -ErrorAction Stop } 'Move report'
            if ($move) {
                $xml = Join-Path $WorkDir "MoveReport-$Stamp.xml"
                $move | Export-Clixml -Path $xml -Depth 10
                Write-Log INFO "Full move report for Microsoft Support -> $xml"
                $fails = @($move.Report.Failures | Select-Object Timestamp, FailureType, FailureSide, Message)
                Export-Result -Data $fails -Prefix 'MoveFailures'
                $fails | Select-Object -Last 3 | ForEach-Object { Write-Log WARN "$($_.Timestamp) $($_.FailureType): $($_.Message)" }
            }
        }
        'ApproveSkipped' {
            if (-not $Apply) { Write-Log INFO 'REPORT MODE: would run Set-MigrationUser -ApproveSkippedItems. Review -Action Errors output first, then add -Apply.'; break }
            if ($PSCmdlet.ShouldProcess($EmailAddress, 'Set-MigrationUser -ApproveSkippedItems')) {
                Set-MigrationUser -Identity $EmailAddress -ApproveSkippedItems -Confirm:$false -ErrorAction Stop
                Write-Log INFO 'Skipped items approved'
            }
        }
        'Complete' {
            $mUser = Get-MigrationUser -Identity $EmailAddress -ErrorAction Stop
            if ($mUser.Status -notmatch '^Synced') { Write-Log WARN "User status is $($mUser.Status), not Synced. Completion may wait or fail." }
            if (-not $Apply) { Write-Log INFO "REPORT MODE: would run Complete-MigrationBatch $BatchName. Add -Apply in the agreed cut-over window."; break }
            if ($PSCmdlet.ShouldProcess($BatchName, 'Complete-MigrationBatch')) {
                Complete-MigrationBatch -Identity $BatchName -Confirm:$false -ErrorAction Stop
                Write-Log INFO 'Completion requested. Do not re-run within 8 hours; check -Action Status.'
            }
        }
        'Retry' {
            if (-not $Apply) { Write-Log INFO "REPORT MODE: would run Start-MigrationBatch $BatchName to retry failed users. Add -Apply."; break }
            if ($PSCmdlet.ShouldProcess($BatchName, 'Start-MigrationBatch (retry)')) {
                Start-MigrationBatch -Identity $BatchName -Confirm:$false -ErrorAction Stop
                Write-Log INFO 'Retry requested'
            }
        }
    }
}
catch {
    Write-ErrorDetail -ErrorRecord $_ -Step "Action $Action"
    if ($ExitCode -eq 0) { $ExitCode = 1 }
}
finally {
    $end = Get-Date
    $result = if ($ExitCode -eq 0) { 'succeeded 1 / failed 0' } else { 'succeeded 0 / failed 1' }
    Write-Log INFO "End $($end.ToString('o')) | Duration $([int]($end - $StartTime).TotalSeconds)s | $result | Exit code $ExitCode"
    Write-Information "Log file: $LogFile" -InformationAction Continue
}
exit $ExitCode
