# Hybrid mailbox move (MRSProxy) – troubleshooting runbook

| | |
|---|---|
| Owner | Carlos Annes (TakeItToCloud) |
| Version | 1.7 – 2026-10-19 (one-run collection 1.0.0 + Case-Settings.psd1; verdict 1.5.0; on-prem 1.1.0, cloud 1.0.4, DC 1.1.0, move 1.1.2) |
| Scope | Exchange hybrid **remote move** (on-premises → Exchange Online) failing to connect, sign in or finish |
| Tools | 6 local PowerShell scripts and one settings file in this folder (nothing is published or pushed anywhere) |

All checks in the scripts are **read-only**. The only things that change anything are `Invoke-HybridMailboxMove.ps1 … -Apply` and the fixes in section 6, which are agreed with the bank before they are applied.

---

## 1. How a hybrid move connects

```
Exchange Online (MRS, Microsoft IP ranges)
   │  HTTPS 443, NTLM sign-in, Host/SNI = <hybrid-name>  (RemoteServer of the migration endpoint)
   ▼
Internet → <public-ip>:443  (client firewall – often restricted to Microsoft IPs)
   │  NAT / reverse proxy  → which internal Exchange server(s)? (network team)
   ▼
Published Exchange servers – IIS "Default Web Site" 443 → /EWS/mrsproxy.svc (MRSProxy)
   │  NTLM validated by a domain controller (4776)       │  data proxied to the mailbox databases
   ▼                                                      ▼
Domain controllers                                   Mailbox servers
```

The procedure in sections 1 and 3–7 is the same for every client. Replace the placeholders with the client's values:

| Placeholder | Where to find it |
|---|---|
| `<user@domain>` | The mailbox being migrated (cloud SMTP address) |
| `<hybrid-name>` | `Get-MigrationEndpoint \| Format-List RemoteServer` |
| `<DOMAIN\endpoint-account>` | `Get-MigrationEndpoint \| Format-List Username` |
| `<public-ip>` | Public DNS answer for `<hybrid-name>` (optional) |
| `<Evidence>` | The case evidence folder (this client: `Z:\Work\Client\Carregosa\MigHibrid\Evidence`) |

This client's values are in section 2.

### What Microsoft requires on that path

| Item | Requirement | Source |
|---|---|---|
| Port / direction | TCP 443 **inbound** from Exchange Online to the server publishing EWS | [Hybrid prerequisites](https://learn.microsoft.com/exchange/hybrid-deployment-prerequisites) |
| Endpoint | `/ews/mrsproxy.svc`, authentication provider **NTLM**, **pre-authentication not supported** | same page, "Hybrid deployment protocols, ports, and endpoints" |
| Source IP allow list | If inbound is restricted, permit the IP addresses in the **Exchange Online** table (web service rows with `ServiceArea = Exchange`) | [Other endpoints, row 6](https://learn.microsoft.com/microsoft-365/enterprise/additional-office365-ip-addresses-and-urls) |
| Certificate | Commercial CA, not expired, covering the published name, **IIS and SMTP** assigned on internet-facing servers | [Certificate requirements](https://learn.microsoft.com/exchange/certificate-requirements), [Troubleshoot a hybrid deployment](https://learn.microsoft.com/exchange/hybrid-deployment/troubleshoot-a-hybrid-deployment) |
| MRSProxy | `MRSProxyEnabled = True` on the EWS virtual directory of every published server | [403 Forbidden article](https://learn.microsoft.com/troubleshoot/exchange/move-mailboxes/remote-server-returned-error-403-forbidden) |
| Devices in front | **No SSL offloading** for MRSProxy; use **SSL bridging** (re-encrypt) | [SSL offloading – MRSProxy](https://learn.microsoft.com/exchange/configuring-ssl-offloading-in-exchange-2013-exchange-2013-help) |
| Extended Protection | If enabled, a bridging device must present the **same certificate** as Exchange | [Extended Protection](https://learn.microsoft.com/exchange/plan-and-deploy/post-installation-tasks/security-best-practices/exchange-extended-protection) |
| TLS | TLS 1.2 enabled; .NET `SystemDefaultTlsVersions` and `SchUseStrongCrypto` explicitly `1` | [Exchange TLS best practices](https://learn.microsoft.com/exchange/plan-and-deploy/post-installation-tasks/security-best-practices/exchange-tls-configuration) |
| Firewall / IDS | No perimeter authentication on `/ews/mrsproxy.svc`; migration traffic must not be treated as a flood/DoS | [Hybrid migration troubleshooter](https://learn.microsoft.com/troubleshoot/exchange/move-or-migrate-mailboxes/troubleshoot-migration-issues-in-exchange-hybrid) |

---

## 2. Environment facts (as measured, 2026-10-15/16)

| Item | Value |
|---|---|
| Migration endpoint | `Hybrid Migration Endpoint - EWS (Default Web Site)` → RemoteServer `hybrid1.bancocarregosa.com`, user `LJC\administrator` |
| Routing domain | `bancocarregosa.mail.onmicrosoft.com` |
| Public IP of hybrid1 | 88.157.207.218 (not in internal DNS; internal lookups get the public IP) |
| Published servers ("CAS") | SAZCMXA (192.168.220.48), SAZCMXB (192.168.220.47) |
| Other Exchange servers | SMX100A, SMX100B |
| Exchange build | 15.2 (Build 2562.17) on all four, role Mailbox |
| Public certificate | `CN=Hybrid1.bancocarregosa.com`, Thawte TLS RSA CA G1 (DigiCert), thumbprint `A492CFBA446F9C1C8A159CE6CD6AEA9F0DD77D77`, **expires 2026-12-03**, one name only |
| Internal certificate | `CN=smx.ljc.local`, issuer LJC-CA-G2 (internal CA), thumbprint `6F9953A6AE7857C816F521FB9ABEF4B85E5D3AE4` |
| EWS on SAZCMXA | MRSProxy, WSSecurity, Windows, Basic, OAuth = True; Extended Protection = None |

---

## 3. The tools: what, where, as whom

| Script | Run on | Shell / account | What it gives you |
|---|---|---|---|
| `Invoke-HybridMoveCollection.ps1` + `Case-Settings.psd1` | **One** internet-facing Exchange server (the one the firewall NATs to) | **Elevated Exchange Management Shell** (Windows PowerShell 5.1), signed in as a **domain** admin (local admin on the Exchange servers and DCs) | **One run, one zip, no per-server RDP:** from this server and every Exchange server and DC it reaches (WinRM; event logs over RPC when WinRM is refused): config, NTLM/TLS/LAPS registry, local accounts, secure channel, IIS/HTTPERR/HttpProxy/EWS/MRS logs, Application/System/NTLM/LAPS events, Security sign-ins of the endpoint account; Exchange organisation config; path checks with *can it affect the sign-in?*; then runs the on-prem and DC scripts below. Optional `-TestCredential`: domain password vs the server's **local** account database. Settings (window, account, hybrid name) come from `Case-Settings.psd1` |
| `Invoke-HybridMailboxMove.ps1` | Admin workstation | Windows PowerShell 5.1 or PowerShell 7, Exchange Online admin | Start / Status / Errors / ApproveSkipped / Complete / Retry of one mailbox |
| `Get-HybridMoveCloudEvidence.ps1` | Admin workstation | Windows PowerShell 5.1 or PowerShell 7, Exchange Online admin | Endpoint test with **saved** credentials (and optional typed ones), batches, move reports, failures classified by layer, Exchange Online IP ranges CSV |
| `Get-HybridMoveOnPremEvidence.ps1` | **Every Exchange server the firewall publishes** for `<hybrid-name>` (each one) | **Elevated Exchange Management Shell** (Windows PowerShell 5.1), Exchange org admin + local admin | EWS/MRSProxy config, IIS auth/handler/app pool, certificates and what 0.0.0.0:443 really serves, live TLS + 401-challenge probe, optional NTLM sign-in probe, TLS registry, IIS mrsproxy log lines, HTTPERR, Schannel, 4625 |
| `Get-HybridMoveAuthEvidence.ps1` | **PDC emulator** (or any DC) | **Elevated** Windows PowerShell 5.1, Domain Admin / Event Log Readers | Endpoint account state (enabled, locked, expired, password last set), lockout policy, 4776 NTLM validation results (with the Exchange server that asked), 4740 lockouts, 4625 |
| `Get-HybridMoveVerdict.ps1` | Admin workstation (anywhere with the report folders) | Windows PowerShell 5.1 or 7, no rights needed | Reads the three reports and states **Firewall / Server / Account / Healthy / Inconclusive**, with evidence and fix |

**Output:** every script writes to `C:\Scripts\Cannes\<ScriptName>\…` on the machine where it runs: `Report-<timestamp>.html` (open this first), `Checks-<timestamp>.csv`, one CSV per data set, and a log in `…\Logs\`. Status values: **Fail**, **Warn**, **NotAssessed** (could not be measured – the reason is in the row), **Info**, **Pass**.

**Getting the scripts onto the servers:** copy the `.ps1` files to `C:\Scripts\` on each server. If Windows blocks them (copied from another machine), run `Unblock-File C:\Scripts\*.ps1` or start them with `powershell.exe -ExecutionPolicy Bypass -File …`.

**Times:** move reports and IIS logs are in **UTC**. The scripts take `-StartTime` / `-EndTime` in the **local** time of the machine they run on and convert (mind daylight-saving changes).

**Evidence folder:** create one folder per case and three sub-folders (names are only a convention – the verdict script recognises each report by its content):

```powershell
$evidence = '<Evidence>'
'Cloud', 'Exchange', 'DC', 'Verdict' | ForEach-Object { New-Item -ItemType Directory -Path (Join-Path $evidence $_) -Force | Out-Null }
```

| Sub-folder | Put here |
|---|---|
| `Cloud` | Cloud script output – automatic with `-EvidencePath '<Evidence>'` |
| `Exchange` | On-prem script output from **every** Exchange server – automatic with `-EvidencePath`; no per-server sub-folders needed, the server name is read from the report |
| `DC` | DC script output – automatic with `-EvidencePath` |
| `Verdict` | Verdict output – automatic when the verdict script gets `-EvidencePath` |

Every script accepts `-EvidencePath '<Evidence>'` and writes into its own sub-folder (`-OutputPath` is then ignored). **On the Exchange servers and the DC** the case folder on your workstation is usually not reachable: use a local folder there (e.g. `-EvidencePath 'C:\Scripts\Evidence'`) and afterwards copy that server's `Exchange` (or `DC`) folder – or a `.zip` of it – into `<Evidence>\Exchange` (or `<Evidence>\DC`). A UNC path to a share works too if the server can reach it.

---

## 4. Standard collection (do this every time a move fails)

**Shortest path (recommended):** fill `Case-Settings.psd1` (hybrid name, endpoint account, mailbox, window start). Then, on the published Exchange server, run `Invoke-HybridMoveCollection.ps1 -TestCredential` once (see `Server-Commands.txt`). It covers steps 2 and 3 below for all servers and writes `Evidence-<server>-<timestamp>.zip` next to the scripts. Run step 1 (cloud) from the workstation whenever needed, then run step 4 with the zip in `<Evidence>`. Use the individual steps below only for a server that the collection reports as *NotAssessed*.

### Step 1 – Exchange Online view (admin workstation, Windows PowerShell 5.1 or PowerShell 7)

```powershell
& 'C:\Scripts\Get-HybridMoveCloudEvidence.ps1' -EmailAddress '<user@domain>' -TestTypedCredential -EvidencePath '<Evidence>'
```

Check first that you are connected to the right tenant (`Get-ConnectionInformation`); if not, `Disconnect-ExchangeOnline -Confirm:$false` and run again.

Read in the report:
1. **Saved credentials work** – Pass/Fail of `Test-MigrationServerAvailability -Endpoint` (uses the password saved in the endpoint).
2. **Saved vs typed credentials** – Fail here means *the saved password is wrong or old*.
3. **Most common failure layer** per user – tells you which section of 5 to follow.
4. Note the time of the last failure (UTC) for the next steps.
5. Copy `ExoIpRanges-<ts>.csv` to `C:\Scripts\` on the Exchange servers (needed in step 2) and give it to the network team.

### Step 2 – On-premises view (on every published Exchange server, elevated EMS)

```powershell
& 'C:\Scripts\Get-HybridMoveOnPremEvidence.ps1' -HybridHostName '<hybrid-name>' -EndpointAccount '<DOMAIN\endpoint-account>' `
    -StartTime '<yyyy-MM-dd HH:mm>' -EndTime '<yyyy-MM-dd HH:mm>' -PublicIp '<public-ip>' `
    -ExoIpListPath 'C:\Scripts\ExoIpRanges-<ts>.csv' -TestCredential -EvidencePath 'C:\Scripts\Evidence'
```

`-PublicIp` and `-ExoIpListPath` are optional. Afterwards copy (or zip) `C:\Scripts\Evidence\Exchange` from each server into `<Evidence>\Exchange` (copying several servers into the same folder is fine).

Set the window around the failure times (local time). Read in the report:
1. **Certificate IIS serves on 0.0.0.0:443** and **Certificate served by <server>** – must be the public certificate covering the hybrid name.
2. **MRSProxy requests reached this server** – none on both servers = blocked before IIS (firewall/NAT/TLS); requests on one server only = the firewall sends to that one.
3. **IIS mrsproxy summary** – read the *Meaning* column. A normal sign-in is `401.0` (challenge) → `401.1` with Win32 `2148074254` / *No credentials are available in the security package* (NTLM handshake step) → `200`. Only **`401.1` with another Win32 code** (e.g. `2148074252` *The logon attempt failed*) is a **rejected sign-in**; the report counts only those. Lab test 2026-10-17: one rejection = Security 4625 *Wrong password* from an Exchange Online server (`DB7PR…`, 52.97.x.x).
4. **Source IPs seen by IIS** – Microsoft IPs = plain NAT; firewall/internal IPs = the firewall proxies or source-NATs.
5. **NTLM sign-in on <server>** (from `-TestCredential`) – 401 = the server rejects that account/password from inside too.

### Step 3 – Domain controller view (PDC emulator, elevated)

```powershell
& 'C:\Scripts\Get-HybridMoveAuthEvidence.ps1' -AccountName '<DOMAIN\endpoint-account>' -StartTime '<yyyy-MM-dd HH:mm>' -AllDomainControllers -EvidencePath 'C:\Scripts\Evidence'
```

Copy (or zip) `C:\Scripts\Evidence\DC` into `<Evidence>\DC`.

Read: **Locked out**, **Password last set**, **NTLM validation failures (4776)** (status meaning + which Exchange server asked), **Lockouts (4740)**.

### Step 4 – Verdict (admin workstation)

```powershell
& 'C:\Scripts\Get-HybridMoveVerdict.ps1' -EvidencePath '<Evidence>'
```

It finds every report under `<Evidence>` (folders and `.zip`), reads the Exchange server name from each report, keeps the newest run per server, and lists what it used in `Inputs-<ts>.csv`. Open `Verdict-<ts>.html`. How it decides (same logic as section 5):

| Exchange Online reports | CAS / DC show | Verdict |
|---|---|---|
| Network / firewall | No mrsproxy request on any CAS | **Firewall** (High) – blocked / NAT |
| Network / firewall | Requests on some CAS | **Firewall** (Medium) – routing, drops, timeouts |
| TLS / certificate | Every CAS serves the right certificate | **Firewall** (High) – device presents another certificate |
| TLS / certificate | A CAS serves a wrong certificate | **Server** (High) |
| Saved credentials fail, typed work | – | **Account** (High) – stale endpoint password |
| Authentication | IIS rejects + 4625/4776 wrong password / locked / expired | **Account** (High) |
| Authentication | Rejected on one CAS, same credentials OK on the other | **Server** (High) – configuration differs |
| Authentication | No CAS logged a rejection in the window | **Firewall** (Medium) – pre-authentication in front, or the window misses the failures |
| Authentication | No IIS rejection, inside probe OK, source IPs not Microsoft, Extended Protection on | **Firewall** (Medium) – bridging with another certificate |
| IIS/MRSProxy check fails on a CAS | – | **Server** (High) |
| Saved credentials work, no blocking finding | – | **Healthy** – retry the move |

Missing inputs give **Inconclusive** instead of a guess. Always check the *Time windows to compare* row: the on-prem window must cover the failure time (UTC) from Exchange Online.

### Step 5 – Fix and follow section 5

Apply the fix for the verdict (agreed with the bank). Fix one layer at a time; after each fix, re-run step 1 and retry the move.

---

## 5. Troubleshooting by layer

### A. Network / firewall
**Symptoms:** `timed out`, `unable to connect`, `could not be completed`, `connection was closed`; on-prem report shows **no mrsproxy requests** on either CAS.

| Check | Where |
|---|---|
| Are calls arriving at IIS at all, and on which server? | On-prem report: *MRSProxy requests reached this server* (both CAS) |
| Is the source an Exchange Online IP? | On-prem report: *Source IPs seen by IIS* (with `-ExoIpListPath`) |
| Firewall allow list matches Microsoft's list | Compare the rule with `ExoIpRanges-<ts>.csv`, rows `ServiceArea = Exchange`, port 443 (network team) |
| NAT/virtual-server target = the published Exchange servers, no pre-authentication, no SSL offloading, IDS/flood protection not throttling Microsoft IPs | Network team (the scripts cannot see the firewall) |
| Outbound 443 from Exchange to Exchange Online | On-prem report: *Outbound HTTPS to Exchange Online* |

**Fix (with the network team):** allow the Exchange Online ranges inbound 443 to `<public-ip>` → the published Exchange servers; remove perimeter auth on `/ews/mrsproxy.svc`; exclude Microsoft ranges from flood protection. Long-running sessions: a Microsoft Q&A answer (community guidance, not product documentation) suggests load-balancer idle timeouts of 30–60 minutes for MRSProxy.

### B. TLS / certificate
**Symptoms:** `Could not establish trust relationship for the SSL/TLS secure channel`.

| Check | Where |
|---|---|
| What IIS really serves on 443 | On-prem: *Certificate IIS serves on 0.0.0.0:443*, *http.sys SSL bindings* |
| What each server returns for SNI = hybrid name | On-prem: *TLS probe (SNI = hybrid name)* |
| What the firewall presents (if it terminates TLS) | Network team; or temporarily allow the Remote Connectivity Analyzer IPs (`72.152.19.128`, `72.152.19.129`, `4.237.88.238`, `4.237.88.239`) and run its EWS test |
| TLS 1.2 / Schannel errors | On-prem: *TLS registry*, *Schannel events* |

**Fix options (agree with the bank, change window, one server at a time):**
1. Public certificate on IIS on the published Exchange servers (`Enable-ExchangeCertificate -Thumbprint <public> -Services IIS`). **Impact:** IIS serves one certificate to *all* clients on that server; clients that use internal (e.g. `.local`) or other names not in the certificate get name-mismatch warnings unless every client URL is moved to a name in the certificate.
2. SSL **bridging** on the firewall with the public certificate (Exchange keeps the internal one). With Extended Protection enabled the certificates must match.
3. **Renew the public certificate before it expires** (this client: see section 2) and assign it to the same services/devices.

### C. Authentication (HTTP 401) – *current case*
**Symptoms:** `The HTTP request is unauthorized with client authentication scheme 'Negotiate'. The authentication header received from the server was 'Negotiate, NTLM, Basic …'`. The server offers Negotiate; the **sign-in** was rejected.

Work through in this order:

| # | Check | Where | Meaning |
|---|---|---|---|
| 1 | Saved credentials vs typed | Cloud report | Saved = Fail, typed = Pass → **saved password is old/wrong** |
| 2 | Account state, password last set | DC report | Locked / expired / recently changed |
| 3 | 4776 status on the DC | DC report | `0xC000006A` wrong password, `0xC0000234` locked, `0xC0000071` expired; *Workstation* = Exchange server that asked |
| 4 | IIS `401.1` + Win32 text, Security 4625 | On-prem report (each CAS) | Which server rejected, and why |
| 5 | NTLM sign-in probe from inside | On-prem report with `-TestCredential` | 401 from inside too → account/server side; OK inside but 401 from Exchange Online → path (firewall auth, Extended Protection + different certificate on a bridging device) |
| 6 | Extended Protection vs devices in front | On-prem: *Extended Protection on EWS* + network team | Not `None` and a device re-encrypts with another certificate → sign-in fails |
| 7 | Security 4625 with **Account Domain `-`** (no domain), logon type 3, NTLM, sub-status `0xC000006A` from an Exchange Online server | On-prem report: *Network sign-ins sent WITHOUT a domain*; verdict | The sign-in arrives without a domain, so Windows checks the name against the server's **local** accounts first; a local account with the same name (e.g. `Administrator`) makes the domain password fail ([Microsoft](https://learn.microsoft.com/troubleshoot/windows-server/windows-security/network-access-validation-algorithms)). **Fix:** use a dedicated domain account whose name does not exist locally on the Exchange servers |

**Fixes:**
- Saved password wrong → `Set-MigrationEndpoint -Identity '<endpoint name>' -Credentials (Get-Credential)` (enter `<DOMAIN\endpoint-account>` + current password).
- Locked → unlock in AD first, then update the endpoint.
- Then retry (section 6). Recommended afterwards: a **dedicated migration account** instead of a general admin account, so routine admin password changes do not break migrations.

### D. MRSProxy / IIS
| Symptom | Check (on-prem report) | Fix |
|---|---|---|
| `(403) Forbidden` | *MRSProxyEnabled on <server>*, ASP.NET 1309 "MRS proxy service is disabled" | `Set-WebServicesVirtualDirectory "<server>\EWS (Default Web Site)" -MRSProxyEnabled $true`, then `iisreset` ([article](https://learn.microsoft.com/troubleshoot/exchange/move-mailboxes/remote-server-returned-error-403-forbidden)) |
| `(405)` / "Exception has been thrown by the target" | *svc-Integrated handler mapping on EWS* | Restore the handler mapping ([article](https://learn.microsoft.com/troubleshoot/exchange/move-mailboxes/hybrid-deployment-errors)) |
| Intermittent 503 / failures | *EWS application pool* state, HTTPERR reasons | Investigate pool recycling / crashes |

### E. Capacity and stability
| Symptom | Where | Next |
|---|---|---|
| `maximum number of active MRS connections` | Cloud report layer *MRSProxy capacity* | Lower endpoint concurrency or raise the limit ([article](https://learn.microsoft.com/troubleshoot/exchange/move-mailboxes/mailbox-migration-reached-maximum-number)) |
| `TooManyTransientFailureRetries` | Cloud report layer *Job gave up* | The real cause is the most common failure next to it; fix that, then retry |
| `Connection_Dropped`, `Timer_*` | On-prem *HTTPERR summary* | Network drops/timeouts before IIS |

### F. Data (move runs but will not finish)
Data Consistency Score **Investigate** → review the *Skipped items* CSV, then `Invoke-HybridMailboxMove.ps1 -Action ApproveSkipped -Apply`. **Poor** → Microsoft Support ([article](https://learn.microsoft.com/exchange/mailbox-migration/track-prevent-data-loss-dcs)).

---

## 6. After a fix – retry and verify

```powershell
# Retry the failed user (Start-MigrationBatch on the existing batch)
& 'C:\Scripts\Invoke-HybridMailboxMove.ps1' -Action Retry  -EmailAddress '<user@domain>' -Apply
# 10–15 minutes later
& 'C:\Scripts\Invoke-HybridMailboxMove.ps1' -Action Errors -EmailAddress '<user@domain>'
& 'C:\Scripts\Invoke-HybridMailboxMove.ps1' -Action Status -EmailAddress '<user@domain>'
```

Success looks like: no new failures after the retry time, `PercentComplete` and `TotalArchiveSize` filled in, status moving to `Synced`.
If the same 401 returns after updating the endpoint password, the retried request may still carry the old one: remove the batch (`Remove-MigrationBatch`), wait until `Get-MigrationBatch` no longer finds it, and start again with a new `-BatchName`.

---

## 7. Escalating to Microsoft Support

Collect: the cloud report folder with `-IncludeVerboseDiagnostics` (the `MoveReport-UserNN-*.xml` files), the on-prem report folders from **every** published Exchange server, the DC report, and the output of Microsoft's **Exchange HealthChecker** (<https://aka.ms/ExchangeHealthChecker>, run on each Exchange server – download it yourself from Microsoft).

---

## 8. Current case – status on 2026-10-16

| When | Finding |
|---|---|
| 15 Oct | Batch `Onboard-MariaCandida` created (primary + archive, no auto-complete). Failed: **certificate trust** – IIS on SAZCMXA/B served `smx.ljc.local` (LJC-CA-G2); the public Hybrid1 certificate was assigned to SMTP only. |
| 16 Oct | Public Hybrid1 certificate assigned to IIS → TLS accepted. New failure: **HTTP 401 Negotiate** on `/EWS/mrsproxy.svc`. |
| 16 Oct | `Test-MigrationServerAvailability` with the **typed** `LJC\administrator` password = **Success**; the 401s continued until 14:14 UTC, then the job stopped (`TooManyTransientFailureRetries`, 114). Points to the **password saved in the endpoint**. |

| 19 Oct | New batch failed the same way (60 x 401, 16:08-16:40 local). SAZCMXA Security 4625: the migration job's sign-ins arrive as `-\administrator` (**no domain**) from Exchange Online server AM8PR04MB8004, sub-status 0xC000006A - checked against SAZCMXA's **local** Administrator. Saved and typed endpoint tests (with domain) succeed. **Cause found.** |

**Next actions**
1. Run step 1 (cloud) – confirm *Saved vs typed credentials*.
2. Run step 3 (DC) – confirm 4776 status `0xC000006A` / lockout / password last set.
3. Update the endpoint password, retry (section 6).
4. **Check internal Outlook/OWA** – IIS on SAZCMXA/B now serves the one-name Hybrid1 certificate; clients using `smx.ljc.local` may see warnings.
5. Plan the Hybrid1 renewal before **2026-12-03**.

---

## 9. What these tools cannot see

- The firewall / reverse proxy configuration, and what Exchange Online receives from the internet (only the cloud endpoint test and the Remote Connectivity Analyzer approach that).
- Logs on servers where the script was not run – run the on-prem script on **each** published Exchange server.
- Events that the audit policy does not record (no 4625/4776 ≠ no failures; the report says so as *Info*).
- Fine-grained password policies (only the default domain policy is read).
