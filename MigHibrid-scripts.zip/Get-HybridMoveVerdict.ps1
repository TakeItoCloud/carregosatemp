﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Reads the report folders of the hybrid-move evidence scripts and states where the problem is: Firewall, Server,
    Account, Healthy or Inconclusive - with the evidence and the fix. Writes an HTML + CSV verdict.

.DESCRIPTION
    Input = the run folders written by:
      Get-HybridMoveCloudEvidence.ps1   (what Exchange Online reports)
      Get-HybridMoveOnPremEvidence.ps1  (one run per Exchange server: what IIS received)
      Get-HybridMoveAuthEvidence.ps1    (what the domain controller decided)

    Easiest use: -EvidencePath <folder>. Put the run folders (or .zip files of them) anywhere under it - suggested
    sub-folders Cloud, Exchange and DC, but they are not required. The script finds every Checks-*.csv, unzips .zip
    files into its own run folder, recognises each report's type from its content, and takes the Exchange server name
    from the report itself (the on-prem script records the computer name on every row). Only the newest run per
    Exchange server, and the newest cloud and DC run, are used; older ones are listed in the log. No server or client
    names are needed.

    It compares the reports: if Exchange Online reports a failure that no Exchange server received, the cause is in
    between (firewall); if a server received it and rejected it, the cause is the server or the account.

    Read-only: only reads the evidence and writes its own report (and unzipped copies inside its own run folder).
    Missing inputs make the verdict Inconclusive rather than guessed. Check that the on-prem log windows cover the
    failure times shown by the cloud report (the verdict lists both).

.PARAMETER EvidencePath
    Root evidence folder holding the cloud, Exchange and DC runs (folders or .zip). Recommended.

.PARAMETER CloudReport
    Alternative to -EvidencePath: folder (or Checks-*.csv) from Get-HybridMoveCloudEvidence.ps1; a parent folder uses the newest run.

.PARAMETER OnPremReport
    Alternative to -EvidencePath: one or more folders (or Checks-*.csv) from Get-HybridMoveOnPremEvidence.ps1.

.PARAMETER AuthReport
    Alternative to -EvidencePath: folder (or Checks-*.csv) from Get-HybridMoveAuthEvidence.ps1.

.PARAMETER OutputPath
    Root output folder. Default C:\Scripts\Cannes; with -EvidencePath and no -OutputPath the default is <EvidencePath>\Verdict.
    Results go to <OutputPath>\Get-HybridMoveVerdict\<timestamp>\.

.EXAMPLE
    .\Get-HybridMoveVerdict.ps1 -EvidencePath <EvidenceFolder>
    Finds every report under the evidence folder (Cloud, Exchange, DC sub-folders or .zip files) and writes the verdict to <EvidenceFolder>\Verdict.

.EXAMPLE
    .\Get-HybridMoveVerdict.ps1 -CloudReport <cloud run folder> -OnPremReport <server run folder 1>, <server run folder 2>
    Explicit folders instead of an evidence folder; output to C:\Scripts\Cannes.

.OUTPUTS
    Verdict-<ts>.html, Verdict-<ts>.csv, Facts-Servers-<ts>.csv, Inputs-<ts>.csv (which runs were used); log in ...\Logs\.
    Exit codes: 0 verdict produced, 1 an input could not be read (verdict built from the rest), 2 could not run.

.NOTES
    Owner: Carlos Annes (TakeItToCloud)
    Version: 1.5.0
    Created: 2026-10-17
    Last updated: 2026-10-19
    Requires: Windows PowerShell 5.1 or PowerShell 7 (reads CSV only; no modules, no connection, no rights beyond reading the folders).
              Reads reports from evidence scripts on-prem 1.0.0+, cloud 1.0.0+, auth 1.0.0+.
#>
[CmdletBinding(DefaultParameterSetName = 'Evidence')]
param(
    [Parameter(Mandatory, ParameterSetName = 'Evidence')][string]$EvidencePath,
    [Parameter(Mandatory, ParameterSetName = 'Folders')][string]$CloudReport,
    [Parameter(ParameterSetName = 'Folders')][string[]]$OnPremReport,
    [Parameter(ParameterSetName = 'Folders')][string]$AuthReport,
    [string]$OutputPath = 'C:\Scripts\Cannes'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# With an evidence folder and no explicit -OutputPath, keep the verdict with the evidence.
if ($EvidencePath -and -not $PSBoundParameters.ContainsKey('OutputPath')) { $OutputPath = Join-Path $EvidencePath 'Verdict' }

# ---- Configuration --------------------------------------------------------------------------------
$ScriptName    = 'Get-HybridMoveVerdict'
$ScriptVersion = '1.5.0'
$Stamp         = Get-Date -Format 'yyyyMMdd-HHmmss'
$RunDir        = Join-Path (Join-Path $OutputPath $ScriptName) $Stamp
$LogDir        = Join-Path (Join-Path $OutputPath $ScriptName) 'Logs'
$LogFile       = Join-Path $LogDir "$ScriptName-$Stamp.log"
$StartRun      = Get-Date
$ExitCode      = 0
$Script:Verdicts = New-Object System.Collections.Generic.List[object]
$Script:InputErrors = 0
$Script:Unfinished = New-Object System.Collections.Generic.List[string]

# IIS sc-win32-status of the normal NTLM challenge step (not a rejection). Same value as the on-prem script.
$NtlmChallengeWin32 = '2148074254'

# Fix texts and references used by the rules (kept together so they can be updated in one place).
$Fix = @{
    FirewallBlock  = 'Network team: allow the Exchange Online IP ranges (ExoIpRanges CSV, ServiceArea = Exchange) inbound TCP 443 to the public IP of the hybrid name, NAT to the published CAS servers; no IDS/flood blocking of Microsoft ranges.'
    FirewallPath   = 'Network team: check NAT/pool members and health checks, idle timeout for long sessions, and that every published CAS receives traffic. HTTPERR on the CAS shows dropped connections.'
    FirewallCert   = 'Network team: pass TLS through to the CAS, or use SSL bridging presenting the SAME public certificate as IIS. SSL offloading is not supported for MRSProxy.'
    ServerCert     = 'Assign the public certificate that covers the hybrid name to IIS on that server (Enable-ExchangeCertificate -Services IIS) in an agreed window; check impact on clients that use other names.'
    PreAuth        = 'Network team: remove perimeter authentication / pre-authentication for /ews/mrsproxy.svc (Microsoft: pre-auth not supported for mailbox migrations). First confirm the on-prem log window covers the failure times.'
    Bridging       = 'Use the same certificate on the bridging device as on IIS, or align Extended Protection on EWS; with Extended Protection a device that re-encrypts with another certificate breaks NTLM sign-in.'
    SavedPassword  = "Update the password saved in the endpoint: Set-MigrationEndpoint -Identity '<endpoint>' -Credentials (Get-Credential), then retry the batch."
    Locked         = 'Unlock the endpoint account in AD, then update the endpoint password if it changed, then retry the batch.'
    Expired        = 'Reset the endpoint account password, update the endpoint (Set-MigrationEndpoint -Credentials), then retry.'
    ServerConfig   = 'Fix the failed IIS / MRSProxy items on that server (see its on-prem report), then retry.'
    ServerDiff     = 'Compare the two servers'' rows "IIS EWS authentication", "Extended Protection on EWS" and "EWS virtual directory" and make them identical.'
    Retry          = 'Retry the move (Invoke-HybridMailboxMove.ps1 -Action Retry -Apply) and check Errors/Status after 15 minutes.'
    NoDomain       = "Point the migration endpoint at a dedicated DOMAIN account whose name does not exist as a local account on the Exchange servers (not 'administrator'), with the Exchange admin rights the endpoint needs: Set-MigrationEndpoint -Identity '<endpoint>' -Credentials (Get-Credential) in DOMAIN\user format, then Test-MigrationServerAvailability -Endpoint '<endpoint>', then start a new batch."
}
$RefPorts = 'https://learn.microsoft.com/exchange/hybrid-deployment-prerequisites'

# ---- Helpers --------------------------------------------------------------------------------------
function Write-Log {
    <# .SYNOPSIS Writes one timestamped line to the log file and the console. #>
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidOverwritingBuiltInCmdlets', '', Justification = 'House rule names the helper Write-Log.')]
    param([ValidateSet('INFO', 'WARN', 'ERROR', 'DEBUG')][string]$Level = 'INFO', [Parameter(Mandatory)][string]$Message)
    $line = '{0} [{1}] {2}' -f (Get-Date -Format 'o'), $Level, $Message
    Add-Content -Path $LogFile -Value $line -Encoding UTF8
    Write-Information -MessageData $line -InformationAction Continue
}

function Write-ErrorDetail {
    <# .SYNOPSIS Logs a caught error with step, item, message, type, position and stack. #>
    param([Parameter(Mandatory)]$ErrorRecord, [Parameter(Mandatory)][string]$Step, [string]$Item = '')
    Write-Log ERROR "Step: $Step | Item: $Item"
    Write-Log ERROR "Message: $($ErrorRecord.Exception.Message)"
    Write-Log ERROR "Type: $($ErrorRecord.Exception.GetType().FullName)"
    Write-Log ERROR "Position: $($ErrorRecord.InvocationInfo.PositionMessage)"
    Write-Log ERROR "Stack: $($ErrorRecord.ScriptStackTrace)"
}

function Add-Verdict {
    <# .SYNOPSIS Adds one verdict row. Verdict: Firewall | Server | Account | Healthy | Inconclusive | Info. #>
    param([ValidateSet('Firewall', 'Server', 'Account', 'Healthy', 'Inconclusive', 'Info')][string]$Verdict, [ValidateSet('High', 'Medium', 'Low', '')][string]$Confidence, [string]$Finding, [string]$Evidence, [string]$Fix, [string]$Reference = '')
    $Script:Verdicts.Add([pscustomobject]@{ Verdict = $Verdict; Confidence = $Confidence; Finding = $Finding; Evidence = $Evidence; Fix = $Fix; Reference = $Reference })
    Write-Log INFO "VERDICT $Verdict ($Confidence): $Finding"
}

function Read-RunFolder {
    <# .SYNOPSIS Resolves a run folder (or its Checks CSV, or a parent folder -> newest run) and loads its Checks rows. #>
    param([Parameter(Mandatory)][string]$Path, [Parameter(Mandatory)][string]$Label)
    if (-not (Test-Path $Path)) { throw "$Label path not found: $Path" }
    $item = Get-Item $Path
    $checks = if ($item.PSIsContainer) {
        $direct = @(Get-ChildItem -Path $item.FullName -Filter 'Checks-*.csv' -File)
        if ($direct.Count) { $direct | Sort-Object LastWriteTime | Select-Object -Last 1 } else { Get-ChildItem -Path $item.FullName -Filter 'Checks-*.csv' -File -Recurse | Sort-Object LastWriteTime | Select-Object -Last 1 }
    } else { $item }
    if (-not $checks) { throw "$Label : no Checks-*.csv under $Path" }
    Write-Log INFO "$Label : $($checks.FullName)"
    [pscustomobject]@{ Dir = $checks.DirectoryName; Rows = @(Import-Csv -Path $checks.FullName) }
}

function Get-RunKind {
    <# .SYNOPSIS Recognises a report: Exchange (rows carry a Server column), Cloud or DC - from check and step names (also when steps failed), then from the script name in the path. #>
    param([object[]]$Rows, [string]$Path)
    if ($Rows -and $Rows.Count -gt 0) {
        if ($Rows[0].PSObject.Properties['Server']) { return 'Exchange' }
        if ($Rows[0].PSObject.Properties['Target'] -and $Rows[0].PSObject.Properties['Impact']) { return 'Collection' }
        $names = @($Rows | ForEach-Object { $_.Check; $_.Area })
        $cloud = 'Saved credentials work*', 'ExchangeRemoteMove endpoints', 'Users analysed', 'Migration endpoints', 'Endpoint test with SAVED credentials', 'Migration batches'
        $dc = 'Locked out', 'Where this runs', 'Lockout policy', 'Password last set', 'Domain and domain controllers', 'Account state', 'Domain password and lockout policy', 'Security events 4776 / 4740 / 4625'
        if ($names | Where-Object { $n = $_; @($cloud | Where-Object { $n -like $_ }).Count }) { return 'Cloud' }
        if ($names | Where-Object { $_ -in $dc }) { return 'DC' }
    }
    if ($Path -match 'Get-HybridMoveCloudEvidence') { return 'Cloud' }
    if ($Path -match 'Get-HybridMoveAuthEvidence') { return 'DC' }
    if ($Path -match 'Get-HybridMoveOnPremEvidence') { return 'Exchange' }
    if ($Path -match '\\Collection\\') { return 'Collection' }
    return 'Unknown'
}

function Get-RunStamp {
    <# .SYNOPSIS The yyyyMMdd-HHmmss stamp in a Checks file name (used to pick the newest run); falls back to the file time. #>
    param([IO.FileInfo]$File)
    if ($File.Name -match 'Checks-(\d{8}-\d{6})') { return [datetime]::ParseExact($Matches[1], 'yyyyMMdd-HHmmss', [Globalization.CultureInfo]::InvariantCulture) }
    return $File.LastWriteTime
}

function Find-EvidenceRun {
    <# .SYNOPSIS Finds every run under the evidence root (folders and .zip), classifies it, keeps the newest per Exchange server, newest cloud and DC. #>
    param([Parameter(Mandatory)][string]$Root)
    if (-not (Test-Path $Root -PathType Container)) { throw "Evidence folder not found: $Root" }
    $scan = New-Object System.Collections.Generic.List[string]; $scan.Add((Resolve-Path $Root).Path)
    $zips = @(Get-ChildItem -Path $Root -Filter '*.zip' -File -Recurse)
    foreach ($z in $zips) {
        $dest = Join-Path (Join-Path $RunDir 'Unzipped') ([IO.Path]::GetFileNameWithoutExtension($z.Name) -replace '[^\w.-]', '_')
        try { Expand-Archive -Path $z.FullName -DestinationPath $dest -Force; $scan.Add($dest); Write-Log INFO "Unzipped $($z.FullName) -> $dest" }
        catch { $Script:InputErrors++; Write-ErrorDetail -ErrorRecord $_ -Step 'Expand-Archive' -Item $z.FullName }
    }
    # Skip earlier output of this script (e.g. when -OutputPath is inside the evidence folder); this run's unzipped copies are scanned explicitly.
    $ownOutput = [IO.Path]::GetFullPath((Join-Path $OutputPath $ScriptName))
    $runs = foreach ($dir in $scan) {
        $files = @(Get-ChildItem -Path $dir -Filter 'Checks-*.csv' -File -Recurse | Where-Object { $dir -like "$ownOutput*" -or $_.FullName -notlike "$ownOutput*" })
        foreach ($f in $files) {
            try {
                $rows = @(Import-Csv -Path $f.FullName)
                $kind = Get-RunKind -Rows $rows -Path $f.FullName
                $server = if ($kind -eq 'Exchange') { ($rows | Where-Object { $_.Server } | Select-Object -First 1).Server } else { '' }
                [pscustomobject]@{ Kind = $kind; Server = $server; Stamp = Get-RunStamp $f; File = $f.FullName; Dir = $f.DirectoryName; Rows = $rows }
            } catch { $Script:InputErrors++; Write-ErrorDetail -ErrorRecord $_ -Step 'Read Checks file' -Item $f.FullName }
        }
    }
    $runs = @($runs)
    # A run is complete when its log has the closing "Exit code" line; a run folder without Checks never got that far.
    foreach ($r in $runs) {
        $stamp = if ($r.File -match 'Checks-(\d{8}-\d{6})') { $Matches[1] } else { '' }
        $logDir = Join-Path (Split-Path $r.Dir -Parent) 'Logs'
        $log = if ($stamp) { Get-ChildItem -Path $logDir -Filter "*$stamp.log" -File -ErrorAction SilentlyContinue | Select-Object -First 1 } else { $null }
        $complete = if (-not $log) { 'Unknown (no log)' } elseif (Select-String -Path $log.FullName -Pattern '\| Exit code' -Quiet) { 'Yes' } else { 'No' }
        $r | Add-Member -NotePropertyName Complete -NotePropertyValue $complete -Force
        if ($complete -eq 'No') { $Script:Unfinished.Add("$($r.Kind) $(if ($r.Server) { "$($r.Server) " })run $($r.Stamp.ToString('yyyy-MM-dd HH:mm')) (partial results): $($r.Dir)") }
    }
    foreach ($dir in $scan) {
        foreach ($d in @(Get-ChildItem -Path $dir -Directory -Recurse -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '(^|-)\d{8}-\d{6}$' -and $_.Parent.Name -like 'Get-HybridMove*Evidence' })) {
            if (-not (Get-ChildItem -Path $d.FullName -Filter 'Checks-*.csv' -File -ErrorAction SilentlyContinue)) {
                $Script:Unfinished.Add("$($d.Parent.Name) run $($d.Name) has NO results file (stopped before its first finding was saved): $($d.FullName)")
            }
        }
    }
    $use = New-Object System.Collections.Generic.List[object]
    foreach ($g in @($runs | Where-Object Kind -EQ 'Exchange' | Group-Object Server)) { $use.Add(($g.Group | Sort-Object Stamp | Select-Object -Last 1)) }
    foreach ($k in 'Cloud', 'DC', 'Collection') { $n = $runs | Where-Object Kind -EQ $k | Sort-Object Stamp | Select-Object -Last 1; if ($n) { $use.Add($n) } }
    $inventory = foreach ($r in $runs) {
        [pscustomobject]@{ Kind = $r.Kind; Server = $r.Server; RunTime = $r.Stamp.ToString('yyyy-MM-dd HH:mm:ss'); Complete = $r.Complete; Used = [bool]($use | Where-Object File -EQ $r.File); File = $r.File }
    }
    @($inventory) | Export-Csv -Path (Join-Path $RunDir "Inputs-$Stamp.csv") -NoTypeInformation -Encoding UTF8
    foreach ($i in @($inventory)) { Write-Log $(if ($i.Kind -eq 'Unknown') { 'WARN' } else { 'INFO' }) "Found $($i.Kind) run $(if ($i.Server) { "($($i.Server)) " })$($i.RunTime) used=$($i.Used) : $($i.File)" }
    $toRun = { param($r) if ($r) { [pscustomobject]@{ Dir = $r.Dir; Rows = $r.Rows } } else { $null } }
    [pscustomobject]@{
        Cloud    = & $toRun ($use | Where-Object Kind -EQ 'Cloud' | Select-Object -First 1)
        Dc       = & $toRun ($use | Where-Object Kind -EQ 'DC' | Select-Object -First 1)
        Exchange = @($use | Where-Object Kind -EQ 'Exchange' | ForEach-Object { & $toRun $_ })
        Collection = & $toRun ($use | Where-Object Kind -EQ 'Collection' | Select-Object -First 1)
    }
}

function Get-Row {
    <# .SYNOPSIS Check rows whose Check name matches a wildcard pattern. #>
    param($Run, [string]$Like)
    if (-not $Run) { return @() }
    return @($Run.Rows | Where-Object { $_.Check -like $Like })
}

function Get-DataCsv {
    <# .SYNOPSIS Loads a data CSV (by name prefix) from a run folder, or $null. #>
    param($Run, [string]$Prefix)
    $f = Get-ChildItem -Path $Run.Dir -Filter "$Prefix*.csv" -File -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($f) { return @(Import-Csv -Path $f.FullName) } else { return $null }
}

function Get-ServerFact {
    <# .SYNOPSIS Reduces one on-prem run to the facts the rules need. #>
    param($Run)
    $server = ($Run.Rows | Where-Object { $_.PSObject.Properties['Server'] -and $_.Server } | Select-Object -First 1).Server
    if (-not $server) { $server = Split-Path $Run.Dir -Leaf }
    $reachedRow = Get-Row $Run 'MRSProxy requests reached this server' | Select-Object -First 1
    $reached = if (-not $reachedRow) { 'NotAssessed' } elseif ($reachedRow.Status -eq 'Pass') { 'Yes' } elseif ($reachedRow.Status -eq 'Warn') { 'No' } else { 'NotAssessed' }

    # Sign-in results: prefer the IIS summary (works for every script version), fall back to the checks.
    $signed = 0; $rejected = 0; $reasons = ''
    $sum = Get-DataCsv $Run 'IIS-mrsproxy-summary'
    if ($sum) {
        foreach ($s in $sum) {
            if ($s.HttpStatus -eq '200.0') { $signed += [int]$s.Count }
            if ($s.HttpStatus -eq '401.1' -and $s.Result -notmatch "win32=$NtlmChallengeWin32") { $rejected += [int]$s.Count; $reasons += "$($s.Win32Text) x$($s.Count); " }
        }
    } else {
        $r = Get-Row $Run 'Sign-ins rejected on mrsproxy.svc*' | Select-Object -First 1
        if ($r -and $r.Detail -match '^(\d+) rejected') { $rejected = [int]$Matches[1]; $reasons = $r.Detail }
    }
    # Per Exchange Online source IP: which sources signed in and which were rejected (separates the move job from validation/tests).
    $okSrc = @(); $rejSrc = @(); $lastReject = ''
    $req = Get-DataCsv $Run 'IIS-mrsproxy-requests'
    if ($req) {
        foreach ($g in @($req | Group-Object 'c-ip')) {
            $ok = @($g.Group | Where-Object { $_.'sc-status' -eq '200' }).Count
            $rj = @($g.Group | Where-Object { $_.'sc-status' -eq '401' -and $_.'sc-substatus' -eq '1' -and $_.'sc-win32-status' -ne $NtlmChallengeWin32 })
            if ($ok) { $okSrc += "$($g.Name) ($ok OK)" }
            if ($rj.Count) { $rejSrc += "$($g.Name) ($($rj.Count) rejected, $($rj[0].DateTimeUtc) - $($rj[-1].DateTimeUtc) UTC)"; if ("$($rj[-1].DateTimeUtc)" -gt $lastReject) { $lastReject = "$($rj[-1].DateTimeUtc)" } }
        }
    }
    $cert = (Get-Row $Run 'Certificate IIS serves on 0.0.0.0:443' | Select-Object -First 1)
    $probe = @(Get-Row $Run 'NTLM sign-in on *')
    $probeState = if ($probe | Where-Object Status -EQ 'Fail') { 'Fail' } elseif ($probe | Where-Object Status -EQ 'Pass') { 'Pass' } else { 'NotAssessed' }
    $ep = (Get-Row $Run 'Extended Protection on EWS' | Select-Object -First 1)
    $epValue = if ($ep -and $ep.Detail -match 'ExtendedProtectionTokenChecking=(\w+)') { $Matches[1] } else { 'NotAssessed' }
    $src = (Get-Row $Run 'Source IPs seen by IIS' | Select-Object -First 1)
    $ipList = @(Get-Row $Run 'Exchange Online IPv4 ranges loaded').Count -gt 0
    $srcState = if (-not $src) { 'NotAssessed' } elseif ($src.Detail -match 'Not in Exchange Online ranges') { 'NotMicrosoft' } elseif ($ipList) { 'Microsoft' } else { 'NotAssessed (no -ExoIpListPath)' }
    $f4625 = (Get-Row $Run 'Failed logons*' | Where-Object Status -EQ 'Fail' | Select-Object -First 1)
    # Network sign-ins sent without a domain ("-\user") and rejected as wrong password (read from the 4625 data, works for every on-prem version).
    $nd = @(); $d4625 = Get-DataCsv $Run 'Security-4625-failed-logons'
    if ($d4625) { $nd = @($d4625 | Where-Object { $_.Account -like '-\*' -and "$($_.LogonType)" -eq '3' -and $_.SubStatus -eq '0xC000006A' }) }
    $ndText = if ($nd.Count) { "$($nd.Count) x '$(($nd[0].Account -split '\\')[-1])' with no domain from $((@($nd | ForEach-Object { "$($_.Workstation) $($_.SourceIp)" } | Sort-Object -Unique)) -join ', ')" } else { '' }
    $mrs = (Get-Row $Run "MRSProxyEnabled on $server" | Select-Object -First 1)
    $cfgFails = @($Run.Rows | Where-Object { $_.Status -eq 'Fail' -and $_.Area -in @('IIS', 'MRSProxy') }) | ForEach-Object { $_.Check }
    $window = (Get-Row $Run 'Log window' | Select-Object -First 1)
    [pscustomobject]@{
        Server = $server; Reached = $reached; SignedIn200 = $signed; RejectedSignIns = $rejected; RejectReasons = $reasons.TrimEnd('; ')
        SourcesSignedIn = ($okSrc -join '; '); SourcesRejected = ($rejSrc -join '; '); LastRejectUtc = $lastReject; NoDomainWrongPassword = $ndText
        CertServed = $(if ($cert) { $cert.Status } else { 'NotAssessed' }); MRSProxy = $(if ($mrs) { $mrs.Status } else { 'NotAssessed' })
        NtlmProbe = $probeState; ExtendedProtection = $epValue; SourceIps = $srcState
        Failed4625 = $(if ($f4625) { $f4625.Detail } else { '' }); ServerConfigFails = ($cfgFails -join '; ')
        LogWindow = $(if ($window) { $window.Detail } else { '' })
    }
}

function Export-HtmlVerdict {
    <# .SYNOPSIS Writes the verdict HTML: verdict table first, then the facts. #>
    param([string]$Path, [object[]]$Servers, $CloudFacts, $DcFacts)
    $enc = { param($s) [System.Net.WebUtility]::HtmlEncode("$s") }
    $order = @{ Firewall = 0; Server = 1; Account = 2; Inconclusive = 3; Info = 4; Healthy = 5 }
    $rows = foreach ($v in ($Script:Verdicts | Sort-Object { $order[$_.Verdict] })) {
        $ref = if ($v.Reference) { "<a href='$(& $enc $v.Reference)'>doc</a>" } else { '' }
        "<tr class='$($v.Verdict.ToLower())'><td>$(& $enc $v.Verdict)</td><td>$(& $enc $v.Confidence)</td><td>$(& $enc $v.Finding)</td><td>$(& $enc $v.Evidence)</td><td>$(& $enc $v.Fix)</td><td>$ref</td></tr>"
    }
    $srv = if ($Servers.Count) { ($Servers | ConvertTo-Html -Fragment) -join "`n" } else { '<p class="muted">No on-prem report given.</p>' }
    $cl = ($CloudFacts | ConvertTo-Html -Fragment -As List) -join "`n"
    $dc = if ($DcFacts) { ($DcFacts | ConvertTo-Html -Fragment -As List) -join "`n" } else { '<p class="muted">No DC report given.</p>' }
    $html = @"
<!doctype html><html><head><meta charset="utf-8"><title>Hybrid move verdict</title>
<style>
body{font-family:Segoe UI,Arial,sans-serif;margin:24px;color:#1b1b1b;background:#fff}
h2{margin-top:28px;border-bottom:1px solid #ddd;padding-bottom:4px}.muted{color:#666}
table{border-collapse:collapse;width:100%;font-size:12px}th,td{border:1px solid #ddd;padding:5px 7px;text-align:left;vertical-align:top}th{background:#f3f3f3}
tr.firewall td:first-child{background:#ffe5b4;font-weight:bold}tr.server td:first-child,tr.account td:first-child{background:#f8d7da;font-weight:bold}
tr.healthy td:first-child{background:#d1e7dd;font-weight:bold}tr.inconclusive td:first-child{background:#e2e3e5}tr.info td:first-child{background:#cfe2ff}
</style></head><body>
<h1>Hybrid move verdict</h1><p class="muted">$ScriptName $ScriptVersion | $($StartRun.ToString('yyyy-MM-dd HH:mm')) | Firewall = between Exchange Online and IIS; Server = Exchange/IIS on a CAS; Account = endpoint account or saved password</p>
<h2>Verdict</h2><table><tr><th>Verdict</th><th>Confidence</th><th>Finding</th><th>Evidence</th><th>Fix</th><th>Ref</th></tr>
$($rows -join "`n")
</table>
<h2>Facts per CAS server</h2><div style="overflow-x:auto">$srv</div>
<h2>Facts from Exchange Online</h2>$cl
<h2>Facts from the domain controller</h2>$dc
</body></html>
"@
    Set-Content -Path $Path -Value $html -Encoding UTF8
}

# ---- Main -----------------------------------------------------------------------------------------
foreach ($dir in @($RunDir, $LogDir)) {
    if (-not (Test-Path $dir)) { Write-Information "Folder $dir is missing - creating it." -InformationAction Continue; New-Item -ItemType Directory -Path $dir -Force | Out-Null }
}
Write-Information "Log file: $LogFile" -InformationAction Continue
Write-Log INFO "$ScriptName $ScriptVersion | Start $($StartRun.ToString('o')) | User $env:USERNAME | Computer $env:COMPUTERNAME | PS $($PSVersionTable.PSVersion)"
Write-Log INFO ("Parameters: " + (($PSBoundParameters.GetEnumerator() | ForEach-Object { "$($_.Key)=$($_.Value -join ',')" }) -join ' | '))

$servers = @(); $cloudFacts = $null; $dcFacts = $null
try {
    # ---- Load inputs ----------------------------------------------------------------------------
    $cloud = $null; $auth = $null; $onprem = @(); $collection = $null
    if ($PSCmdlet.ParameterSetName -eq 'Evidence') {
        $found = Find-EvidenceRun -Root $EvidencePath
        $cloud = $found.Cloud; $onprem = @($found.Exchange); $auth = $found.Dc; $collection = $found.Collection
    } else {
        try { $cloud = Read-RunFolder -Path $CloudReport -Label 'Cloud report' } catch { $Script:InputErrors++; Write-ErrorDetail -ErrorRecord $_ -Step 'Read cloud report' -Item $CloudReport }
        foreach ($p in @($OnPremReport | Where-Object { $_ })) {
            try { $onprem += Read-RunFolder -Path $p -Label 'On-prem report' } catch { $Script:InputErrors++; Write-ErrorDetail -ErrorRecord $_ -Step 'Read on-prem report' -Item $p }
        }
        if ($AuthReport) { try { $auth = Read-RunFolder -Path $AuthReport -Label 'DC report' } catch { $Script:InputErrors++; Write-ErrorDetail -ErrorRecord $_ -Step 'Read DC report' -Item $AuthReport } }
    }
    if (-not $cloud -and $onprem.Count -eq 0 -and -not $collection) { $ExitCode = 2; throw 'No readable input report.' }

    # ---- Facts: Exchange Online -----------------------------------------------------------------
    $savedRow = Get-Row $cloud 'Saved credentials work*' | Select-Object -First 1
    $savedState = if ($savedRow) { $savedRow.Status } else { 'NotAssessed' }
    $savedLayer = if ($savedRow -and $savedRow.Detail -match 'Layer: ([^.]+)\.') { $Matches[1] } else { '' }
    $svtRow = @(Get-Row $cloud 'Saved vs typed credentials*') + @(Get-Row $cloud 'Typed credentials*') | Select-Object -First 1
    $typedState = if (-not $svtRow) { 'NotAssessed' } elseif ($svtRow.Check -like 'Saved vs typed*' -and $svtRow.Status -eq 'Fail') { 'SavedWrong' } elseif ($svtRow.Status -eq 'Pass') { 'BothWork' } elseif ($savedState -eq 'Pass') { 'TypedWrong' } else { 'BothFail' }
    $layerRows = @(Get-Row $cloud 'Most common failure layer*')
    $layers = @($layerRows | ForEach-Object { if ($_.Detail -match '^(.+?) x\d+') { $Matches[1] } } | Sort-Object -Unique)
    if ($savedState -eq 'Fail' -and $savedLayer) { $layers = @(@($layers) + $savedLayer | Sort-Object -Unique) }
    $lastFail = @($layerRows | ForEach-Object { if ($_.Detail -match 'last at ([^.]+?)\.') { $Matches[1] } }) -join '; '
    $userStatus = @(Get-Row $cloud 'Migration status*' | ForEach-Object { "$($_.Check -replace '^Migration status ', ''): $($_.Status)" }) -join '; '
    $cloudFacts = [pscustomobject]@{ SavedCredentials = $savedState; SavedCredentialsLayer = $savedLayer; TypedVsSaved = $typedState
        FailureLayers = ($layers -join ', '); LastFailureUtc = $lastFail; Users = $userStatus }
    Write-Log INFO "Cloud facts: saved=$savedState typed=$typedState layers=$($layers -join ',')"

    # ---- Facts: CAS servers ---------------------------------------------------------------------
    $servers = @(foreach ($r in $onprem) { Get-ServerFact $r })
    $servers | Export-Csv -Path (Join-Path $RunDir "Facts-Servers-$Stamp.csv") -NoTypeInformation -Encoding UTF8
    foreach ($s in $servers) { Write-Log INFO "Server facts $($s.Server): reached=$($s.Reached) 200=$($s.SignedIn200) rejected=$($s.RejectedSignIns) cert=$($s.CertServed) probe=$($s.NtlmProbe) EP=$($s.ExtendedProtection) src=$($s.SourceIps)" }

    # ---- Facts: domain controller ---------------------------------------------------------------
    if ($auth) {
        $st = { param($like) $r = Get-Row $auth $like | Select-Object -First 1; if ($r) { $r } else { $null } }
        $lk = & $st 'Locked out'; $ex = & $st 'Password expired'; $en = & $st 'Enabled'; $pw = & $st 'Password last set'
        $v4776 = Get-Row $auth 'NTLM validation*' | Select-Object -First 1; $v4740 = Get-Row $auth 'Lockouts (4740)*' | Select-Object -First 1
        $dcFacts = [pscustomobject]@{ Enabled = $(if ($en) { $en.Status } else { 'NotAssessed' }); LockedOut = $(if ($lk) { $lk.Status } else { 'NotAssessed' })
            PasswordExpired = $(if ($ex) { $ex.Status } else { 'NotAssessed' }); PasswordLastSet = $(if ($pw) { $pw.Detail } else { '' })
            NtlmValidation4776 = $(if ($v4776) { "$($v4776.Status): $($v4776.Detail)" } else { 'NotAssessed' }); Lockouts4740 = $(if ($v4740) { "$($v4740.Status): $($v4740.Detail)" } else { 'NotAssessed' }) }
    }

    # ---- Rules ----------------------------------------------------------------------------------
    $net = $layers -contains 'Network / firewall'; $tls = $layers -contains 'TLS / certificate'; $authFail = $layers -contains 'Authentication'
    $reachedYes = @($servers | Where-Object Reached -EQ 'Yes'); $reachedNo = @($servers | Where-Object Reached -EQ 'No')
    $rejectSrv = @($servers | Where-Object { $_.RejectedSignIns -gt 0 })
    $acctDc = $dcFacts -and ($dcFacts.LockedOut -eq 'Fail' -or $dcFacts.PasswordExpired -eq 'Fail' -or $dcFacts.Enabled -eq 'Fail' -or $dcFacts.NtlmValidation4776 -like 'Fail*')
    $acct4625 = @($servers | Where-Object { $_.Failed4625 })

    if (-not $cloud) { Add-Verdict Inconclusive '' 'No Exchange Online report' 'Cloud report missing or unreadable.' 'Run Get-HybridMoveCloudEvidence.ps1 and pass its folder.' }
    if ($servers.Count -eq 0) { Add-Verdict Inconclusive '' 'No CAS report' 'Without the on-prem reports the firewall cannot be told apart from the server.' 'Run Get-HybridMoveOnPremEvidence.ps1 on every published CAS and pass the folders.' }

    # Network / firewall
    if ($net -and $servers.Count -and $reachedYes.Count -eq 0 -and $reachedNo.Count -eq $servers.Count) {
        Add-Verdict Firewall High 'Exchange Online cannot connect, and no MRSProxy request reached any CAS' "Cloud layer: Network / firewall (last $lastFail). IIS on $(($servers.Server) -join ', '): no /EWS/mrsproxy.svc requests in the log window." $Fix.FirewallBlock $RefPorts
    } elseif ($net -and $reachedYes.Count) {
        Add-Verdict Firewall Medium 'Connections fail or drop although some requests reach IIS' "Cloud layer: Network / firewall. Requests reached: $(($reachedYes.Server) -join ', '); not reached: $(@($reachedNo.Server) -join ', ')." $Fix.FirewallPath $RefPorts
    } elseif ($servers.Count -gt 1 -and $reachedYes.Count -and $reachedNo.Count) {
        Add-Verdict Info '' 'The firewall sends MRSProxy traffic to only some CAS servers' "Reached: $(($reachedYes.Server) -join ', '); none on: $(($reachedNo.Server) -join ', ')." 'Run the on-prem script with -StartTime/-EndTime covering the failures; troubleshoot the servers that receive traffic.'
    }

    # TLS / certificate
    $badCert = @($servers | Where-Object CertServed -EQ 'Fail')
    if ($badCert.Count) {
        Add-Verdict Server High "IIS serves a certificate Exchange Online does not trust on $(($badCert.Server) -join ', ')" 'On-prem: "Certificate IIS serves on 0.0.0.0:443" = Fail.' $Fix.ServerCert 'https://learn.microsoft.com/exchange/certificate-requirements'
    } elseif ($tls -and $servers.Count -and @($servers | Where-Object CertServed -EQ 'Pass').Count -eq $servers.Count) {
        Add-Verdict Firewall High 'Exchange Online rejects the certificate, but every CAS serves the right one' 'Cloud layer: TLS / certificate; on-prem: certificate served = Pass on all CAS. A device in front presents another certificate.' $Fix.FirewallCert 'https://learn.microsoft.com/exchange/configuring-ssl-offloading-in-exchange-2013-exchange-2013-help'
    }

    # Account / password
    if ($typedState -eq 'SavedWrong') {
        Add-Verdict Account High 'The password saved in the migration endpoint is wrong or old' 'Cloud: typed credentials work, saved credentials fail.' $Fix.SavedPassword 'https://learn.microsoft.com/powershell/module/exchangepowershell/test-migrationserveravailability'
    }
    if ($dcFacts -and $dcFacts.LockedOut -eq 'Fail') { Add-Verdict Account High 'Endpoint account is locked out' "DC: $($dcFacts.Lockouts4740)" $Fix.Locked }
    if ($dcFacts -and $dcFacts.PasswordExpired -eq 'Fail') { Add-Verdict Account High 'Endpoint account password expired' 'DC: PasswordExpired = True.' $Fix.Expired }
    if ($dcFacts -and $dcFacts.Enabled -eq 'Fail') { Add-Verdict Account High 'Endpoint account is disabled' 'DC: Enabled = False.' 'Enable the account (or use a dedicated migration account), update the endpoint, retry.' }

    # Sign-ins without a domain hit a LOCAL account with the same name (e.g. Administrator) -> "wrong password".
    $noDom = @($servers | Where-Object { $_.NoDomainWrongPassword })
    if ($noDom.Count) {
        Add-Verdict Account High 'Migration sign-ins arrive WITHOUT a domain and are checked against the server''s LOCAL account of the same name' "$(@($noDom | ForEach-Object { "$($_.Server): $($_.NoDomainWrongPassword)" }) -join ' | '). Security 4625: Account Domain '-', logon type 3, NTLM, sub-status 0xC000006A. Microsoft: when the domain sent is empty and the user exists in the local database, the local account is used and the attempt fails as wrong password. Other sign-ins with the domain (validation, tests) succeed." $Fix.NoDomain 'https://learn.microsoft.com/troubleshoot/windows-server/windows-security/network-access-validation-algorithms'
    }

    if (($rejectSrv.Count -or $acct4625.Count -or $acctDc) -and -not $noDom.Count) {
        $ev = "IIS rejected sign-ins: $(@($rejectSrv | ForEach-Object { "$($_.Server) x$($_.RejectedSignIns) ($($_.RejectReasons))" }) -join '; '). 4625: $(@($acct4625 | ForEach-Object { "$($_.Server): $($_.Failed4625)" }) -join '; '). DC 4776: $(if ($dcFacts) { $dcFacts.NtlmValidation4776 } else { 'not given' })."
        if ($typedState -eq 'TypedWrong' -and -not $authFail) {
            Add-Verdict Info Medium 'Rejected sign-ins match the typed-password test; the saved endpoint credentials work' $ev 'Nothing to fix for the migration; retype the password correctly for future tests.'
        } elseif ($authFail -or $savedState -eq 'Fail') {
            # Same credentials accepted on another CAS that receives traffic -> the account is unlikely; the server differs.
            $okElsewhere = @($reachedYes | Where-Object { $_.RejectedSignIns -eq 0 -and $_.SignedIn200 -gt 0 })
            if ($rejectSrv.Count -and $okElsewhere.Count -and -not $acctDc -and $typedState -ne 'SavedWrong') {
                Add-Verdict Server High "Sign-ins are rejected on $(($rejectSrv.Server) -join ', ') only" "$ev The same credentials sign in fine on $(($okElsewhere.Server) -join ', ')." $Fix.ServerDiff
                Add-Verdict Info Low 'Account unlikely' "Credentials work on $(($okElsewhere.Server) -join ', ') and the DC report shows no account problem." 'Only if the server comparison finds no difference: check the secure channel / DC used by the rejecting server.'
            } elseif ($savedState -eq 'Pass' -and $typedState -ne 'SavedWrong' -and -not $acctDc -and $dcFacts) {
                # Saved credentials work now and the DC shows a healthy account: "update the password" would be a guess.
                $src = @($rejectSrv | ForEach-Object { "$($_.Server): rejected from $($_.SourcesRejected); signed in from $(if ($_.SourcesSignedIn) { $_.SourcesSignedIn } else { 'none' })" }) -join ' | '
                Add-Verdict Inconclusive Medium "The move job's sign-ins were rejected, but the saved credentials and the account are fine now" "$ev $src. Saved endpoint credentials: Pass now. DC: enabled, not locked, not expired, password last set $($dcFacts.PasswordLastSet)" 'Not the firewall (calls reach IIS from Microsoft IPs and the NTLM handshake completes). Start a fresh batch and collect while it fails: DC script with -AllDomainControllers straight away (4776 shows the exact reason and which DC), on-prem script with -TestCredential. If the same pattern repeats with a healthy account, open a Microsoft case with the MoveReport XML.' 'https://learn.microsoft.com/troubleshoot/exchange/move-or-migrate-mailboxes/troubleshoot-migration-issues-in-exchange-hybrid'
            } else {
                Add-Verdict Account High 'Exchange Online sign-ins reach IIS and are rejected for the account' $ev $(if ($typedState -eq 'SavedWrong') { $Fix.SavedPassword } elseif ($ev -match 'locked') { $Fix.Locked } else { $Fix.SavedPassword }) 'https://learn.microsoft.com/troubleshoot/exchange/move-or-migrate-mailboxes/troubleshoot-migration-issues-in-exchange-hybrid'
            }
        } else {
            Add-Verdict Info Low 'Rejected sign-ins seen on the CAS / DC' $ev 'If they are not from your own tests, check which account and source sent them.'
        }
    } elseif ($authFail -and $servers.Count -and -not $noDom.Count) {
        $proxied = @($servers | Where-Object SourceIps -EQ 'NotMicrosoft').Count -gt 0
        $epOn = @($servers | Where-Object { $_.ExtendedProtection -notin @('None', 'NotAssessed') }).Count -gt 0
        $probeOk = @($servers | Where-Object NtlmProbe -EQ 'Pass').Count -gt 0
        if ($proxied -and $epOn -and $probeOk) {
            Add-Verdict Firewall Medium 'A device re-encrypts the traffic and Extended Protection rejects the sign-in' 'Cloud: Authentication; no IIS rejection logged; NTLM probe from inside = Pass; source IPs not Microsoft (proxy/bridging); Extended Protection on.' $Fix.Bridging 'https://learn.microsoft.com/exchange/plan-and-deploy/post-installation-tasks/security-best-practices/exchange-extended-protection'
        } else {
            Add-Verdict Firewall Medium 'Exchange Online gets 401, but no CAS logged a rejected sign-in' "Cloud: Authentication (last $lastFail). IIS on $(($servers.Server) -join ', '): no rejected sign-in in the log window ($(@($servers | ForEach-Object LogWindow | Select-Object -First 1))). Either the 401 comes from a device in front (pre-authentication) or the window misses the failures." $Fix.PreAuth $RefPorts
        }
    }

    # Server configuration
    foreach ($s in @($servers | Where-Object { $_.ServerConfigFails })) { Add-Verdict Server High "IIS / MRSProxy configuration fails on $($s.Server)" $s.ServerConfigFails $Fix.ServerConfig 'https://learn.microsoft.com/troubleshoot/exchange/move-mailboxes/remote-server-returned-error-403-forbidden' }
    foreach ($s in @($reachedYes | Where-Object { $_.MRSProxy -in @('Warn', 'Fail') })) { Add-Verdict Server High "MRSProxy is not enabled on $($s.Server), which receives the traffic" 'On-prem: MRSProxyEnabled not True.' "Set-WebServicesVirtualDirectory '$($s.Server)\EWS (Default Web Site)' -MRSProxyEnabled `$true; iisreset." 'https://learn.microsoft.com/troubleshoot/exchange/move-mailboxes/remote-server-returned-error-403-forbidden' }
    if ($dcFacts -and $dcFacts.PasswordLastSet -match 'Changed in the last') { Add-Verdict Info Low 'Endpoint account password changed recently' "DC: $($dcFacts.PasswordLastSet)" 'If the endpoint was saved before that date, update it (Set-MigrationEndpoint -Credentials).' }

    # One-run collection (Invoke-HybridMoveCollection.ps1): its Fail rows as context; the rules above decide.
    if ($collection) {
        foreach ($x in @($collection.Rows | Where-Object Status -EQ 'Fail')) { Add-Verdict Info Medium "Collection: $($x.Check) on $($x.Target)" $x.Detail $x.Impact $x.Reference }
        $na = @($collection.Rows | Where-Object Status -EQ 'NotAssessed')
        if ($na.Count) { Add-Verdict Info '' 'Collection: parts could not be collected' (($na | ForEach-Object { "$($_.Target): $($_.Check) - $($_.Detail)" }) -join ' | ') 'Run Invoke-HybridMoveCollection.ps1 -SkipRemote on those servers, or open WinRM / remote event log from the collecting server.' }
    }

    # Overall
    # An evidence-based Inconclusive (it has a confidence) also blocks 'Healthy'; missing-input rows (no confidence) do not.
    $problems = @($Script:Verdicts | Where-Object { $_.Verdict -in @('Firewall', 'Server', 'Account') -or ($_.Verdict -eq 'Inconclusive' -and $_.Confidence) })
    if ($problems.Count -eq 0) {
        if ($savedState -eq 'Pass') {
            Add-Verdict Healthy High 'Exchange Online reaches MRSProxy and signs in with the saved credentials' "Cloud: saved credentials = Pass$(if ($layers.Count) { "; earlier failures: $($layers -join ', ') (last $lastFail) are not reproduced now" }). $(if ($reachedYes.Count) { "IIS on $(($reachedYes.Server) -join ', '): $(($reachedYes | Measure-Object SignedIn200 -Sum).Sum) successful sign-in(s)." })" $Fix.Retry
        } else {
            Add-Verdict Inconclusive '' 'No rule matched with the evidence given' "Saved credentials: $savedState; layers: $($layers -join ', '); CAS reports: $($servers.Count); DC report: $([bool]$dcFacts)." 'Run the missing reports and make sure the on-prem log window covers the failure times.'
        }
    }
    foreach ($u in $Script:Unfinished) { Add-Verdict Inconclusive '' 'A run did not finish' $u 'Run that script again and let it end (the log ends with an Exit code line). From the 1.1.0 scripts on, findings are saved after every step, so an interrupted run still counts.' }
    Add-Verdict Info '' 'Time windows to compare' "Exchange Online last failure (UTC): $(if ($lastFail) { $lastFail } else { 'none listed' }). On-prem windows: $(@($servers | ForEach-Object { "$($_.Server): $($_.LogWindow)" }) -join ' | ')" 'If the windows do not cover the failure time, re-run the on-prem script with -StartTime/-EndTime around it.'
}
catch {
    Write-ErrorDetail -ErrorRecord $_ -Step 'Fatal'
    if ($ExitCode -eq 0) { $ExitCode = 2 }
}
finally {
    try {
        $Script:Verdicts | Export-Csv -Path (Join-Path $RunDir "Verdict-$Stamp.csv") -NoTypeInformation -Encoding UTF8
        $html = Join-Path $RunDir "Verdict-$Stamp.html"
        Export-HtmlVerdict -Path $html -Servers $servers -CloudFacts $cloudFacts -DcFacts $dcFacts
        Write-Log INFO "HTML verdict: $html"
    } catch { Write-ErrorDetail -ErrorRecord $_ -Step 'Write report'; if ($ExitCode -eq 0) { $ExitCode = 1 } }
    if ($ExitCode -eq 0 -and $Script:InputErrors -gt 0) { $ExitCode = 1 }
    $end = Get-Date
    Write-Log INFO ("End $($end.ToString('o')) | Duration $([int]($end - $StartRun).TotalSeconds)s | verdict rows $($Script:Verdicts.Count) | " + (($Script:Verdicts | Group-Object Verdict | ForEach-Object { "$($_.Name) $($_.Count)" }) -join ', ') + " | input errors $($Script:InputErrors) | Exit code $ExitCode")
    Write-Information "Log file: $LogFile" -InformationAction Continue
}
$summary = ($Script:Verdicts | Format-Table Verdict, Confidence, Finding -AutoSize | Out-String -Width 200).TrimEnd()
Write-Information -MessageData $summary -InformationAction Continue
exit $ExitCode
