﻿#Requires -Version 5.1
<#
.SYNOPSIS
    One-run on-premises evidence collection for hybrid mailbox move problems: configuration, events and logs from this
    server and from every other Exchange server and domain controller it can reach, in one zip for offline analysis.

.DESCRIPTION
    Run ONCE on the internet-facing Exchange server (CAS) in an elevated Exchange Management Shell, signed in with a
    domain account that is admin on the Exchange servers and DCs. Settings come from Case-Settings.psd1 next to the
    script (no typing); command-line parameters override them. At most ONE password prompt (-TestCredential).

    What it collects
      Every server (this one in-process; the others through WinRM - PowerShell remoting):
        system and patch level, IP addresses, time service, local accounts and local Administrators group,
        LAPS policy and LAPS log, LSA / NTLM / Netlogon / SCHANNEL / .NET TLS registry, secure channel (nltest),
        http.sys certificate bindings, IIS EWS authentication config, IIS logs for /EWS/, /Autodiscover/ and
        mrsproxy (filtered lines, or full files with -FullIisLogs), HTTPERR logs, Exchange HttpProxy / EWS / MRS logs,
        event logs in the time window: Application and System (errors and warnings), NTLM and LAPS operational logs,
        Security sign-in events for the endpoint account (4624, 4625, 4648, 4740, 4767, 4768, 4771, 4776).
      From this server, for the whole organisation (Exchange Management Shell, read-only Get-* cmdlets):
        servers, virtual directories, certificates, hybrid / OAuth / federation configuration, connectors,
        throttling, setting overrides, and the migrating mailbox (Case-Settings MigratingMailbox).
      Path checks from this server to every target: TCP ports, WinRM, remote event log, admin share (\\server\c$),
        LDAP - each failure with whether it can affect the migration sign-in.
      Analysis: runs Get-HybridMoveOnPremEvidence.ps1 (this server) and Get-HybridMoveAuthEvidence.ps1 (all DCs)
        when they sit next to this script, so Get-HybridMoveVerdict.ps1 can use the result.

    When WinRM to a server fails, events are still read over the remote event log service (RPC) and logs over the
    admin share when those work; what could not be read is listed as NotAssessed with the reason.

    Changes nothing in Exchange, IIS, Windows or AD. Writes only evidence: its own output folder, and on each remote
    server a temporary folder under C:\Windows\Temp that it zips, copies back and deletes. No passwords are logged.

    Sources (read 2026-10-19):
      https://learn.microsoft.com/exchange/hybrid-deployment-prerequisites
      https://learn.microsoft.com/troubleshoot/windows-server/windows-security/network-access-validation-algorithms
      https://learn.microsoft.com/troubleshoot/windows-server/windows-security/ntlm-user-authentication
      https://learn.microsoft.com/powershell/module/microsoft.powershell.management/test-computersecurechannel
      https://learn.microsoft.com/windows-server/identity/laps/laps-management-policy-settings
      https://learn.microsoft.com/windows-server/identity/laps/laps-technical-reference

.PARAMETER SettingsPath
    Case settings file. Default: Case-Settings.psd1 next to this script.

.PARAMETER HybridHostName
    Public MRSProxy name (endpoint RemoteServer). Overrides the settings file.

.PARAMETER EndpointAccount
    Endpoint account (DOMAIN\user). Overrides the settings file.

.PARAMETER MigratingMailbox
    Mailbox being migrated (for on-prem mailbox details). Overrides the settings file.

.PARAMETER PublicIp
    Public IP of the hybrid name. Overrides the settings file.

.PARAMETER StartTime
    Start of the time window (local). Overrides the settings file.

.PARAMETER EndTime
    End of the time window (local). Default: now.

.PARAMETER ComputerName
    Collect only from these servers (plus this one). Default: every Exchange server and every DC.

.PARAMETER SkipRemote
    Collect from this server only.

.PARAMETER SkipAnalysis
    Do not run Get-HybridMoveOnPremEvidence.ps1 / Get-HybridMoveAuthEvidence.ps1.

.PARAMETER FullIisLogs
    Copy whole IIS log files of the window instead of the /EWS/, /Autodiscover/ and mrsproxy lines (can be large).

.PARAMETER MaxLogMB
    Size cap per server for copied log files (IIS, HTTPERR, Exchange logs). Default 300.

.PARAMETER MaxEvents
    Maximum events read per event log per server. Default 5000.

.PARAMETER TestCredential
    One password prompt: checks the endpoint account's DOMAIN password against this server's LOCAL account database
    and against the domain (shows whether sign-ins that arrive without a domain can succeed here).

.PARAMETER EvidencePath
    Case evidence folder. Default: Evidence next to this script. Results go to <EvidencePath>\Collection\...

.EXAMPLE
    .\Invoke-HybridMoveCollection.ps1
    Everything, with the values from Case-Settings.psd1.

.EXAMPLE
    .\Invoke-HybridMoveCollection.ps1 -StartTime '2026-10-19 20:40' -TestCredential -FullIisLogs
    Same with an explicit window, the credential check and full IIS log files.

.OUTPUTS
    <EvidencePath>\Collection\<SERVER>-<ts>\  Report-<ts>.html, Checks-<ts>.csv, Targets-<ts>.csv,
      Servers\<name>\ (per server), Exchange-Org\ (organisation config as .xml and .txt).
    Zip of the whole evidence folder next to it: Evidence-<SERVER>-<ts>.zip. Log in <EvidencePath>\Collection\Logs\.
    Exit codes: 0 everything collected, 1 something could not be collected (see NotAssessed rows), 2 could not run.

.NOTES
    Owner: Carlos Annes (TakeItToCloud)
    Version: 1.0.0
    Created: 2026-10-19
    Last updated: 2026-10-19
    Requires: Windows PowerShell 5.1 (the Exchange Management Shell on the Exchange server is 5.1), Exchange
              Management Shell, elevated session, a domain account that is local admin on the targets (WinRM and
              Security log), WinRM enabled on the targets for the full remote collection. Output path: the case
              evidence folder (-EvidencePath), as agreed for this case layout, instead of C:\Scripts\Cannes.
#>
[CmdletBinding()]
param(
    [string]$SettingsPath,
    [string]$HybridHostName,
    [ValidatePattern('^[^\\]+\\[^\\]+$')][string]$EndpointAccount,
    [string]$MigratingMailbox,
    [string]$PublicIp,
    [datetime]$StartTime,
    [datetime]$EndTime = (Get-Date),
    [string[]]$ComputerName,
    [switch]$SkipRemote,
    [switch]$SkipAnalysis,
    [switch]$FullIisLogs,
    [ValidateRange(10, 10000)][int]$MaxLogMB = 300,
    [ValidateRange(100, 100000)][int]$MaxEvents = 5000,
    [switch]$TestCredential,
    [string]$EvidencePath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
# Windows PowerShell 5.1 leaves $PSScriptRoot empty in param() defaults when run with -File: resolve here.
$ScriptDir = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
if (-not $SettingsPath) { $SettingsPath = Join-Path $ScriptDir 'Case-Settings.psd1' }
if (-not $EvidencePath) { $EvidencePath = Join-Path $ScriptDir 'Evidence' }

# ---- Configuration --------------------------------------------------------------------------------
$ScriptName    = 'Invoke-HybridMoveCollection'
$ScriptVersion = '1.0.0'
$Stamp         = Get-Date -Format 'yyyyMMdd-HHmmss'
$Root          = Join-Path $EvidencePath 'Collection'
$RunDir        = Join-Path $Root "$($env:COMPUTERNAME)-$Stamp"
$LogDir        = Join-Path $Root 'Logs'
$LogFile       = Join-Path $LogDir "$ScriptName-$($env:COMPUTERNAME)-$Stamp.log"
$StartRun      = Get-Date
$ExitCode      = 0
$Script:Checks = New-Object System.Collections.Generic.List[object]
$Script:Partial = 0

# Ports tested from this server; Impact says whether a failure can explain a sign-in (401) failure of the migration.
$PortTable = @(
    @{ Role = 'DC'; Port = 53;   Use = 'DNS';                         Impact = 'Name resolution; a failure breaks much more than the migration.' }
    @{ Role = 'DC'; Port = 88;   Use = 'Kerberos';                    Impact = 'Not used by Exchange Online''s NTLM sign-in to MRSProxy.' }
    @{ Role = 'DC'; Port = 135;  Use = 'RPC endpoint mapper (Netlogon, remote event log)'; Impact = 'Netlogon RPC is how domain NTLM sign-ins reach a DC; the decisive check is the secure channel test.' }
    @{ Role = 'DC'; Port = 389;  Use = 'LDAP';                        Impact = 'Exchange needs LDAP to DCs; a failure would break Exchange widely.' }
    @{ Role = 'DC'; Port = 445;  Use = 'SMB (\\dc\c$, SYSVOL)';       Impact = 'Explains a failing \\dc\c$; on its own it does not explain the 401 while the secure channel test passes.' }
    @{ Role = 'DC'; Port = 3268; Use = 'Global catalog';              Impact = 'Exchange directory lookups; a failure breaks Exchange widely.' }
    @{ Role = 'DC'; Port = 5985; Use = 'WinRM (remote collection)';   Impact = 'Only affects this collection, not the migration.' }
    @{ Role = 'Exchange'; Port = 443;  Use = 'HTTPS front end';       Impact = 'Client and proxy traffic between Exchange servers.' }
    @{ Role = 'Exchange'; Port = 444;  Use = 'HTTPS back end (front end proxies requests to the mailbox servers)'; Impact = 'If blocked, a move fails AFTER sign-in, not with 401.' }
    @{ Role = 'Exchange'; Port = 445;  Use = 'SMB (\\server\c$)';     Impact = 'Only affects copying logs; not used by the migration.' }
    @{ Role = 'Exchange'; Port = 5985; Use = 'WinRM (remote collection, Exchange remote PowerShell)'; Impact = 'Only affects this collection.' }
)

# Organisation configuration exported from the Exchange Management Shell (read-only Get-* cmdlets).
$OrgExports = [ordered]@{
    'ExchangeServer'               = { Get-ExchangeServer -ErrorAction Stop }
    'ClientAccessService'          = { Get-ClientAccessService -ErrorAction Stop }
    'WebServicesVirtualDirectory'  = { foreach ($s in Get-ExchangeServer -ErrorAction Stop) { try { Get-WebServicesVirtualDirectory -Server $s.Name -ErrorAction Stop } catch { Get-WebServicesVirtualDirectory -Server $s.Name -ADPropertiesOnly -ErrorAction Stop } } }
    'AutodiscoverVirtualDirectory' = { foreach ($s in Get-ExchangeServer -ErrorAction Stop) { try { Get-AutodiscoverVirtualDirectory -Server $s.Name -ErrorAction Stop } catch { Get-AutodiscoverVirtualDirectory -Server $s.Name -ADPropertiesOnly -ErrorAction Stop } } }
    'OwaVirtualDirectory'          = { Get-OwaVirtualDirectory -ADPropertiesOnly -ErrorAction Stop }
    'EcpVirtualDirectory'          = { Get-EcpVirtualDirectory -ADPropertiesOnly -ErrorAction Stop }
    'MapiVirtualDirectory'         = { Get-MapiVirtualDirectory -ADPropertiesOnly -ErrorAction Stop }
    'OabVirtualDirectory'          = { Get-OabVirtualDirectory -ADPropertiesOnly -ErrorAction Stop }
    'ActiveSyncVirtualDirectory'   = { Get-ActiveSyncVirtualDirectory -ADPropertiesOnly -ErrorAction Stop }
    'OutlookAnywhere'              = { Get-OutlookAnywhere -ADPropertiesOnly -ErrorAction Stop }
    'ExchangeCertificate'          = { foreach ($s in Get-ExchangeServer -ErrorAction Stop) { try { Get-ExchangeCertificate -Server $s.Name -ErrorAction Stop } catch { Write-Log WARN "ExchangeCertificate $($s.Name): $($_.Exception.Message)" } } }
    'HybridConfiguration'          = { Get-HybridConfiguration -ErrorAction Stop }
    'OrganizationConfig'           = { Get-OrganizationConfig -ErrorAction Stop }
    'AuthConfig'                   = { Get-AuthConfig -ErrorAction Stop }
    'AuthServer'                   = { Get-AuthServer -ErrorAction Stop }
    'PartnerApplication'           = { Get-PartnerApplication -ErrorAction Stop }
    'IntraOrganizationConnector'   = { Get-IntraOrganizationConnector -ErrorAction Stop }
    'OrganizationRelationship'     = { Get-OrganizationRelationship -ErrorAction Stop }
    'FederationTrust'              = { Get-FederationTrust -ErrorAction Stop }
    'SendConnector'                = { Get-SendConnector -ErrorAction Stop }
    'ReceiveConnector'             = { Get-ReceiveConnector -ErrorAction Stop }
    'TransportConfig'              = { Get-TransportConfig -ErrorAction Stop }
    'ThrottlingPolicy'             = { Get-ThrottlingPolicy -ErrorAction Stop }
    'SettingOverride'              = { Get-SettingOverride -ErrorAction Stop }
    'MailboxDatabase'              = { Get-MailboxDatabase -ErrorAction Stop }
    'MigratingMailbox'             = { if ($Script:Cfg.MigratingMailbox) { Get-Mailbox -Identity $Script:Cfg.MigratingMailbox -ErrorAction Stop } }
    'MigratingMailboxStatistics'   = { if ($Script:Cfg.MigratingMailbox) { Get-MailboxStatistics -Identity $Script:Cfg.MigratingMailbox -ErrorAction Stop; Get-MailboxStatistics -Identity $Script:Cfg.MigratingMailbox -Archive -ErrorAction Stop } }
}

# ---- Per-server collector (runs in-process here, and through WinRM on the other servers) ----------
$Collector = {
    param([string]$OutDir, [datetime]$From, [datetime]$To, [string[]]$Accounts, [bool]$IsDc, [int]$CapMB, [int]$MaxEv, [bool]$FullIis)
    $ErrorActionPreference = 'Stop'
    $errs = New-Object System.Collections.Generic.List[string]; $done = New-Object System.Collections.Generic.List[string]
    # Shared by reference: $script: in a scriptblock means the caller's script (or the remote global scope), not this block.
    $state = @{ Bytes = [long]0; Skipped = 0; CapBytes = [long]$CapMB * 1MB; MaxEvents = $MaxEv }
    New-Item -ItemType Directory -Path $OutDir -Force | Out-Null
    function Save-Csv { param($Name, $Rows) try { @($Rows) | Export-Csv -Path (Join-Path $OutDir "$Name.csv") -NoTypeInformation -Encoding UTF8; $done.Add($Name) } catch { $errs.Add("$Name : $($_.Exception.Message)") } }
    function Save-Text { param($Name, $Block) try { (& $Block 2>&1 | Out-String -Width 4096) | Set-Content -Path (Join-Path $OutDir "$Name.txt") -Encoding UTF8; $done.Add($Name) } catch { $errs.Add("$Name : $($_.Exception.Message)") } }
    function Get-RegValue { param([string[]]$Keys) foreach ($k in $Keys) { if (Test-Path $k) { foreach ($sub in @(Get-Item $k) + @(Get-ChildItem $k -Recurse -ErrorAction SilentlyContinue)) { foreach ($n in $sub.GetValueNames()) { [pscustomobject]@{ Key = $sub.Name; Name = $n; Value = "$($sub.GetValue($n))" } } } } else { [pscustomobject]@{ Key = $k; Name = '(key not present)'; Value = '' } } } }
    function Convert-Ev { param($E) $d = ''; try { $x = [xml]$E.ToXml(); $d = (@($x.Event.EventData.Data | ForEach-Object { "$($_.Name)=$($_.InnerText)" }) -join '; ') } catch { $d = '' }
        $m = "$($E.Message)" -replace '\s+', ' '; [pscustomobject]@{ TimeCreated = $E.TimeCreated.ToString('yyyy-MM-dd HH:mm:ss'); Id = $E.Id; Provider = $E.ProviderName; Level = $E.LevelDisplayName; Data = $d; Message = $m.Substring(0, [Math]::Min(2000, $m.Length)) } }
    function Read-Log { param($Name, [hashtable]$Filter, [string]$XPath, [string]$LogName)
        try {
            $ev = if ($XPath) { @(Get-WinEvent -LogName $LogName -FilterXPath $XPath -MaxEvents $state.MaxEvents -ErrorAction Stop) } else { @(Get-WinEvent -FilterHashtable $Filter -MaxEvents $state.MaxEvents -ErrorAction Stop) }
            Save-Csv $Name ($ev | ForEach-Object { Convert-Ev $_ })
        } catch { if ($_.Exception.Message -match 'No events were found') { Save-Csv $Name @() } else { $errs.Add("$Name : $($_.Exception.Message)") } } }
    function Copy-Capped { param($Files, $Dest)
        New-Item -ItemType Directory -Path $Dest -Force | Out-Null
        foreach ($f in $Files) { if (($state.Bytes + $f.Length) -gt $state.CapBytes) { $state.Skipped++; continue }; Copy-Item -Path $f.FullName -Destination $Dest -Force; $state.Bytes += $f.Length } }

    # System, patches, network, time
    try { $os = Get-CimInstance Win32_OperatingSystem; $cs = Get-CimInstance Win32_ComputerSystem
        Save-Csv 'system' ([pscustomobject]@{ Computer = $env:COMPUTERNAME; Domain = $cs.Domain; Role = $(if ($IsDc) { 'DomainController' } else { 'Member' }); OS = $os.Caption; Version = $os.Version; LastBoot = $os.LastBootUpTime; LocalTime = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'); TimeZone = (Get-TimeZone).Id; PSVersion = "$($PSVersionTable.PSVersion)" }) } catch { $errs.Add("system : $($_.Exception.Message)") }
    try { Save-Csv 'ip-addresses' (Get-NetIPAddress -AddressFamily IPv4 | Select-Object InterfaceAlias, IPAddress, PrefixLength) } catch { $errs.Add("ip-addresses : $($_.Exception.Message)") }
    try { Save-Csv 'hotfixes-120-days' (Get-HotFix | Where-Object { $_.InstalledOn -and $_.InstalledOn -ge (Get-Date).AddDays(-120) } | Select-Object HotFixID, Description, InstalledOn, InstalledBy) } catch { $errs.Add("hotfixes : $($_.Exception.Message)") }
    Save-Text 'w32tm-status' { w32tm /query /status }

    # Local accounts (not on DCs: they have no local account database in use)
    if (-not $IsDc) {
        try { Save-Csv 'local-users' (Get-LocalUser | Select-Object Name, Enabled, @{n = 'SID'; e = { "$($_.SID)" } }, PasswordLastSet, LastLogon, PasswordExpires, Description) } catch { $errs.Add("local-users : $($_.Exception.Message)") }
        try { Save-Csv 'local-administrators' (Get-LocalGroupMember -SID 'S-1-5-32-544' | Select-Object Name, ObjectClass, PrincipalSource, @{n = 'SID'; e = { "$($_.SID)" } }) } catch { $errs.Add("local-administrators : $($_.Exception.Message)") }
    }

    # Registry: LSA / NTLM / Netlogon / SCHANNEL / .NET TLS / LAPS policy roots
    Save-Csv 'registry-auth' (Get-RegValue @('HKLM:\SYSTEM\CurrentControlSet\Control\Lsa', 'HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters'))
    Save-Csv 'registry-tls' (Get-RegValue @('HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL', 'HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319', 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NETFramework\v4.0.30319'))
    Save-Csv 'registry-laps' (Get-RegValue @('HKLM:\Software\Microsoft\Policies\LAPS', 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\LAPS', 'HKLM:\Software\Microsoft\Windows\CurrentVersion\LAPS\Config', 'HKLM:\Software\Policies\Microsoft Services\AdmPwd'))

    # Secure channel / DC locator / http.sys bindings
    $dom = try { (Get-CimInstance Win32_ComputerSystem).Domain } catch { '' }
    if ($dom) { Save-Text 'nltest-dsgetdc' { nltest "/dsgetdc:$dom" }; if (-not $IsDc) { Save-Text 'nltest-sc_query' { nltest "/sc_query:$dom" }; Save-Text 'secure-channel' { Test-ComputerSecureChannel -Verbose 4>&1 } } }
    Save-Text 'netsh-http-sslcert' { netsh http show sslcert }

    # IIS: EWS authentication config, sites and pools, logs (filtered or full), HTTPERR
    $appcmd = Join-Path $env:windir 'System32\inetsrv\appcmd.exe'
    if (Test-Path $appcmd) {
        foreach ($sec in 'windowsAuthentication', 'basicAuthentication', 'anonymousAuthentication') { Save-Text "iis-ews-$sec" { & $appcmd list config 'Default Web Site/EWS' "-section:system.webServer/security/authentication/$sec" } }
        Save-Text 'iis-ews-access' { & $appcmd list config 'Default Web Site/EWS' '-section:system.webServer/security/access' }
        Save-Text 'iis-sites' { & $appcmd list site }; Save-Text 'iis-apppools' { & $appcmd list apppool }
        try {
            Import-Module WebAdministration
            foreach ($site in Get-Website) {
                $dir = Join-Path ([Environment]::ExpandEnvironmentVariables($site.logFile.directory)) "W3SVC$($site.id)"
                $files = @(Get-ChildItem -Path $dir -Filter '*.log' -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -ge $From.AddHours(-1) -and $_.CreationTime -le $To.AddDays(1) })
                $dest = Join-Path $OutDir "iis-logs\W3SVC$($site.id)"
                if ($FullIis) { Copy-Capped $files $dest }
                else {
                    New-Item -ItemType Directory -Path $dest -Force | Out-Null
                    foreach ($f in $files) {
                        $hdr = @(Get-Content -Path $f.FullName -TotalCount 20 | Where-Object { $_ -like '#*' })
                        $hits = @(Select-String -Path $f.FullName -Pattern '/ews/', '/autodiscover/', 'mrsproxy' -SimpleMatch | ForEach-Object { $_.Line })
                        if ($hits.Count) { $out = Join-Path $dest $f.Name; ($hdr + $hits) | Set-Content -Path $out -Encoding UTF8; $state.Bytes += (Get-Item $out).Length }
                    }
                }
            }
            $done.Add('iis-logs')
        } catch { $errs.Add("iis-logs : $($_.Exception.Message)") }
    }
    $httperr = @(Get-ChildItem -Path (Join-Path $env:windir 'System32\LogFiles\HTTPERR') -Filter '*.log' -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -ge $From.AddHours(-1) })
    if ($httperr.Count) { try { Copy-Capped $httperr (Join-Path $OutDir 'httperr'); $done.Add('httperr') } catch { $errs.Add("httperr : $($_.Exception.Message)") } }

    # Exchange logs: HttpProxy (EWS, Autodiscover), EWS, MRS - files of the window, size-capped
    if ($env:ExchangeInstallPath -and (Test-Path (Join-Path $env:ExchangeInstallPath 'Logging'))) {
        try {
            $lr = Join-Path $env:ExchangeInstallPath 'Logging'
            $dirs = @(Get-ChildItem -Path $lr -Directory -Recurse -Depth 3 -ErrorAction SilentlyContinue | Where-Object { $_.FullName.Substring($lr.Length) -match '(?i)(\\HttpProxy\\(Ews|Autodiscover)$)|(\\Ews$)|(MailboxReplication)|(\\MRS)' })
            foreach ($d in $dirs) {
                $files = @(Get-ChildItem -Path $d.FullName -File -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -ge $From.AddHours(-1) -and $_.LastWriteTime -le $To.AddHours(2) })
                Copy-Capped $files (Join-Path $OutDir ("exchange-logs\" + ($d.FullName.Substring($lr.Length).Trim('\') -replace '[\\:]', '_')))
            }
            Save-Csv 'exchange-log-folders' ($dirs | Select-Object FullName)
        } catch { $errs.Add("exchange-logs : $($_.Exception.Message)") }
    }

    # Event logs in the window
    Read-Log 'events-application' @{ LogName = 'Application'; Level = 1, 2, 3; StartTime = $From; EndTime = $To }
    Read-Log 'events-system' @{ LogName = 'System'; Level = 1, 2, 3; StartTime = $From; EndTime = $To }
    foreach ($ln in 'Microsoft-Windows-NTLM/Operational', 'Microsoft-Windows-LAPS/Operational') {
        if (Get-WinEvent -ListLog $ln -ErrorAction SilentlyContinue) { Read-Log ('events-' + ($ln -replace '[^A-Za-z0-9]+', '-').Trim('-')) @{ LogName = $ln; StartTime = $From.AddDays(-7); EndTime = $To } }
    }
    $fromIso = $From.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ'); $toIso = $To.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
    $userXp = ($Accounts | ForEach-Object { "Data[@Name='TargetUserName']='$($_ -replace "'", '')'" }) -join ' or '
    $ids = '(EventID=4624 or EventID=4625 or EventID=4648 or EventID=4740 or EventID=4767 or EventID=4768 or EventID=4771 or EventID=4776)'
    Read-Log 'events-security-account' $null "*[System[$ids and TimeCreated[@SystemTime>='$fromIso' and @SystemTime<='$toIso']] and EventData[($userXp)]]" 'Security'
    try { $old = (Get-WinEvent -LogName Security -MaxEvents 1 -Oldest -ErrorAction Stop).TimeCreated; Save-Csv 'security-log-coverage' ([pscustomobject]@{ OldestEvent = $old.ToString('yyyy-MM-dd HH:mm:ss'); CoversWindowStart = ($old -le $From) }) } catch { $errs.Add("security-log-coverage : $($_.Exception.Message)") }

    [pscustomobject]@{ Computer = $env:COMPUTERNAME; OutDir = $OutDir; Collected = ($done -join ', '); Errors = @($errs); CopiedMB = [math]::Round($state.Bytes / 1MB, 1); SkippedFilesOverCap = $state.Skipped }
}

# ---- Helpers --------------------------------------------------------------------------------------
function Write-Log {
    <# .SYNOPSIS Writes one timestamped line to the log file and the console. #>
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidOverwritingBuiltInCmdlets', '', Justification = 'House rule names the helper Write-Log.')]
    param([ValidateSet('INFO', 'WARN', 'ERROR', 'DEBUG')][string]$Level = 'INFO', [Parameter(Mandatory)][string]$Message)
    $line = '{0} [{1}] {2}' -f (Get-Date -Format 'o'), $Level, $Message
    Add-Content -Path $LogFile -Value $line -Encoding UTF8
    Write-Information -MessageData $line -InformationAction Continue
}

function Write-ErrorDetail {
    <# .SYNOPSIS Logs a caught error with step, item, message, type, position and stack. #>
    param([Parameter(Mandatory)]$ErrorRecord, [Parameter(Mandatory)][string]$Step, [string]$Item = $env:COMPUTERNAME)
    Write-Log ERROR "Step: $Step | Item: $Item"
    Write-Log ERROR "Message: $($ErrorRecord.Exception.Message)"
    Write-Log ERROR "Type: $($ErrorRecord.Exception.GetType().FullName)"
    Write-Log ERROR "Position: $($ErrorRecord.InvocationInfo.PositionMessage)"
    Write-Log ERROR "Stack: $($ErrorRecord.ScriptStackTrace)"
}

function Add-Check {
    <# .SYNOPSIS Adds one finding row: Pass | Warn | Fail | Info | NotAssessed, with what it means for the migration sign-in. #>
    param([string]$Server, [string]$Area, [string]$Check, [ValidateSet('Pass', 'Warn', 'Fail', 'Info', 'NotAssessed')][string]$Status, [string]$Detail, [string]$Impact = '', [string]$Reference = '')
    $Script:Checks.Add([pscustomobject]@{ Target = $Server; Area = $Area; Check = $Check; Status = $Status; Detail = $Detail; Impact = $Impact; Reference = $Reference })
    try { $Script:Checks | Export-Csv -Path (Join-Path $RunDir "Checks-$Stamp.csv") -NoTypeInformation -Encoding UTF8 } catch { Write-Verbose "Checkpoint not written: $($_.Exception.Message)" }
}

function Test-TcpPort {
    <# .SYNOPSIS TCP connect test with a timeout; returns $true / $false. #>
    param([string]$HostName, [int]$Port, [int]$TimeoutMs = 3000)
    $c = New-Object Net.Sockets.TcpClient
    try { $ar = $c.BeginConnect($HostName, $Port, $null, $null); if (-not $ar.AsyncWaitHandle.WaitOne($TimeoutMs)) { return $false }; $c.EndConnect($ar); return $true } catch { return $false } finally { $c.Close() }
}

function Invoke-RpcCollection {
    <# .SYNOPSIS Fallback when WinRM fails: reads Application, System and the account's Security events over the remote event log service. #>
    param([string]$Computer, [string]$Dest, [string[]]$Accounts)
    New-Item -ItemType Directory -Path $Dest -Force | Out-Null
    $errs = New-Object System.Collections.Generic.List[string]
    $fromIso = $Script:Cfg.StartTime.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ'); $toIso = $Script:Cfg.EndTime.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
    $userXp = ($Accounts | ForEach-Object { "Data[@Name='TargetUserName']='$($_ -replace "'", '')'" }) -join ' or '
    $sets = [ordered]@{
        'events-application'      = @{ ComputerName = $Computer; FilterHashtable = @{ LogName = 'Application'; Level = 1, 2, 3; StartTime = $Script:Cfg.StartTime; EndTime = $Script:Cfg.EndTime }; MaxEvents = $MaxEvents }
        'events-system'           = @{ ComputerName = $Computer; FilterHashtable = @{ LogName = 'System'; Level = 1, 2, 3; StartTime = $Script:Cfg.StartTime; EndTime = $Script:Cfg.EndTime }; MaxEvents = $MaxEvents }
        'events-security-account' = @{ ComputerName = $Computer; LogName = 'Security'; MaxEvents = $MaxEvents; FilterXPath = "*[System[(EventID=4624 or EventID=4625 or EventID=4648 or EventID=4740 or EventID=4767 or EventID=4768 or EventID=4771 or EventID=4776) and TimeCreated[@SystemTime>='$fromIso' and @SystemTime<='$toIso']] and EventData[($userXp)]]" }
    }
    foreach ($name in $sets.Keys) {
        $a = $sets[$name]
        try {
            $rows = foreach ($e in @(Get-WinEvent @a -ErrorAction Stop)) {
                $d = try { (@(([xml]$e.ToXml()).Event.EventData.Data | ForEach-Object { "$($_.Name)=$($_.InnerText)" }) -join '; ') } catch { '' }
                $m = "$($e.Message)" -replace '\s+', ' '
                [pscustomobject]@{ TimeCreated = $e.TimeCreated.ToString('yyyy-MM-dd HH:mm:ss'); Id = $e.Id; Provider = $e.ProviderName; Level = $e.LevelDisplayName; Data = $d; Message = $m.Substring(0, [Math]::Min(2000, $m.Length)) }
            }
            @($rows) | Export-Csv -Path (Join-Path $Dest "$name.csv") -NoTypeInformation -Encoding UTF8
        } catch {
            if ($_.Exception.Message -match 'No events were found') { @() | Export-Csv -Path (Join-Path $Dest "$name.csv") -NoTypeInformation -Encoding UTF8 }
            else { $errs.Add("$name : $($_.Exception.Message)") }
        }
    }
    [pscustomobject]@{ Computer = $Computer; Collected = 'events over RPC only (no WinRM: no configuration, registry or log files)'; Errors = @($errs); CopiedMB = 0; SkippedFilesOverCap = 0 }
}

function Get-CsvRow {
    <# .SYNOPSIS Imports a collected CSV of a server, or returns an empty array. #>
    param([string]$Dir, [string]$Name)
    $p = Join-Path $Dir "$Name.csv"
    if (Test-Path $p) { return @(Import-Csv -Path $p) } else { return @() }
}

function Export-HtmlReport {
    <# .SYNOPSIS Writes the summary HTML: findings with impact, then the targets table. #>
    param([string]$Path, [object[]]$Targets)
    $enc = { param($s) [System.Net.WebUtility]::HtmlEncode("$s") }
    $order = @{ Fail = 0; Warn = 1; NotAssessed = 2; Info = 3; Pass = 4 }
    $rows = foreach ($c in ($Script:Checks | Sort-Object { $order[$_.Status] }, Target, Area)) {
        $ref = if ($c.Reference) { "<a href='$(& $enc $c.Reference)'>doc</a>" } else { '' }
        "<tr class='$($c.Status.ToLower())'><td>$(& $enc $c.Status)</td><td>$(& $enc $c.Target)</td><td>$(& $enc $c.Area)</td><td>$(& $enc $c.Check)</td><td>$(& $enc $c.Detail)</td><td>$(& $enc $c.Impact)</td><td>$ref</td></tr>"
    }
    $tg = if ($Targets) { ($Targets | ConvertTo-Html -Fragment) -join "`n" } else { '' }
    $counts = ($Script:Checks | Group-Object Status | ForEach-Object { "$($_.Name): $($_.Count)" }) -join ' &middot; '
    @"
<!doctype html><html><head><meta charset="utf-8"><title>Hybrid move collection</title>
<style>body{font-family:Segoe UI,Arial,sans-serif;margin:24px;color:#1b1b1b;background:#fff}h2{margin-top:28px;border-bottom:1px solid #ddd}
.muted{color:#666}table{border-collapse:collapse;width:100%;font-size:12px}th,td{border:1px solid #ddd;padding:4px 6px;text-align:left;vertical-align:top}th{background:#f3f3f3}
tr.fail td:first-child{background:#f8d7da;font-weight:bold}tr.warn td:first-child{background:#fff3cd;font-weight:bold}tr.pass td:first-child{background:#d1e7dd}
tr.notassessed td:first-child{background:#e2e3e5}tr.info td:first-child{background:#cfe2ff}</style></head><body>
<h1>Hybrid move collection - $(& $enc $env:COMPUTERNAME)</h1><p class="muted">$ScriptName $ScriptVersion | window $($Script:Cfg.StartTime.ToString('yyyy-MM-dd HH:mm')) - $($Script:Cfg.EndTime.ToString('yyyy-MM-dd HH:mm')) local | run $($StartRun.ToString('yyyy-MM-dd HH:mm'))</p><p>$counts</p>
<h2>Findings</h2><table><tr><th>Status</th><th>Target</th><th>Area</th><th>Check</th><th>Detail</th><th>Can it affect the migration sign-in?</th><th>Ref</th></tr>
$($rows -join "`n")</table>
<h2>Targets and access methods</h2>$tg
</body></html>
"@ | Set-Content -Path $Path -Encoding UTF8
}

# ---- Main -----------------------------------------------------------------------------------------
foreach ($d in @($RunDir, $LogDir, (Join-Path $RunDir 'Servers'), (Join-Path $RunDir 'Exchange-Org'))) {
    if (-not (Test-Path $d)) { Write-Information "Folder $d is missing - creating it." -InformationAction Continue; New-Item -ItemType Directory -Path $d -Force | Out-Null }
}
Write-Information "Log file: $LogFile" -InformationAction Continue
Write-Log INFO "$ScriptName $ScriptVersion | Start $($StartRun.ToString('o')) | User $env:USERDOMAIN\$env:USERNAME | Computer $env:COMPUTERNAME | PS $($PSVersionTable.PSVersion)"
Write-Log INFO ("Parameters: " + (($PSBoundParameters.GetEnumerator() | ForEach-Object { "$($_.Key)=$($_.Value -join ',')" }) -join ' | '))

$targets = New-Object System.Collections.Generic.List[object]
$Script:Cfg = $null
try {
    # Settings: file first, then parameters
    $Script:Cfg = @{ HybridHostName = ''; EndpointAccount = ''; MigratingMailbox = ''; PublicIp = ''; StartTime = $null; EndTime = $EndTime }
    if (Test-Path $SettingsPath) { $f = Import-PowerShellDataFile -Path $SettingsPath; foreach ($k in @($f.Keys)) { $Script:Cfg[$k] = $f[$k] }; Write-Log INFO "Settings read from $SettingsPath" } else { Write-Log WARN "Settings file not found: $SettingsPath" }
    foreach ($k in 'HybridHostName', 'EndpointAccount', 'MigratingMailbox', 'PublicIp', 'StartTime', 'EndTime') { if ($PSBoundParameters.ContainsKey($k)) { $Script:Cfg[$k] = $PSBoundParameters[$k] } }
    foreach ($k in 'HybridHostName', 'EndpointAccount', 'StartTime') { if (-not $Script:Cfg[$k]) { $ExitCode = 2; throw "Missing $k - set it in $SettingsPath or as a parameter." } }
    $Script:Cfg.StartTime = [datetime]$Script:Cfg.StartTime; $Script:Cfg.EndTime = [datetime]$Script:Cfg.EndTime
    $user = ($Script:Cfg.EndpointAccount -split '\\')[-1]; $netbios = ($Script:Cfg.EndpointAccount -split '\\')[0]
    $accounts = @($user, $user.ToLower(), $user.ToUpper(), ($user.Substring(0, 1).ToUpper() + $user.Substring(1).ToLower())) | Sort-Object -Unique
    Write-Log INFO "Window $($Script:Cfg.StartTime) - $($Script:Cfg.EndTime) | account $($Script:Cfg.EndpointAccount) | hybrid $($Script:Cfg.HybridHostName)"

    $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if (-not $isAdmin) { $ExitCode = 2; throw 'Run in an elevated session (Run as administrator).' }

    # Exchange Management Shell
    if (-not (Get-Command Get-ExchangeServer -ErrorAction SilentlyContinue) -and $env:ExchangeInstallPath -and (Test-Path (Join-Path $env:ExchangeInstallPath 'bin\RemoteExchange.ps1'))) {
        Write-Log INFO 'Loading the Exchange Management Shell'
        . (Join-Path $env:ExchangeInstallPath 'bin\RemoteExchange.ps1'); Connect-ExchangeServer -auto -ClientApplication:ManagementShell | Out-Null
    }
    $haveEms = [bool](Get-Command Get-ExchangeServer -ErrorAction SilentlyContinue)
    if (-not $haveEms) { Add-Check $env:COMPUTERNAME 'Run' 'Exchange Management Shell' NotAssessed 'Exchange cmdlets not available: organisation config and the Exchange server list are skipped.' }

    # Targets: this server, every Exchange server, every DC (or -ComputerName)
    $self = ([Net.Dns]::GetHostEntry($env:COMPUTERNAME)).HostName
    $dcs = @(); try { $dcs = @([DirectoryServices.ActiveDirectory.Domain]::GetComputerDomain().DomainControllers | ForEach-Object { "$($_.Name)" }) } catch { Write-ErrorDetail -ErrorRecord $_ -Step 'List DCs' }
    $exch = @(); if ($haveEms) { try { $exch = @(Get-ExchangeServer -ErrorAction Stop | ForEach-Object { "$($_.Fqdn)" }) } catch { Write-ErrorDetail -ErrorRecord $_ -Step 'List Exchange servers' } }
    $all = if ($ComputerName) { @($ComputerName) } elseif ($SkipRemote) { @() } else { @($exch) + @($dcs) }
    foreach ($n in (@($self) + $all | Where-Object { $_ } | Sort-Object -Unique)) {
        $targets.Add([pscustomobject]@{ Name = $n; Role = $(if ($dcs -contains $n) { 'DC' } elseif ($exch -contains $n) { 'Exchange' } else { 'Other' }); IsSelf = ($n -eq $self); WinRM = ''; RemoteEventLog = ''; AdminShare = ''; Ldap = ''; Collected = ''; Errors = '' })
    }
    Write-Log INFO "Targets: $(($targets | ForEach-Object Name) -join ', ')"

    # Path checks and access methods
    foreach ($t in @($targets | Where-Object { -not $_.IsSelf })) {
        Write-Log INFO "Path checks to $($t.Name)"
        $smbOpen = $false
        foreach ($p in @($PortTable | Where-Object { $_.Role -eq $t.Role })) {
            $ok = Test-TcpPort -HostName $t.Name -Port $p.Port
            if ($p.Port -eq 445) { $smbOpen = $ok }
            Add-Check $t.Name 'Path' "TCP $($p.Port) ($($p.Use))" $(if ($ok) { 'Pass' } else { 'Warn' }) $(if ($ok) { 'Reachable from this server' } else { 'Not reachable from this server (blocked or filtered)' }) $(if ($ok) { '' } else { $p.Impact })
        }
        $t.WinRM = try { Test-WSMan -ComputerName $t.Name -ErrorAction Stop | Out-Null; 'OK' } catch { "Failed: $($_.Exception.Message -replace '\s+', ' ')" }
        $t.RemoteEventLog = try { Get-WinEvent -ComputerName $t.Name -LogName System -MaxEvents 1 -ErrorAction Stop | Out-Null; 'OK' } catch { "Failed: $($_.Exception.Message -replace '\s+', ' ')" }
        $t.AdminShare = if (-not $smbOpen) { 'Failed (TCP 445 not reachable)' } elseif (Test-Path "\\$($t.Name)\c$") { 'OK' } else { 'Failed (port open, but \\server\c$ refused: permissions, UAC remote restrictions or SMB policy)' }
        if ($t.Role -eq 'DC') { $t.Ldap = try { $nc = ([ADSI]"LDAP://$($t.Name)/RootDSE").defaultNamingContext; if ($nc) { 'OK' } else { 'Empty answer' } } catch { "Failed: $($_.Exception.Message)" } }
        Add-Check $t.Name 'Access' 'Remote collection methods' $(if ($t.WinRM -eq 'OK') { 'Pass' } elseif ($t.RemoteEventLog -eq 'OK') { 'Warn' } else { 'NotAssessed' }) "WinRM: $($t.WinRM) | remote event log: $($t.RemoteEventLog) | admin share: $($t.AdminShare)$(if ($t.Ldap) { " | LDAP: $($t.Ldap)" })" 'Affects only this collection (WinRM / event log / SMB are not used by the migration sign-in).'
    }

    # Collect: this server in-process; the others through WinRM, falling back to the remote event log (RPC)
    foreach ($t in $targets) {
        $short = ($t.Name -split '\.')[0]
        $dest = Join-Path $RunDir "Servers\$short"
        $isDc = $t.Role -eq 'DC'
        $r = $null
        try {
            if ($t.IsSelf) {
                Write-Log INFO "Collecting from this server ($($t.Name))"
                $r = & $Collector $dest $Script:Cfg.StartTime $Script:Cfg.EndTime $accounts $isDc $MaxLogMB $MaxEvents $FullIisLogs.IsPresent | Select-Object -Last 1
            }
            elseif ($t.WinRM -eq 'OK') {
                Write-Log INFO "Collecting from $($t.Name) through WinRM"
                try {
                    $s = New-PSSession -ComputerName $t.Name -ErrorAction Stop
                    try {
                        $remoteDir = "C:\Windows\Temp\HybridMoveCollect-$Stamp"
                        $r = Invoke-Command -Session $s -ScriptBlock $Collector -ArgumentList $remoteDir, $Script:Cfg.StartTime, $Script:Cfg.EndTime, $accounts, $isDc, $MaxLogMB, $MaxEvents, $FullIisLogs.IsPresent | Select-Object -Last 1
                        $remoteZip = Invoke-Command -Session $s -ScriptBlock { param($Folder) $z = "$Folder.zip"; Compress-Archive -Path "$Folder\*" -DestinationPath $z -Force; $z } -ArgumentList $remoteDir
                        $localZip = Join-Path $RunDir "Servers\$short.zip"
                        Copy-Item -FromSession $s -Path $remoteZip -Destination $localZip -Force
                        Expand-Archive -Path $localZip -DestinationPath $dest -Force
                        Remove-Item -Path $localZip -Force
                        Invoke-Command -Session $s -ScriptBlock { param($Folder) Remove-Item -Path $Folder, "$Folder.zip" -Recurse -Force -ErrorAction SilentlyContinue } -ArgumentList $remoteDir
                    }
                    finally { Remove-PSSession -Session $s }
                }
                catch {
                    Write-ErrorDetail -ErrorRecord $_ -Step 'WinRM collection' -Item $t.Name
                    $t.WinRM = "Listener answers but the session failed: $($_.Exception.Message -replace '\s+', ' ')"
                    $r = $null
                }
            }
            if (-not $r -and -not $t.IsSelf -and $t.RemoteEventLog -eq 'OK') {
                Write-Log WARN "No WinRM collection from $($t.Name): reading its event logs over RPC only"
                $r = Invoke-RpcCollection -Computer $t.Name -Dest $dest -Accounts $accounts
                $Script:Partial++
            }
            if (-not $r) {
                $Script:Partial++
                Add-Check $t.Name 'Collection' 'Server collection' NotAssessed "Neither WinRM nor the remote event log worked (WinRM: $($t.WinRM) | event log: $($t.RemoteEventLog)). Run the script on $short itself with -SkipRemote." 'Unknown until collected.'
                continue
            }
            $t.Collected = "$($r.Collected) | copied $($r.CopiedMB) MB$(if ($r.SkippedFilesOverCap) { " | $($r.SkippedFilesOverCap) file(s) skipped over the $MaxLogMB MB cap" })"
            $t.Errors = (@($r.Errors) -join ' || ')
            if (@($r.Errors).Count) { $Script:Partial++; foreach ($e in @($r.Errors)) { Write-Log WARN "$($t.Name): $e" } }
            Add-Check $t.Name 'Collection' 'Server collection' $(if (@($r.Errors).Count) { 'Warn' } else { 'Pass' }) "$($t.Collected)$(if ($t.Errors) { " | errors: $($t.Errors)" })"
        }
        catch {
            $Script:Partial++; Write-ErrorDetail -ErrorRecord $_ -Step 'Collect' -Item $t.Name
            Add-Check $t.Name 'Collection' 'Server collection' NotAssessed "Failed: $($_.Exception.Message)"
        }
    }

    # Organisation configuration (Exchange Management Shell)
    if ($haveEms) {
        foreach ($k in $OrgExports.Keys) {
            try {
                $data = @(& $OrgExports[$k])
                $data | Export-Clixml -Path (Join-Path $RunDir "Exchange-Org\$k.xml") -Depth 4
                ($data | Format-List * | Out-String -Width 4096) | Set-Content -Path (Join-Path $RunDir "Exchange-Org\$k.txt") -Encoding UTF8
                Write-Log INFO "Exchange-Org $k : $($data.Count) object(s)"
            } catch { $Script:Partial++; Write-Log WARN "Exchange-Org $k : $($_.Exception.Message)" }
        }
    }

    # Findings from what was collected
    foreach ($t in $targets) {
        $dir = Join-Path $RunDir ("Servers\" + ($t.Name -split '\.')[0])
        if (-not (Test-Path $dir)) { continue }
        $adm = @(Get-CsvRow $dir 'local-users' | Where-Object { $_.SID -like '*-500' })
        foreach ($a in $adm) {
            $sameName = $a.Name -eq $user
            Add-Check $t.Name 'Local account' "Built-in local administrator '$($a.Name)'" $(if ($sameName -and $a.Enabled -eq 'True') { 'Fail' } elseif ($sameName) { 'Warn' } else { 'Info' }) "Enabled=$($a.Enabled) | PasswordLastSet=$($a.PasswordLastSet) | LastLogon=$($a.LastLogon)" $(if ($sameName) { "Can cause it: sign-ins for '$user' that arrive WITHOUT a domain are checked against this local account; if its password differs from the domain one they fail as wrong password. A recent PasswordLastSet would explain why it worked before." } else { '' }) 'https://learn.microsoft.com/troubleshoot/windows-server/windows-security/network-access-validation-algorithms'
        }
        $laps = @(Get-CsvRow $dir 'registry-laps' | Where-Object { $_.Name -ne '(key not present)' })
        if ($laps.Count) { Add-Check $t.Name 'Local account' 'LAPS policy present' Info (($laps | ForEach-Object { "$($_.Key -replace '^HKEY_LOCAL_MACHINE', 'HKLM')\$($_.Name)=$($_.Value)" }) -join '; ') 'LAPS rotates the local administrator password: sign-ins without a domain stop matching the domain password.' 'https://learn.microsoft.com/windows-server/identity/laps/laps-management-policy-settings' }
        $reg = Get-CsvRow $dir 'registry-auth'
        foreach ($n in 'RestrictReceivingNTLMTraffic', 'RestrictSendingNTLMTraffic', 'LmCompatibilityLevel', 'DisableLoopbackCheck') {
            $v = @($reg | Where-Object Name -EQ $n | Select-Object -First 1)
            if ($v.Count) { Add-Check $t.Name 'NTLM' $n $(if ($n -eq 'RestrictReceivingNTLMTraffic' -and $v[0].Value -ne '0') { 'Warn' } else { 'Info' }) "$($v[0].Key -replace '^HKEY_LOCAL_MACHINE', 'HKLM') = $($v[0].Value)" $(if ($n -eq 'RestrictReceivingNTLMTraffic' -and $v[0].Value -ne '0') { 'Can cause it: incoming NTLM is restricted on this server, and Exchange Online signs in to MRSProxy with NTLM.' } else { '' }) }
        }
        $sc = Join-Path $dir 'nltest-sc_query.txt'
        if (Test-Path $sc) { $txt = Get-Content $sc -Raw; Add-Check $t.Name 'Domain' 'Secure channel to the domain (nltest /sc_query)' $(if ($txt -match 'NERR_Success') { 'Pass' } else { 'Fail' }) (($txt -replace '\s+', ' ').Trim()) 'If broken: domain NTLM sign-ins cannot be checked by a DC and fail.' 'https://learn.microsoft.com/powershell/module/microsoft.powershell.management/test-computersecurechannel' }
        $sec = Get-CsvRow $dir 'events-security-account'
        $nd = @($sec | Where-Object { $_.Id -eq '4625' -and $_.Data -match 'TargetDomainName=(-|);' -and $_.Data -match 'LogonType=3' })
        if ($nd.Count) { Add-Check $t.Name 'Sign-in' 'Network sign-ins WITHOUT a domain, rejected' Fail "$($nd.Count) event(s) 4625; sources: $((@($nd | ForEach-Object { if ($_.Data -match 'WorkstationName=([^;]*)') { $Matches[1] } } | Sort-Object -Unique)) -join ', ') | first $($nd[-1].TimeCreated) last $($nd[0].TimeCreated)" 'Can cause it: these are checked against the LOCAL account of the same name (see the local administrator row).' 'https://learn.microsoft.com/troubleshoot/windows-server/windows-security/network-access-validation-algorithms' }
        $cov = @(Get-CsvRow $dir 'security-log-coverage')
        if ($cov.Count -and $cov[0].CoversWindowStart -eq 'False') { Add-Check $t.Name 'Events' 'Security log covers the window' Warn "Oldest event $($cov[0].OldestEvent) is after the window start: earlier sign-in events are gone." 'Evidence for the start of the window is missing; collect sooner after a failure.' }
    }

    # Optional: the one password prompt - local vs domain account database on this server
    if ($TestCredential) {
        try {
            Add-Type -AssemblyName System.DirectoryServices.AccountManagement
            $cred = Get-Credential -UserName $Script:Cfg.EndpointAccount -Message "Domain password of $($Script:Cfg.EndpointAccount) (checked locally and in the domain; not stored or logged)"
            if ($cred) {
                $pw = $cred.GetNetworkCredential().Password
                $loc = $null; $dom = $null
                try { $loc = (New-Object System.DirectoryServices.AccountManagement.PrincipalContext('Machine')).ValidateCredentials($user, $pw) } catch { $loc = "Error: $($_.Exception.Message)" }
                try { $dom = (New-Object System.DirectoryServices.AccountManagement.PrincipalContext('Domain', $netbios)).ValidateCredentials($user, $pw) } catch { $dom = "Error: $($_.Exception.Message)" }
                Remove-Variable pw, cred
                Add-Check $env:COMPUTERNAME 'Sign-in' "Domain password of $($Script:Cfg.EndpointAccount) vs this server's LOCAL '$user'" $(if ("$dom" -eq 'True' -and "$loc" -eq 'False') { 'Fail' } elseif ("$loc" -eq 'True') { 'Pass' } else { 'Info' }) "Accepted by the DOMAIN account: $dom | accepted by the LOCAL account: $loc" $(if ("$dom" -eq 'True' -and "$loc" -eq 'False') { 'Can cause it: a sign-in without a domain is checked locally here and fails with this password.' } elseif ("$loc" -eq 'True') { 'Local and domain passwords match: sign-ins without a domain would succeed here, so the local account does not explain the failure.' } else { '' })
            }
        } catch { Write-ErrorDetail -ErrorRecord $_ -Step 'TestCredential' }
    }

    # Analysis scripts (same evidence folder) for Get-HybridMoveVerdict.ps1
    if (-not $SkipAnalysis) {
        $on = Join-Path $ScriptDir 'Get-HybridMoveOnPremEvidence.ps1'; $dc = Join-Path $ScriptDir 'Get-HybridMoveAuthEvidence.ps1'
        $exo = Join-Path $ScriptDir 'ExoIpRanges.csv'
        if (Test-Path $on) {
            Write-Log INFO 'Running Get-HybridMoveOnPremEvidence.ps1 (this server)'
            $a = @{ HybridHostName = $Script:Cfg.HybridHostName; EndpointAccount = $Script:Cfg.EndpointAccount; StartTime = $Script:Cfg.StartTime; EndTime = $Script:Cfg.EndTime; EvidencePath = $EvidencePath }
            if ($Script:Cfg.PublicIp) { $a.PublicIp = $Script:Cfg.PublicIp }; if (Test-Path $exo) { $a.ExoIpListPath = $exo }
            & $on @a; Write-Log INFO "On-prem evidence exit code $LASTEXITCODE"
        }
        if (Test-Path $dc) {
            Write-Log INFO 'Running Get-HybridMoveAuthEvidence.ps1 (all DCs)'
            & $dc -AccountName $Script:Cfg.EndpointAccount -StartTime $Script:Cfg.StartTime -EndTime $Script:Cfg.EndTime -AllDomainControllers -EvidencePath $EvidencePath
            Write-Log INFO "DC evidence exit code $LASTEXITCODE"
        }
    }
}
catch {
    Write-ErrorDetail -ErrorRecord $_ -Step 'Fatal'
    if ($ExitCode -eq 0) { $ExitCode = 2 }
}
finally {
    # Each output step on its own, so one failure does not lose the others. ToArray(): @() around an empty
    # List[object] throws "Argument types do not match" in Windows PowerShell 5.1.
    $targetRows = $targets.ToArray()
    try { if ($targetRows.Count) { $targetRows | Export-Csv -Path (Join-Path $RunDir "Targets-$Stamp.csv") -NoTypeInformation -Encoding UTF8 } }
    catch { Write-ErrorDetail -ErrorRecord $_ -Step 'Targets CSV'; if ($ExitCode -eq 0) { $ExitCode = 1 } }
    try {
        if ($Script:Cfg -and $Script:Cfg.StartTime -is [datetime] -and $Script:Cfg.EndTime -is [datetime]) {
            $html = Join-Path $RunDir "Report-$Stamp.html"; Export-HtmlReport -Path $html -Targets $targetRows; Write-Log INFO "HTML report: $html"
        }
    } catch { Write-ErrorDetail -ErrorRecord $_ -Step 'HTML report'; if ($ExitCode -eq 0) { $ExitCode = 1 } }
    try {
        $zip = Join-Path (Split-Path $EvidencePath -Parent) "Evidence-$($env:COMPUTERNAME)-$Stamp.zip"
        Compress-Archive -Path (Join-Path $EvidencePath '*') -DestinationPath $zip -Force
        Write-Log INFO "Evidence zip (copy this to the laptop): $zip"
    } catch { Write-ErrorDetail -ErrorRecord $_ -Step 'Zip'; if ($ExitCode -eq 0) { $ExitCode = 1 } }
    if ($ExitCode -eq 0 -and $Script:Partial -gt 0) { $ExitCode = 1 }
    $c = $Script:Checks; $end = Get-Date
    Write-Log INFO ("End $($end.ToString('o')) | Duration $([int]($end - $StartRun).TotalSeconds)s | targets $($targets.Count) | partial $($Script:Partial) | findings Fail $(@($c | Where-Object Status -EQ 'Fail').Count), Warn $(@($c | Where-Object Status -EQ 'Warn').Count), NotAssessed $(@($c | Where-Object Status -EQ 'NotAssessed').Count) | Exit code $ExitCode")
    Write-Information "Log file: $LogFile" -InformationAction Continue
}
exit $ExitCode
