#Requires -Version 5.1
<#
.SYNOPSIS
    Guided, gated cutover of MigrationWiz-migrated mailboxes from on-prem UserMailbox to hybrid
    RemoteMailbox stamped with the Exchange Online GUIDs, driven by a terminal menu.

.DESCRIPTION
    One script, run on two machines that share one folder:
      * Exchange server, inside the Exchange Management Shell (Windows PowerShell 5.1): on-prem stages.
      * Your workstation with the ExchangeOnlineManagement module (PowerShell 7 or 5.1): cloud stages.
    Copy the whole working folder (<OutputPath>\Invoke-MailboxCutover) between the two machines,
    to the same path. Each stage reads the files the other machine wrote and writes its own.

    Stages (menu numbers):
      1  Prep A        [Cloud]   Reads alias, cloud ExchangeGuid/ArchiveGuid, routing address. Read-only.
      2  Prep B        [OnPrem]  Reads on-prem GUIDs, databases, holds, scoping tag; full backup. Read-only.
      3  Guide         [Any]     MigrationWiz first Full pass (before the cutover window).
      4  Guide         [Any]     Stop the Entra Connect sync scheduler (you do it on the server).
      5  Guide         [Any]     MigrationWiz final Full passes + Retry Errors.
      6  Cutover       [OnPrem]  C5 Disable-Mailbox, C5b disconnected check, C6 Enable-RemoteMailbox,
                                 C7 ExchangeGuid, C8 archive + ArchiveGuid, C8b verify gate,
                                 C10 clear scoping tag. CHANGES the directory (only with -Apply).
      7  Address check [Cloud]   Compares cloud SMTP/X500 addresses with the RemoteMailbox. Read-only.
      8  Address add   [OnPrem]  Adds only missing addresses (@{add=}). CHANGES (only with -Apply).
      9  Guide         [Any]     Start the Entra Connect scheduler + delta sync (you do it).
      10 Validate      [Cloud]   Recipient types, GUID match, archive status, item counts. Read-only.
      11 Post-cutover  [Cloud]   Re-enables retention processing (ElcProcessingDisabled = False). CHANGES
                                 Exchange Online (only with -Apply). Prints the client checklist.
      12 Report        [Any]     Consolidated status CSV + HTML. Read-only.
      13 Rollback info [Any]     Prints each user's rollback data and commands. Read-only, never rolls back.
      R  Refresh       [OnPrem]  Re-reads the RemoteMailbox state for cut-over users. Read-only.

    Without -Apply every stage only reports what it would do. -WhatIf and -Confirm are honoured on
    every change. Every change is pinned to one domain controller.

    What it cannot see: MigrationWiz (no API used - you confirm those steps), the Entra Connect
    servers (you run those commands), mail flow and Outlook clients (manual checklist), and data held
    in auxiliary (auto-expanded) archives (Get-EXOMailboxStatistics -Archive reports the main archive).

.PARAMETER Batch
    Name of the wave (letters, digits, - and _), for example Wave1. Keeps each wave's data separate.
    Asked for interactively when not given.

.PARAMETER OutputPath
    Root output folder. The script works in <OutputPath>\Invoke-MailboxCutover. Default C:\Scripts\Cannes.

.PARAMETER InputCsv
    CSV with one column, Upn. Default <OutputPath>\Invoke-MailboxCutover\Input\Users.csv.

.PARAMETER Stage
    Runs one stage without the menu. Guide stages and Cutover need an interactive session.

.PARAMETER Apply
    Allows changes. Without it the script only reports.

.PARAMETER DomainController
    FQDN of the domain controller for all on-prem reads/writes. Default: the domain PDC emulator.

.PARAMETER DisconnectWaitMinutes
    How long C5b waits for the disconnected mailboxes to appear. Default 10.

.PARAMETER FinalPassMaxAgeMinutes
    Maximum age of the stage 5 confirmation when a user's cutover starts. Default 120.

.PARAMETER PrepMaxAgeHours
    Maximum age of the Prep A / Prep B data when a user's cutover starts. Default 72.

.EXAMPLE
    .\Invoke-MailboxCutover.ps1 -Batch Wave1
    Opens the menu in report-only mode. Nothing is changed.

.EXAMPLE
    .\Invoke-MailboxCutover.ps1 -Batch Wave1 -Apply
    Opens the menu with changes allowed. Each change still passes its gates; -WhatIf also works.

.EXAMPLE
    .\Invoke-MailboxCutover.ps1 -Batch Wave1 -Stage PrepCloud
    Runs stage 1 only (read-only) and exits with 0, 1 or 2.

.OUTPUTS
    <Root>\Data\<Batch>\    State.json, CloudData.csv, OnPremData.csv, Disconnected.csv,
                            OnPremPost.csv, MissingAddresses.csv
    <Root>\Backup\<Batch>\  <alias>-OnPremMailbox-<timestamp>.xml
    <Root>\Reports\<Batch>\ <Stage>-<timestamp>.csv, Summary-<timestamp>.csv/.html, RollbackInfo-<timestamp>.txt
    <Root>\Logs\            Invoke-MailboxCutover-<timestamp>.log
    Exit code: 0 all succeeded, 1 one or more items failed, 2 could not run.

.NOTES
    Owner: Carlos Annes (TakeItToCloud)
    Version: 1.0.0
    Created: 2026-10-28
    Last updated: 2026-10-28
    Requires: Windows PowerShell 5.1 or PowerShell 7.x.
              On-prem stages: Exchange Management Shell on an Exchange server; Recipient Management
              (Disable-Mailbox, Enable/Set-RemoteMailbox) plus read access to mailbox databases and
              statistics (Organization Management covers all).
              Cloud stages: ExchangeOnlineManagement 3.0.0 or later; Exchange Administrator for stage 11
              (Set-Mailbox -ElcProcessingDisabled), View-Only Recipients is enough for stages 1, 7, 10.
    Why 5.1 and not 7.0 only: the on-prem stages must run inside the Exchange Management Shell, which is
              Windows PowerShell 5.1, and one script serves both machines.
    Sources (read 2026-10-28):
      https://learn.microsoft.com/powershell/module/exchangepowershell/enable-remotemailbox
      https://learn.microsoft.com/powershell/module/exchangepowershell/set-remotemailbox
      https://learn.microsoft.com/powershell/module/exchangepowershell/update-storemailboxstate
      https://learn.microsoft.com/exchange/recipients/disconnected-mailboxes/disable-or-delete-mailboxes
      https://learn.microsoft.com/powershell/module/exchangepowershell/get-connectioninformation (EXO module 3.0.0+)
    Step logic follows the validated single-user cutover runbook (C5-C10).
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [ValidatePattern('^[A-Za-z0-9_-]*$')]
    [string]$Batch = '',

    [string]$OutputPath = 'C:\Scripts\Cannes',

    [string]$InputCsv = '',

    [ValidateSet('Menu','PrepCloud','PrepOnPrem','GuideFirstPass','GuideStopSync','GuideFinalPass','Cutover',
                 'AddressCheck','AddressApply','GuideStartSync','Validate','PostCutover','Report','RollbackInfo',
                 'RefreshOnPrem','Overview')]
    [string]$Stage = 'Menu',

    [switch]$Apply,

    [string]$DomainController = '',

    [ValidateRange(1,60)]
    [int]$DisconnectWaitMinutes = 10,

    [ValidateRange(5,1440)]
    [int]$FinalPassMaxAgeMinutes = 120,

    [ValidateRange(1,720)]
    [int]$PrepMaxAgeHours = 72
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ============================================================ CONFIG (values that may change)
$ScriptName    = 'Invoke-MailboxCutover'
$ScriptVersion = '1.0.0'
$Config = [ordered]@{
    ScopingAttribute      = 'CustomAttribute5'              # Entra Connect MIGWIZ rule scope attribute (Exchange name)
    ScopingValue          = 'BT - User Migrated'            # value that keeps msExchMailboxGuid nulled
    RoutingAddressPattern = '\.mail\.onmicrosoft\.com$'     # tenant routing domain
    MailAddressPattern    = '^(smtp:|X500:)'                # address types compared/added (SIP/SPO/EUM ignored)
    DisconnectPollSeconds = 30
    RequiredModulesCloud  = @(
        [pscustomobject]@{ Name = 'ExchangeOnlineManagement'; MinVersion = '3.0.0' }   # Get-ConnectionInformation needs 3.0.0+
    )
}
$CutoverSteps = @('Preflight','C5','C5b','C6','C7','C8','C8b','C10','PostExport')

$Stages = @(
    [pscustomobject]@{ Key='PrepCloud';      Menu='1';  Where='Cloud';  Interactive=$false; Title='Prep A - export cloud data (read-only)' }
    [pscustomobject]@{ Key='PrepOnPrem';     Menu='2';  Where='OnPrem'; Interactive=$false; Title='Prep B - on-prem capture, backup, hold + tag gates (read-only)' }
    [pscustomobject]@{ Key='GuideFirstPass'; Menu='3';  Where='Any';    Interactive=$true;  Title='Guide - MigrationWiz first Full pass (before the window)' }
    [pscustomobject]@{ Key='GuideStopSync';  Menu='4';  Where='Any';    Interactive=$true;  Title='Guide - STOP Entra Connect sync scheduler' }
    [pscustomobject]@{ Key='GuideFinalPass'; Menu='5';  Where='Any';    Interactive=$true;  Title='Guide - MigrationWiz final passes + Retry Errors' }
    [pscustomobject]@{ Key='Cutover';        Menu='6';  Where='OnPrem'; Interactive=$true;  Title='Cutover C5-C10 (one user at a time)' }
    [pscustomobject]@{ Key='AddressCheck';   Menu='7';  Where='Cloud';  Interactive=$false; Title='Address check cloud vs RemoteMailbox (read-only)' }
    [pscustomobject]@{ Key='AddressApply';   Menu='8';  Where='OnPrem'; Interactive=$false; Title='Add missing addresses on the RemoteMailbox' }
    [pscustomobject]@{ Key='GuideStartSync'; Menu='9';  Where='Any';    Interactive=$true;  Title='Guide - START Entra Connect sync + delta' }
    [pscustomobject]@{ Key='Validate';       Menu='10'; Where='Cloud';  Interactive=$false; Title='Validation (read-only)' }
    [pscustomobject]@{ Key='PostCutover';    Menu='11'; Where='Cloud';  Interactive=$false; Title='Post-cutover: retention processing + client checklist' }
    [pscustomobject]@{ Key='Report';         Menu='12'; Where='Any';    Interactive=$false; Title='Consolidated report (read-only)' }
    [pscustomobject]@{ Key='RollbackInfo';   Menu='13'; Where='Any';    Interactive=$false; Title='Rollback information (read-only)' }
    [pscustomobject]@{ Key='RefreshOnPrem';  Menu='R';  Where='OnPrem'; Interactive=$false; Title='Refresh on-prem RemoteMailbox state (read-only)' }
    [pscustomobject]@{ Key='Overview';       Menu='H';  Where='Any';    Interactive=$false; Title='Process overview - what to run, where and when' }
)
# ============================================================ END CONFIG

# ---------- script-level state ----------
$Script:Cmdlet        = $PSCmdlet
$Script:LogFile       = $null
$Script:PendingLog    = New-Object System.Collections.Generic.List[string]
$Script:Results       = New-Object System.Collections.Generic.List[object]
$Script:Totals        = @{ Succeeded = 0; Failed = 0; NotAssessed = 0 }
$Script:ExitCode      = 0
$Script:PrereqFailure = $false
$Script:InputUpns     = @()
$Script:Context       = 'None'
$Script:DC            = $null
$Script:State         = $null
$Script:StartTime     = Get-Date
$Script:IsInteractive = [Environment]::UserInteractive -and ($Host.Name -ne 'Default Host')
$Script:Paths         = [ordered]@{}

# =====================================================================================================
#  Generic helpers
# =====================================================================================================

function Write-Log {
    <#
    .SYNOPSIS  Writes one timestamped line to the log file and to the console.
    .PARAMETER Message  Text to write.
    .PARAMETER Level    INFO, WARN, ERROR, DEBUG or OK (OK is logged as INFO, shown in green).
    .PARAMETER NoConsole Writes to the log only.
    #>
    param(
        [Parameter(Mandatory)][AllowEmptyString()][string]$Message,
        [ValidateSet('INFO','WARN','ERROR','DEBUG','OK')][string]$Level = 'INFO',
        [switch]$NoConsole
    )
    $fileLevel = if ($Level -eq 'OK') { 'INFO' } else { $Level }
    $line = '{0} [{1}] {2}' -f (Get-Date).ToString('yyyy-MM-ddTHH:mm:ss.fffzzz'), $fileLevel, $Message
    if ($Script:LogFile) {
        Add-Content -LiteralPath $Script:LogFile -Value $line -Encoding UTF8 -WhatIf:$false -Confirm:$false
    } else {
        $Script:PendingLog.Add($line)
    }
    if (-not $NoConsole) {
        $color = switch ($Level) { 'WARN' {'Yellow'} 'ERROR' {'Red'} 'DEBUG' {'DarkGray'} 'OK' {'Green'} default {'Gray'} }
        Write-Host $Message -ForegroundColor $color
    }
}

function Write-ErrorDetail {
    <#
    .SYNOPSIS  Logs a caught error with step, item, message, type, position and stack.
    .PARAMETER Step         What was being attempted.
    .PARAMETER Item         The user/object being processed.
    .PARAMETER ErrorRecord  The caught $_.
    #>
    param([string]$Step, [string]$Item, [System.Management.Automation.ErrorRecord]$ErrorRecord)
    Write-Log ("FAILED step '{0}' for '{1}': {2}" -f $Step, $Item, $ErrorRecord.Exception.Message) -Level ERROR
    Write-Log ("  Exception type : {0}" -f $ErrorRecord.Exception.GetType().FullName) -Level ERROR -NoConsole
    Write-Log ("  Position       : {0}" -f $ErrorRecord.InvocationInfo.PositionMessage) -Level ERROR -NoConsole
    Write-Log ("  Stack          : {0}" -f $ErrorRecord.ScriptStackTrace) -Level ERROR -NoConsole
}

function Initialize-Folder {
    <#
    .SYNOPSIS  Creates a folder if missing, telling the operator and the log.
    .PARAMETER Path  Folder to ensure.
    #>
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        Write-Host "Folder missing, creating it: $Path" -ForegroundColor Yellow
        New-Item -ItemType Directory -Path $Path -Force -WhatIf:$false -Confirm:$false | Out-Null
        Write-Log "Created missing folder: $Path" -NoConsole
    }
}

function Get-Prop {
    <#
    .SYNOPSIS  Returns a property value or $null when the property does not exist (StrictMode-safe).
    .PARAMETER Object  Source object.
    .PARAMETER Name    Property name.
    #>
    param($Object, [string]$Name)
    if ($null -eq $Object) { return $null }
    $p = $Object.PSObject.Properties[$Name]
    if ($p) { return $p.Value }
    return $null
}

function Test-GuidValue {
    <#
    .SYNOPSIS  True when the value parses as a GUID and is not the empty GUID.
    .PARAMETER Value  Value to test.
    #>
    param($Value)
    if ($null -eq $Value) { return $false }
    $g = [guid]::Empty
    if (-not [guid]::TryParse([string]$Value, [ref]$g)) { return $false }
    return ($g -ne [guid]::Empty)
}

function Test-SameGuid {
    <#
    .SYNOPSIS  True when both values are valid, non-empty and equal GUIDs.
    .PARAMETER A  First value.
    .PARAMETER B  Second value.
    #>
    param($A, $B)
    if (-not (Test-GuidValue $A) -or -not (Test-GuidValue $B)) { return $false }
    return ([guid][string]$A -eq [guid][string]$B)
}

function ConvertTo-PlainAddress {
    <#
    .SYNOPSIS  Strips an smtp:/SMTP: prefix and returns the address text.
    .PARAMETER Value  Address with or without prefix.
    #>
    param($Value)
    return ([string]$Value -replace '^(?i)smtp:', '').Trim()
}

function Get-IsoNow { (Get-Date).ToString('o') }

function ConvertFrom-Iso {
    <#
    .SYNOPSIS  Parses an ISO 8601 string written by Get-IsoNow; returns $null when empty.
    .PARAMETER Value  ISO string.
    #>
    param($Value)
    if ($null -eq $Value) { return $null }
    if ($Value -is [datetime])       { return $Value.ToLocalTime() }   # PowerShell 7 ConvertFrom-Json converts ISO strings
    if ($Value -is [datetimeoffset]) { return $Value.LocalDateTime }
    if ([string]::IsNullOrWhiteSpace([string]$Value)) { return $null }
    return ([datetimeoffset]::Parse([string]$Value, [Globalization.CultureInfo]::InvariantCulture)).LocalDateTime
}

function ConvertTo-StateValue {
    <#
    .SYNOPSIS  Normalises a value read from State.json: dates back to ISO strings, everything else unchanged.
    .PARAMETER Value  Value to normalise.
    #>
    param($Value)
    if ($Value -is [datetime])       { return $Value.ToString('o') }
    if ($Value -is [datetimeoffset]) { return $Value.ToString('o') }
    return $Value
}

function Test-InScope {
    <#
    .SYNOPSIS  True when the user is listed in the current input CSV.
    .PARAMETER Upn  User.
    #>
    param([string]$Upn)
    return [bool](@($Script:InputUpns) | Where-Object { $_ -ieq $Upn })
}

function Read-Confirmation {
    <#
    .SYNOPSIS  Asks the operator to type an exact word; returns $true only on an exact match.
    .PARAMETER Expected  Word that must be typed.
    .PARAMETER Prompt    Text shown before the prompt.
    #>
    param([Parameter(Mandatory)][string]$Expected, [string]$Prompt = '')
    if (-not $Script:IsInteractive) { return $false }
    if ($Prompt) { Write-Host $Prompt -ForegroundColor Cyan }
    $answer = Read-Host ("Type {0} to continue (anything else cancels)" -f $Expected)
    $ok = ($answer -ceq $Expected)
    Write-Log ("Operator confirmation '{0}': {1}" -f $Expected, $(if ($ok) {'given'} else {'NOT given'})) -NoConsole
    return $ok
}

function Show-Section {
    <#
    .SYNOPSIS  Prints a section header.
    .PARAMETER Title  Header text.
    #>
    param([string]$Title)
    Write-Host ''
    Write-Host ('=' * 78) -ForegroundColor DarkCyan
    Write-Host (' ' + $Title) -ForegroundColor Cyan
    Write-Host ('=' * 78) -ForegroundColor DarkCyan
}

function Show-NextAction {
    <#
    .SYNOPSIS  Prints the "what to do next" box after a stage and logs it.
    .PARAMETER Lines  Instruction lines.
    #>
    param([string[]]$Lines)
    Write-Host ''
    Write-Host '--------------------------- NEXT ---------------------------------------------' -ForegroundColor Magenta
    foreach ($l in $Lines) { Write-Host (' ' + $l) -ForegroundColor Magenta; Write-Log ("NEXT: " + $l) -NoConsole }
    Write-Host '------------------------------------------------------------------------------' -ForegroundColor Magenta
}

function Show-CopyInstruction {
    <#
    .SYNOPSIS  Standard instruction to copy the working folder to the other machine.
    .PARAMETER Target  'Exchange server' or 'your machine'.
    #>
    param([string]$Target)
    return @(
        ("Copy the WHOLE folder {0}" -f $Script:Paths.Root),
        ("to the SAME path on the {0} (overwrite). Copy only the copy you just ran on." -f $Target)
    )
}

function Add-Result {
    <#
    .SYNOPSIS  Records one result row and updates the run totals.
    .PARAMETER Stage   Stage key.
    .PARAMETER Upn     User (or '-' for batch-level).
    .PARAMETER Status  Passed, Done, Failed, NotAssessed, Skipped, Planned, Confirmed.
    .PARAMETER Detail  Reasons / notes.
    #>
    param([string]$Stage, [string]$Upn, [string]$Status, [string]$Detail = '')
    $Script:Results.Add([pscustomobject]@{
        Time = Get-IsoNow; Stage = $Stage; Upn = $Upn; Status = $Status; Detail = $Detail
    })
    switch ($Status) {
        { $_ -in 'Passed','Done','Confirmed' } { $Script:Totals.Succeeded++ }
        'Failed'                               { $Script:Totals.Failed++ }
        default                                { $Script:Totals.NotAssessed++ }
    }
}

function Export-StageReport {
    <#
    .SYNOPSIS  Writes this stage's result rows to Reports\<Batch>\<Stage>-<timestamp>.csv.
    .PARAMETER StageKey  Stage key.
    #>
    param([string]$StageKey)
    $rows = @($Script:Results | Where-Object { $_.Stage -eq $StageKey })
    if ($rows.Count -eq 0) { return }
    $file = Join-Path $Script:Paths.Reports ('{0}-{1}.csv' -f $StageKey, (Get-Date -Format 'yyyyMMdd-HHmmss'))
    $rows | Export-Csv -LiteralPath $file -NoTypeInformation -Encoding UTF8 -WhatIf:$false -Confirm:$false
    Write-Log "Stage report written: $file"
}

function Test-ChangeAllowed {
    <#
    .SYNOPSIS  Central change gate: report-only without -Apply, then ShouldProcess (-WhatIf/-Confirm).
    .PARAMETER Target       Object being changed.
    .PARAMETER Action       Description of the change.
    .PARAMETER CommandText  The exact command, for the log.
    #>
    param([string]$Target, [string]$Action, [string]$CommandText)
    if (-not $Apply) {
        Write-Log ("[REPORT ONLY] Would run: {0}" -f $CommandText) -Level WARN
        return $false
    }
    if ($Script:Cmdlet.ShouldProcess($Target, $Action)) {
        Write-Log ("Running: {0}" -f $CommandText)
        return $true
    }
    Write-Log ("[WhatIf/declined] Not executed: {0}" -f $CommandText) -Level WARN
    return $false
}

# =====================================================================================================
#  Context, modules, connections
# =====================================================================================================

function Get-RunContext {
    <#
    .SYNOPSIS  OnPrem when Exchange Management Shell cmdlets are loaded, Cloud when the EXO module exists.
    #>
    if ((Get-Command -Name Enable-RemoteMailbox -ErrorAction SilentlyContinue) -and
        (Get-Command -Name Get-MailboxDatabase -ErrorAction SilentlyContinue)) { return 'OnPrem' }
    if (Get-Module -ListAvailable -Name ExchangeOnlineManagement) { return 'Cloud' }
    return 'None'
}

function Test-StageAllowed {
    <#
    .SYNOPSIS  Refuses a stage on the wrong machine or without an interactive session.
    .PARAMETER StageInfo  Row from $Stages.
    #>
    param($StageInfo)
    if ($StageInfo.Interactive -and -not $Script:IsInteractive) {
        Write-Log ("Stage '{0}' needs an interactive session." -f $StageInfo.Key) -Level ERROR
        return $false
    }
    if ($StageInfo.Where -eq 'Any') { return $true }
    if ($StageInfo.Where -eq $Script:Context) { return $true }
    $where = if ($StageInfo.Where -eq 'OnPrem') { 'the Exchange server, inside the Exchange Management Shell' } else { 'your machine (ExchangeOnlineManagement module, NOT the Exchange Management Shell)' }
    Write-Log ("Stage {0} ({1}) must run on {2}. This session is '{3}'." -f $StageInfo.Menu, $StageInfo.Key, $where, $Script:Context) -Level ERROR
    return $false
}

function Test-RequiredModule {
    <#
    .SYNOPSIS  Checks a module/minimum version; offers a CurrentUser install when interactive.
    .PARAMETER Name        Module name.
    .PARAMETER MinVersion  Minimum version.
    #>
    param([string]$Name, [string]$MinVersion)
    $m = Get-Module -ListAvailable -Name $Name | Sort-Object Version -Descending | Select-Object -First 1
    if ($m -and ($m.Version -ge [version]$MinVersion)) {
        Write-Log ("Module {0} {1} found (minimum {2})." -f $Name, $m.Version, $MinVersion) -NoConsole
        return $true
    }
    $have = if ($m) { [string]$m.Version } else { 'not installed' }
    $useResource = [bool](Get-Command -Name Install-PSResource -ErrorAction SilentlyContinue)
    $cmd = if ($useResource) { "Install-PSResource -Name $Name -Scope CurrentUser" } else { "Install-Module -Name $Name -Scope CurrentUser -MinimumVersion $MinVersion" }
    Write-Log ("Module {0} {1} required, found: {2}." -f $Name, $MinVersion, $have) -Level WARN
    if (-not $Script:IsInteractive) {
        Write-Log ("Non-interactive session: not installing. Run: {0}" -f $cmd) -Level ERROR
        return $false
    }
    $ans = Read-Host ("Install {0} for the current user now? [Y/N]" -f $Name)
    if ($ans -notmatch '^[Yy]$') { Write-Log "Operator declined the install of $Name." -Level ERROR; return $false }
    try {
        if ($useResource) { Install-PSResource -Name $Name -Scope CurrentUser -TrustRepository -ErrorAction Stop -WhatIf:$false -Confirm:$false }
        else { Install-Module -Name $Name -Scope CurrentUser -MinimumVersion $MinVersion -Force -ErrorAction Stop -WhatIf:$false -Confirm:$false }
        Write-Log "Installed $Name for the current user." -Level OK
        return $true
    } catch {
        Write-ErrorDetail -Step 'Install module' -Item $Name -ErrorRecord $_
        return $false
    }
}

function Connect-CloudSession {
    <#
    .SYNOPSIS  Ensures an interactive Exchange Online connection (reuses an existing one).
    #>
    foreach ($mod in $Config.RequiredModulesCloud) {
        if (-not (Test-RequiredModule -Name $mod.Name -MinVersion $mod.MinVersion)) { $Script:PrereqFailure = $true; throw "Required module $($mod.Name) missing." }
    }
    Import-Module ExchangeOnlineManagement -ErrorAction Stop
    $conn = $null
    try { $conn = @(Get-ConnectionInformation -ErrorAction Stop | Where-Object { $_.State -eq 'Connected' -and -not $_.IsEopSession }) } catch { $conn = @() }
    if ($conn.Count -eq 0) {
        Write-Log 'Connecting to Exchange Online (interactive sign-in)...'
        Connect-ExchangeOnline -ShowBanner:$false -ErrorAction Stop
        $conn = @(Get-ConnectionInformation | Where-Object { $_.State -eq 'Connected' -and -not $_.IsEopSession })
    }
    if ($conn.Count -eq 0) { throw 'No Exchange Online connection after Connect-ExchangeOnline.' }
    Write-Log ("Exchange Online connected as {0} (tenant {1})." -f $conn[0].UserPrincipalName, $conn[0].TenantID) -Level OK
}

function Get-OnPremDomainController {
    <#
    .SYNOPSIS  Returns -DomainController or the PDC emulator of the current domain (no AD module needed).
    #>
    if ($DomainController) { return $DomainController }
    Add-Type -AssemblyName System.DirectoryServices
    $pdc =([System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()).PdcRoleOwner.Name
    if ([string]::IsNullOrWhiteSpace($pdc)) { throw 'Could not resolve the PDC emulator. Pass -DomainController.' }
    return $pdc
}

# =====================================================================================================
#  Data files and state
# =====================================================================================================

function Import-DataCsv {
    <#
    .SYNOPSIS  Reads Data\<Batch>\<Name>.csv; returns an empty array when the file does not exist.
    .PARAMETER Name  File name without extension.
    #>
    param([string]$Name)
    $path = Join-Path $Script:Paths.Data ("{0}.csv" -f $Name)
    if (-not (Test-Path -LiteralPath $path)) { return @() }
    return @(Import-Csv -LiteralPath $path -Encoding UTF8)
}

function Save-DataCsv {
    <#
    .SYNOPSIS  Writes Data\<Batch>\<Name>.csv, replacing existing rows of the users in $Rows.
    .PARAMETER Name  File name without extension.
    .PARAMETER Rows  Rows to write; all rows of the same Upn values are replaced.
    #>
    param([string]$Name, [object[]]$Rows)
    $Rows = @($Rows)
    $upns = @($Rows | ForEach-Object { ([string]$_.Upn).ToLowerInvariant() } | Select-Object -Unique)
    $kept = @(Import-DataCsv -Name $Name | Where-Object { $upns -notcontains ([string]$_.Upn).ToLowerInvariant() })
    $all  = @($kept) + @($Rows)
    $path = Join-Path $Script:Paths.Data ("{0}.csv" -f $Name)
    if ($all.Count -eq 0) {
        if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Force -WhatIf:$false -Confirm:$false }
        Write-Log "Data file now empty, removed: $path" -NoConsole
        return
    }
    $all | Export-Csv -LiteralPath $path -NoTypeInformation -Encoding UTF8 -WhatIf:$false -Confirm:$false
    Write-Log ("Data file written: {0} ({1} rows)" -f $path, $all.Count) -NoConsole
}

function Get-DataRow {
    <#
    .SYNOPSIS  Returns the row for one Upn from a data array, or $null.
    .PARAMETER Rows  Data rows.
    .PARAMETER Upn   User.
    #>
    param([object[]]$Rows, [string]$Upn)
    return (@($Rows) | Where-Object { [string]$_.Upn -ieq $Upn } | Select-Object -First 1)
}

function New-UserStateObject {
    <#
    .SYNOPSIS  Builds a complete per-user state object, taking existing values from $Source.
    .PARAMETER Upn     User.
    .PARAMETER Source  Existing state object (from JSON) or $null.
    #>
    param([string]$Upn, $Source)
    $fields = 'PrepCloud','PrepCloudAt','PrepOnPrem','PrepOnPremAt','CutoverStatus','CutoverStep','CutoverStartedAt',
              'CutoverDoneAt','LastError','AddressCheck','AddressCheckAt','AddressApply','AddressApplyAt',
              'Validate','ValidateAt','PostCutover','PostCutoverAt'
    $o = [ordered]@{ Upn = $Upn }
    foreach ($f in $fields) { $o[$f] = ConvertTo-StateValue (Get-Prop $Source $f) }
    if (-not $o.CutoverStatus) { $o.CutoverStatus = 'NotStarted' }
    if (-not $o.CutoverStep)   { $o.CutoverStep   = 'None' }
    $canon = @(@('None') + $CutoverSteps | Where-Object { $_ -ieq [string]$o.CutoverStep }) | Select-Object -First 1
    if ($canon) { $o.CutoverStep = $canon }
    else { Write-Log ("{0}: unknown CutoverStep '{1}' in State.json - cutover refused for this user until fixed." -f $Upn, $o.CutoverStep) -Level ERROR; $o.CutoverStep = 'Invalid' }
    foreach ($f in 'PrepCloud','PrepOnPrem','AddressCheck','AddressApply','Validate','PostCutover') { if (-not $o[$f]) { $o[$f] = 'NotRun' } }
    $o.History = @(Get-Prop $Source 'History' | Where-Object { $null -ne $_ })
    return [pscustomobject]$o
}

function Import-State {
    <#
    .SYNOPSIS  Loads (or creates) Data\<Batch>\State.json and aligns it with the input CSV.
    .PARAMETER Upns  Users from the input CSV.
    #>
    param([string[]]$Upns)
    $path = Join-Path $Script:Paths.Data 'State.json'
    $raw  = $null
    if (Test-Path -LiteralPath $path) {
        $raw = Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json
        Write-Log ("State loaded: revision {0}, last updated {1} by {2}" -f (Get-Prop $raw 'Revision'), (Get-Prop $raw 'Updated'), (Get-Prop $raw 'UpdatedBy'))
    } else {
        Write-Log "No state file yet - starting a new state for batch '$Batch'."
    }
    $g = Get-Prop $raw 'Global'
    $global = [pscustomobject][ordered]@{
        FirstPassConfirmedAt = ConvertTo-StateValue (Get-Prop $g 'FirstPassConfirmedAt')
        SyncStoppedAt        = ConvertTo-StateValue (Get-Prop $g 'SyncStoppedAt')
        FinalPassConfirmedAt = ConvertTo-StateValue (Get-Prop $g 'FinalPassConfirmedAt')
        FinalPassUsers       = @(Get-Prop $g 'FinalPassUsers' | Where-Object { $_ } | ForEach-Object { [string]$_ })
        FinalPassNote        = Get-Prop $g 'FinalPassNote'
        SyncStartedAt        = ConvertTo-StateValue (Get-Prop $g 'SyncStartedAt')
    }
    $users = New-Object System.Collections.Generic.List[object]
    $existing = @(Get-Prop $raw 'Users' | Where-Object { $null -ne $_ })
    foreach ($e in $existing) { $users.Add((New-UserStateObject -Upn ([string]$e.Upn) -Source $e)) }
    foreach ($u in $Upns) {
        if (-not ($users | Where-Object { $_.Upn -ieq $u })) { $users.Add((New-UserStateObject -Upn $u -Source $null)); Write-Log "Added to state: $u" -NoConsole }
    }
    foreach ($s in $users) {
        if ($Upns.Count -gt 0 -and $Upns -notcontains $s.Upn) { Write-Log ("In state but not in the input CSV: not offered for prep or a new cutover (a half-converted user is still offered for resume): {0}" -f $s.Upn) -Level WARN }
    }
    $Script:State = [pscustomobject][ordered]@{
        Batch     = $Batch
        Revision  = [int](Get-Prop $raw 'Revision')
        Created   = $(if (Get-Prop $raw 'Created') { Get-Prop $raw 'Created' } else { Get-IsoNow })
        Updated   = Get-Prop $raw 'Updated'
        UpdatedBy = Get-Prop $raw 'UpdatedBy'
        Global    = $global
        Users     = $users.ToArray()
    }
}

function Save-State {
    <#
    .SYNOPSIS  Writes State.json atomically (temp file, then replace).
    #>
    $Script:State.Revision  = [int]$Script:State.Revision + 1
    $Script:State.Updated   = Get-IsoNow
    $Script:State.UpdatedBy = '{0}\{1}' -f $env:COMPUTERNAME, $env:USERNAME
    $path = Join-Path $Script:Paths.Data 'State.json'
    $tmp  = "$path.tmp"
    $Script:State | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $tmp -Encoding UTF8 -WhatIf:$false -Confirm:$false
    Move-Item -LiteralPath $tmp -Destination $path -Force -WhatIf:$false -Confirm:$false
    Write-Log "State saved: $path" -NoConsole
}

function Get-UserState {
    <#
    .SYNOPSIS  Returns the state object of one user.
    .PARAMETER Upn  User.
    #>
    param([string]$Upn)
    return ($Script:State.Users | Where-Object { $_.Upn -ieq $Upn } | Select-Object -First 1)
}

function Add-UserHistory {
    <#
    .SYNOPSIS  Appends a history entry to a user's state.
    .PARAMETER UserState  User state object.
    .PARAMETER Stage      Stage key.
    .PARAMETER Result     Result text.
    .PARAMETER Detail     Detail text.
    #>
    param($UserState, [string]$Stage, [string]$Result, [string]$Detail = '')
    $entry = [pscustomobject]@{ Time = Get-IsoNow; Machine = $env:COMPUTERNAME; Stage = $Stage; Result = $Result; Detail = $Detail }
    $UserState.History = @($UserState.History) + @($entry)
}

function Get-InputUpns {
    <#
    .SYNOPSIS  Reads and validates the input CSV (one column: Upn).
    #>
    $path = $Script:Paths.InputCsv
    if (-not (Test-Path -LiteralPath $path)) {
        throw ("Input file not found: {0}. Create it with one column named Upn (one user per line)." -f $path)
    }
    $rows = @(Import-Csv -LiteralPath $path -Encoding UTF8)
    if ($rows.Count -eq 0) { throw "Input file is empty: $path" }
    if (-not $rows[0].PSObject.Properties['Upn']) { throw "Input file has no 'Upn' column: $path" }
    $upns = New-Object System.Collections.Generic.List[string]
    foreach ($r in $rows) {
        $v = ([string]$r.Upn).Trim()
        if (-not $v) { continue }
        if ($v -notmatch '^[^@\s]+@[^@\s]+\.[^@\s]+$') { throw "Invalid Upn in input file: '$v'" }
        if (-not ($upns | Where-Object { $_ -ieq $v })) { $upns.Add($v) }
    }
    if ($upns.Count -eq 0) { throw "No users in input file: $path" }
    Write-Log ("Input users ({0}): {1}" -f $upns.Count, ($upns -join ', '))
    return ,$upns.ToArray()
}

function Test-SyncStopped {
    <#
    .SYNOPSIS  True when stage 4 is confirmed and stage 9 has not been confirmed after it.
    #>
    $stop  = ConvertFrom-Iso $Script:State.Global.SyncStoppedAt
    $start = ConvertFrom-Iso $Script:State.Global.SyncStartedAt
    if (-not $stop) { return $false }
    if ($start -and $start -gt $stop) { return $false }
    return $true
}

# =====================================================================================================
#  Stage 1 - Prep A (Cloud, read-only)
# =====================================================================================================

function Invoke-PrepCloud {
    <#
    .SYNOPSIS  Exports alias, cloud GUIDs, routing address and archive state; gates each user. Read-only.
    #>
    Show-Section 'Stage 1 - Prep A: cloud data (read-only)'
    Connect-CloudSession
    $rows = New-Object System.Collections.Generic.List[object]
    foreach ($skip in @($Script:State.Users | Where-Object { (Test-InScope $_.Upn) -and $_.CutoverStatus -ne 'NotStarted' })) {
        Write-Log ("{0}: cutover already {1} - Prep A not re-run." -f $skip.Upn, $skip.CutoverStatus) -Level WARN
    }
    foreach ($s in @($Script:State.Users | Where-Object { (Test-InScope $_.Upn) -and $_.CutoverStatus -eq 'NotStarted' })) {
        $upn = $s.Upn
        Write-Log "Reading Exchange Online mailbox $upn ..."
        $reasons = New-Object System.Collections.Generic.List[string]
        try {
            $m = Get-EXOMailbox -Identity $upn -Properties Alias,DisplayName,PrimarySmtpAddress,RecipientTypeDetails,ExchangeGuid,ArchiveGuid,ArchiveStatus,EmailAddresses,ElcProcessingDisabled -ErrorAction Stop
            $addrs   = @($m.EmailAddresses | ForEach-Object { [string]$_ })
            $routing = @($addrs | Where-Object { $_ -match '^(?i)smtp:' } | ForEach-Object { ConvertTo-PlainAddress $_ } |
                         Where-Object { $_ -match $Config.RoutingAddressPattern })
            $preferred = @($routing | Where-Object { $_ -like ("{0}@*" -f $m.Alias) })
            $routingAddr = if ($preferred.Count -gt 0) { $preferred[0] } elseif ($routing.Count -gt 0) { $routing[0] } else { '' }

            if ([string]$m.RecipientTypeDetails -ne 'UserMailbox') { $reasons.Add("RecipientTypeDetails is '$($m.RecipientTypeDetails)', expected UserMailbox") }
            if (-not $m.Alias)                                    { $reasons.Add('Alias empty') }
            if (-not (Test-GuidValue $m.ExchangeGuid))            { $reasons.Add('Cloud ExchangeGuid empty') }
            if (-not $routingAddr)                                { $reasons.Add('No *.mail.onmicrosoft.com routing address on the cloud mailbox') }
            if (-not (Test-GuidValue $m.ArchiveGuid))             { Write-Log "$upn has no cloud archive - C8 will be skipped for this user." -Level WARN }

            $rows.Add([pscustomobject][ordered]@{
                Upn                   = $upn
                Alias                 = [string]$m.Alias
                DisplayName           = [string]$m.DisplayName
                PrimarySmtpAddress    = [string]$m.PrimarySmtpAddress
                RecipientTypeDetails  = [string]$m.RecipientTypeDetails
                CloudExchangeGuid     = [string]$m.ExchangeGuid
                CloudArchiveGuid      = [string]$m.ArchiveGuid
                ArchiveStatus         = [string]$m.ArchiveStatus
                RemoteRouting         = $routingAddr
                ElcProcessingDisabled = [string]$m.ElcProcessingDisabled
                CollectedAt           = Get-IsoNow
                CollectedOn           = $env:COMPUTERNAME
            })
            $status = if ($reasons.Count -eq 0) { 'Passed' } else { 'Failed' }
        } catch {
            Write-ErrorDetail -Step 'Get-EXOMailbox' -Item $upn -ErrorRecord $_
            $reasons.Add("Read failed: $($_.Exception.Message)")
            $status = 'Failed'
        }
        $detail = ($reasons -join '; ')
        $s.PrepCloud = $status; $s.PrepCloudAt = Get-IsoNow
        Add-UserHistory -UserState $s -Stage 'PrepCloud' -Result $status -Detail $detail
        Add-Result -Stage 'PrepCloud' -Upn $upn -Status $status -Detail $detail
        if ($status -eq 'Passed') { Write-Log "$upn : Prep A passed." -Level OK } else { Write-Log "$upn : Prep A FAILED - $detail" -Level ERROR }
    }
    if ($rows.Count -gt 0) { Save-DataCsv -Name 'CloudData' -Rows $rows.ToArray() }
    Save-State
    Export-StageReport -StageKey 'PrepCloud'
    $next = @('Fix any FAILED user before going on (or remove it from Users.csv).') + (Show-CopyInstruction 'Exchange server') +
            @('Then open the Exchange Management Shell there and run stage 2 (Prep B).')
    Show-NextAction $next
}

# =====================================================================================================
#  Stage 2 - Prep B (OnPrem, read-only)
# =====================================================================================================

function Invoke-PrepOnPrem {
    <#
    .SYNOPSIS  Captures on-prem GUIDs/databases, backs up each mailbox, gates holds and the scoping tag. Read-only.
    #>
    Show-Section 'Stage 2 - Prep B: on-prem capture + gates (read-only)'
    $cloud = @(Import-DataCsv -Name 'CloudData')
    if ($cloud.Count -eq 0) {
        Write-Log 'CloudData.csv not found in this folder. Run stage 1 on your machine and copy the folder here.' -Level ERROR
        Add-Result -Stage 'PrepOnPrem' -Upn '-' -Status 'Failed' -Detail 'CloudData.csv missing'
        return
    }
    $dc = Get-OnPremDomainController
    Write-Log "Domain controller for reads: $dc"
    $rows = New-Object System.Collections.Generic.List[object]
    foreach ($skip in @($Script:State.Users | Where-Object { (Test-InScope $_.Upn) -and $_.CutoverStatus -ne 'NotStarted' })) {
        Write-Log ("{0}: cutover already {1} - Prep B not re-run." -f $skip.Upn, $skip.CutoverStatus) -Level WARN
    }
    foreach ($s in @($Script:State.Users | Where-Object { (Test-InScope $_.Upn) -and $_.CutoverStatus -eq 'NotStarted' })) {
        $upn = $s.Upn
        $reasons = New-Object System.Collections.Generic.List[string]
        $c = Get-DataRow -Rows $cloud -Upn $upn
        if ($s.PrepCloud -ne 'Passed' -or -not $c) {
            $detail = 'Prep A not passed for this user (or no CloudData row) - skipped'
            Write-Log "$upn : $detail" -Level WARN
            $s.PrepOnPrem = 'Skipped'
            Add-Result -Stage 'PrepOnPrem' -Upn $upn -Status 'Skipped' -Detail $detail
            continue
        }
        try {
            $m = Get-Mailbox -Identity $c.PrimarySmtpAddress -DomainController $dc -ErrorAction Stop
            $alias = [string]$m.Alias
            $ts = Get-Date -Format 'yyyyMMdd-HHmmss'
            $backup = Join-Path $Script:Paths.Backup ("{0}-OnPremMailbox-{1}.xml" -f $alias, $ts)
            $m | Export-Clixml -LiteralPath $backup -Depth 3 -WhatIf:$false -Confirm:$false
            Write-Log "Backup written: $backup" -NoConsole

            $lit   = [string](Get-Prop $m 'LitigationHoldEnabled')
            $inpl  = @(Get-Prop $m 'InPlaceHolds' | ForEach-Object { [string]$_ } | Where-Object { $_ })
            $cth   = Get-Prop $m 'ComplianceTagHoldApplied'
            $delay = Get-Prop $m 'DelayHoldApplied'
            $tag   = [string](Get-Prop $m $Config.ScopingAttribute)

            if ([string]$m.RecipientTypeDetails -ne 'UserMailbox') { $reasons.Add("On-prem RecipientTypeDetails is '$($m.RecipientTypeDetails)', expected UserMailbox (already cut over?)") }
            if ($alias -ine [string]$c.Alias)                      { $reasons.Add("On-prem alias '$alias' differs from cloud alias '$($c.Alias)'") }
            if ($lit -ieq 'True')                                  { $reasons.Add('LitigationHoldEnabled = True (held mailbox: different procedure, -IgnoreLegalHold)') }
            if ($inpl.Count -gt 0)                                 { $reasons.Add("InPlaceHolds present: $($inpl -join ',')") }
            if ($null -ne $cth -and [string]$cth -ieq 'True')      { $reasons.Add('ComplianceTagHoldApplied = True') }
            if ($null -ne $delay -and [string]$delay -ieq 'True')  { $reasons.Add('DelayHoldApplied = True') }
            if ($null -eq $cth -or $null -eq $delay)               { Write-Log "$upn : ComplianceTagHold/DelayHold not exposed on-prem - NotAssessed (LitigationHold and InPlaceHolds were checked)." -Level WARN }
            if ($tag -cne $Config.ScopingValue)                    { $reasons.Add("$($Config.ScopingAttribute) is '$tag', expected '$($Config.ScopingValue)'") }
            if ((Test-GuidValue $m.ArchiveGuid) -and -not (Test-GuidValue $c.CloudArchiveGuid)) { $reasons.Add('On-prem archive exists but the cloud mailbox has no archive') }
            if (Test-SameGuid $m.ExchangeGuid $c.CloudExchangeGuid) { Write-Log "$upn : on-prem ExchangeGuid already equals the cloud one (stamp will be a no-op)." -Level WARN }
            foreach ($pair in @(@([string]$m.ExchangeGuid, [string]$m.Database), @([string]$m.ArchiveGuid, [string](Get-Prop $m 'ArchiveDatabase')))) {
                if (-not (Test-GuidValue $pair[0]) -or -not $pair[1]) { continue }
                try { $null = Get-MailboxStatistics -Database $pair[1] -StoreMailboxIdentity $pair[0] -ErrorAction Stop }
                catch { Write-Log ("{0}: store lookup of {1} in '{2}' failed ({3}). C5b may not confirm the disconnect; you will be offered CONTINUE." -f $upn, $pair[0], $pair[1], $_.Exception.Message) -Level WARN }
            }
            $eap = [string](Get-Prop $m 'EmailAddressPolicyEnabled')
            if ($eap -ieq 'False') { Write-Log "$upn : EmailAddressPolicyEnabled is False - after C6 the policy may change the primary SMTP. The C8b gate checks the primary; note this user." -Level WARN }

            $rows.Add([pscustomobject][ordered]@{
                Upn                = $upn
                Alias              = $alias
                AdObjectGuid       = [string]$m.Guid
                DistinguishedName  = [string]$m.DistinguishedName
                PrimarySmtpAddress = [string]$m.PrimarySmtpAddress
                OnPremExchangeGuid = [string]$m.ExchangeGuid
                OnPremArchiveGuid  = [string]$m.ArchiveGuid
                Database           = [string]$m.Database
                ArchiveDatabase    = [string](Get-Prop $m 'ArchiveDatabase')
                LegacyExchangeDN   = [string]$m.LegacyExchangeDN
                LitigationHold     = $lit
                InPlaceHolds       = ($inpl -join ';')
                ComplianceTagHold  = $(if ($null -eq $cth) { 'NotAssessed' } else { [string]$cth })
                DelayHold          = $(if ($null -eq $delay) { 'NotAssessed' } else { [string]$delay })
                ScopingTag         = $tag
                EmailAddressPolicy = $eap
                BackupFile         = $backup
                CollectedAt        = Get-IsoNow
                CollectedOn        = $env:COMPUTERNAME
            })
            $status = if ($reasons.Count -eq 0) { 'Passed' } else { 'Failed' }
        } catch {
            Write-ErrorDetail -Step 'Get-Mailbox / backup' -Item $upn -ErrorRecord $_
            $reasons.Add("Read failed: $($_.Exception.Message)")
            $status = 'Failed'
        }
        $detail = ($reasons -join '; ')
        $s.PrepOnPrem = $status; $s.PrepOnPremAt = Get-IsoNow
        Add-UserHistory -UserState $s -Stage 'PrepOnPrem' -Result $status -Detail $detail
        Add-Result -Stage 'PrepOnPrem' -Upn $upn -Status $status -Detail $detail
        if ($status -eq 'Passed') { Write-Log "$upn : Prep B passed." -Level OK } else { Write-Log "$upn : Prep B FAILED - $detail" -Level ERROR }
    }
    if ($rows.Count -gt 0) { Save-DataCsv -Name 'OnPremData' -Rows $rows.ToArray() }
    Save-State
    Export-StageReport -StageKey 'PrepOnPrem'
    Show-NextAction @(
        'Only users with Prep B = Passed can be cut over.',
        'Stage 3 (MigrationWiz first Full pass) - do it BEFORE the cutover window.',
        'Tip: run stages 3, 4 and 5 HERE on the Exchange server, so the confirmations are',
        'already in this folder when you run stage 6 - no copy needed in between.'
    )
}

# =====================================================================================================
#  Guide stages (3, 4, 5, 9)
# =====================================================================================================

function Test-GuideRecordable {
    <#
    .SYNOPSIS  Guide confirmations are recorded only in -Apply mode (a report-only rehearsal must not satisfy the gates).
    .PARAMETER StageKey  Stage key.
    #>
    param([string]$StageKey)
    if ($Apply) { return $true }
    Write-Log 'REPORT ONLY: rehearsal - this confirmation is NOT recorded. Start the script with -Apply to record it.' -Level WARN
    Add-Result -Stage $StageKey -Upn '-' -Status 'Skipped' -Detail 'Rehearsal (no -Apply)'
    return $false
}

function Get-BatchUserList {
    <#
    .SYNOPSIS  Users that passed Prep B and are not cut over yet.
    #>
    return @($Script:State.Users | Where-Object { (Test-InScope $_.Upn) -and $_.PrepOnPrem -eq 'Passed' -and $_.CutoverStatus -eq 'NotStarted' } | ForEach-Object { $_.Upn })
}

function Invoke-GuideFirstPass {
    <#
    .SYNOPSIS  Explains the MigrationWiz first Full pass and records the operator confirmation.
    #>
    Show-Section 'Stage 3 - MigrationWiz first Full pass (BEFORE the cutover window)'
    $users = Get-BatchUserList
    Write-Host 'Why: Pre-Stage copied email only. The FIRST Full pass also copies calendar, contacts,' -ForegroundColor Gray
    Write-Host 'tasks and all recent mail, and can take hours. Doing it now keeps the final pass short.' -ForegroundColor Gray
    Write-Host ''
    Write-Host 'In MigrationWiz:' -ForegroundColor White
    Write-Host '  1. Primary project -> tick ONLY the users below -> Start -> Full Migration.'
    Write-Host '  2. Archive project -> tick ONLY the users below -> Start -> Full Migration.'
    Write-Host '  3. Wait until every item shows Completed. Review the errors.'
    Write-Host ''
    Write-Host 'Users:' -ForegroundColor White
    foreach ($u in $users) { Write-Host "  - $u" }
    if (-not (Test-GuideRecordable -StageKey 'GuideFirstPass')) { return }
    if (Read-Confirmation -Expected 'CONFIRM' -Prompt 'Confirm ONLY when all items above show Completed in both projects.') {
        $Script:State.Global.FirstPassConfirmedAt = Get-IsoNow
        Save-State
        Add-Result -Stage 'GuideFirstPass' -Upn '-' -Status 'Confirmed' -Detail ($users -join ',')
        Show-NextAction @('When the cutover window starts: stage 4 (stop the Entra Connect scheduler).')
    } else {
        Add-Result -Stage 'GuideFirstPass' -Upn '-' -Status 'Skipped' -Detail 'Not confirmed'
    }
}

function Invoke-GuideStopSync {
    <#
    .SYNOPSIS  Tells the operator how to stop the Entra Connect scheduler and records the confirmation.
    #>
    Show-Section 'Stage 4 - STOP the Entra Connect sync scheduler'
    Write-Host 'Why: Disable-Mailbox strips the Exchange attributes. A sync cycle in the middle of the' -ForegroundColor Gray
    Write-Host 'cutover could push the half-converted object to Entra ID.' -ForegroundColor Gray
    Write-Host ''
    Write-Host 'On the ACTIVE Entra Connect server (StagingModeEnabled : False), elevated PowerShell:' -ForegroundColor White
    Write-Host '    Set-ADSyncScheduler -SyncCycleEnabled $false' -ForegroundColor Yellow
    Write-Host '    Get-ADSyncScheduler | Format-List SyncCycleEnabled, SyncCycleInProgress, StagingModeEnabled' -ForegroundColor Yellow
    Write-Host ''
    Write-Host 'Expected:  SyncCycleEnabled : False   SyncCycleInProgress : False   StagingModeEnabled : False'
    Write-Host 'If SyncCycleInProgress is True: wait, then run the Get line again until it is False.'
    Write-Host 'On the OTHER server only check: StagingModeEnabled : True (leave it alone).'
    Write-Host ''
    Write-Host 'WARNING: sync stays stopped for the WHOLE TENANT until you do stage 9.' -ForegroundColor Red
    if (-not (Test-GuideRecordable -StageKey 'GuideStopSync')) { return }
    if (Read-Confirmation -Expected 'CONFIRM' -Prompt 'Confirm only if the output matched the expected values above.') {
        $Script:State.Global.SyncStoppedAt = Get-IsoNow
        Save-State
        Add-Result -Stage 'GuideStopSync' -Upn '-' -Status 'Confirmed'
        Show-NextAction @('Now stage 5 (final MigrationWiz passes + Retry Errors).')
    } else {
        Add-Result -Stage 'GuideStopSync' -Upn '-' -Status 'Skipped' -Detail 'Not confirmed'
    }
}

function Invoke-GuideFinalPass {
    <#
    .SYNOPSIS  Explains the final MigrationWiz passes and Retry Errors; records the confirmation and notes.
    #>
    Show-Section 'Stage 5 - MigrationWiz final passes + Retry Errors'
    if (-not (Test-SyncStopped)) { Write-Log 'Stage 4 (sync stopped) is not confirmed. Do stage 4 first.' -Level ERROR; Add-Result -Stage 'GuideFinalPass' -Upn '-' -Status 'Failed' -Detail 'Sync not stopped'; return }
    $users = Get-BatchUserList
    Write-Host 'After C5 (Disable-Mailbox) the source mailbox is gone: nothing more can be migrated.' -ForegroundColor Gray
    Write-Host 'Everything that must move has to move NOW.' -ForegroundColor Gray
    Write-Host ''
    Write-Host '  1. Ask the users to close Outlook, OWA and mobile mail.'
    Write-Host '  2. Primary project -> tick the users -> Start -> Full Migration (tick "Migrate Automatic Replies").'
    Write-Host '  3. Archive project -> tick the users -> Start -> Full Migration.'
    Write-Host '  4. When both are Completed: Start -> Retry Errors in BOTH projects.'
    Write-Host '  5. Note completion time and error counts per user (you can type them below).'
    Write-Host ''
    foreach ($u in $users) { Write-Host "  - $u" }
    Write-Host ''
    Write-Host ("Start stage 6 within {0} minutes of confirming (mail arriving on-prem after the final pass is not migrated)." -f $FinalPassMaxAgeMinutes) -ForegroundColor Yellow
    if (-not (Test-GuideRecordable -StageKey 'GuideFinalPass')) { return }
    if (Read-Confirmation -Expected 'CONFIRM' -Prompt 'Confirm only when final passes AND Retry Errors are Completed in both projects.') {
        $note = Read-Host 'Optional note (e.g. error counts per user). Press Enter to skip'
        $Script:State.Global.FinalPassConfirmedAt = Get-IsoNow
        $Script:State.Global.FinalPassUsers = @($users)
        $Script:State.Global.FinalPassNote = $note
        Save-State
        Add-Result -Stage 'GuideFinalPass' -Upn '-' -Status 'Confirmed' -Detail $note
        Show-NextAction @('Now stage 6 (cutover) on the Exchange server, started with -Apply.',
                          'If you confirmed this on your machine, copy the folder to the Exchange server first.')
    } else {
        Add-Result -Stage 'GuideFinalPass' -Upn '-' -Status 'Skipped' -Detail 'Not confirmed'
    }
}

function Invoke-GuideStartSync {
    <#
    .SYNOPSIS  Tells the operator how to restart the Entra Connect scheduler + delta; blocks if a user is mid-cutover.
    #>
    Show-Section 'Stage 9 - START the Entra Connect scheduler + delta sync (MANDATORY)'
    $half = @($Script:State.Users | Where-Object { $_.CutoverStatus -in 'InProgress','Failed' -and $_.CutoverStep -notin 'C10','PostExport' })
    if ($half.Count -gt 0) {
        foreach ($h in $half) { Write-Log ("{0} may be half-converted (status {1}, last recorded step {2}). Run stage 6 to resume - it checks the real state. Starting sync now can push a stripped object." -f $h.Upn, $h.CutoverStatus, $h.CutoverStep) -Level ERROR }
        if (-not (Read-Confirmation -Expected 'START-ANYWAY' -Prompt 'Finish or resume those users first. Type START-ANYWAY only if you accept the risk.')) {
            Add-Result -Stage 'GuideStartSync' -Upn '-' -Status 'Skipped' -Detail 'Half-converted users present'
            return
        }
    }
    $pending = @(Import-DataCsv -Name 'MissingAddresses')
    if ($pending.Count -gt 0) { Write-Log ("MissingAddresses.csv still has {0} row(s). Add them (stage 8) and re-check (stage 7) - or accept and fix after sync." -f $pending.Count) -Level WARN }
    Write-Host 'On the ACTIVE Entra Connect server, elevated PowerShell:' -ForegroundColor White
    Write-Host '    Set-ADSyncScheduler -SyncCycleEnabled $true' -ForegroundColor Yellow
    Write-Host '    Get-ADSyncScheduler | Format-List SyncCycleEnabled' -ForegroundColor Yellow
    Write-Host '    Start-ADSyncSyncCycle -PolicyType Delta' -ForegroundColor Yellow
    Write-Host ''
    Write-Host 'Expected: SyncCycleEnabled : True. Wait until the delta cycle FINISHED:'
    Write-Host 'Synchronization Service Manager -> Operations -> Export on the Entra ID connector = success.'
    if (-not (Test-GuideRecordable -StageKey 'GuideStartSync')) { return }
    if (Read-Confirmation -Expected 'CONFIRM' -Prompt 'Confirm only when SyncCycleEnabled is True and the delta cycle has finished.') {
        $Script:State.Global.SyncStartedAt = Get-IsoNow
        Save-State
        Add-Result -Stage 'GuideStartSync' -Upn '-' -Status 'Confirmed'
        Show-NextAction @('On your machine: stage 10 (validation).',
                          'If you confirmed this on the Exchange server, copy the folder to your machine first.')
    } else {
        Add-Result -Stage 'GuideStartSync' -Upn '-' -Status 'Skipped' -Detail 'Not confirmed'
        Write-Log 'Sync is still STOPPED for the whole tenant.' -Level ERROR
    }
}

# =====================================================================================================
#  Stage 6 - Cutover (OnPrem, changes only with -Apply)
# =====================================================================================================

function Get-RemoteMailboxSafe {
    <#
    .SYNOPSIS  Get-RemoteMailbox that returns $null when the object is not a RemoteMailbox yet.
    .PARAMETER Id  Identity.
    .PARAMETER Dc  Domain controller.
    #>
    param([string]$Id, [string]$Dc)
    try { return (Get-RemoteMailbox -Identity $Id -DomainController $Dc -ErrorAction Stop) }
    catch {
        if ($_.Exception.Message -match "couldn't be found|could not be found|wasn't found|not found") { return $null }
        throw
    }
}

function Find-DisconnectedMailbox {
    <#
    .SYNOPSIS  Looks for the disconnected primary/archive by MailboxGuid in the known databases.
    .PARAMETER Map  Hashtable GUID(lowercase) -> database name.
    .PARAMETER Upn  User (for the output rows).
    #>
    param([hashtable]$Map, [string]$Upn)
    $found = New-Object System.Collections.Generic.List[object]
    foreach ($g in @($Map.Keys)) {
        $db = $Map[$g]
        $stats = $null
        # Targeted lookup (no full database enumeration). Errors are logged, never thrown: we are inside the C5 -> C6 window.
        try { $stats = @(Get-MailboxStatistics -Database $db -StoreMailboxIdentity $g -ErrorAction Stop) }
        catch { Write-Log ("[{0}] Store lookup of {1} in '{2}' failed: {3}" -f $Upn, $g, $db, $_.Exception.Message) -Level WARN; continue }
        foreach ($st in $stats) {
            if ($null -eq $st) { continue }
            $reason = [string](Get-Prop $st 'DisconnectReason')
            if ($reason) {
                $found.Add([pscustomobject][ordered]@{
                    Upn = $Upn; Database = $db; DisplayName = [string](Get-Prop $st 'DisplayName'); MailboxGuid = $g
                    DisconnectReason = $reason; DisconnectDate = [string](Get-Prop $st 'DisconnectDate'); CollectedAt = Get-IsoNow
                })
            }
        }
    }
    return ,$found.ToArray()
}

function Invoke-CutoverStep {
    <#
    .SYNOPSIS  Runs one cutover step for one user. Returns OK, Fail or NotExecuted.
    .PARAMETER Step    Step name.
    .PARAMETER Cloud   CloudData row.
    .PARAMETER OnPrem  OnPremData row.
    .PARAMETER UserState  User state (C5 marks it InProgress before the irreversible call).
    #>
    param([string]$Step, $Cloud, $OnPrem, $UserState = $null)
    $upn = $OnPrem.Upn; $alias = $OnPrem.Alias; $id = $OnPrem.AdObjectGuid; $dc = $Script:DC
    $cloudEx = [string]$Cloud.CloudExchangeGuid; $cloudAr = [string]$Cloud.CloudArchiveGuid
    $hasCloudArchive = Test-GuidValue $cloudAr
    switch ($Step) {

        'Preflight' {
            $r = Get-Recipient -Identity $id -DomainController $dc -ErrorAction Stop
            $m = Get-Mailbox -Identity $id -DomainController $dc -ErrorAction Stop
            $bad = New-Object System.Collections.Generic.List[string]
            if ([string]$r.RecipientTypeDetails -ne 'UserMailbox') { $bad.Add("RecipientTypeDetails '$($r.RecipientTypeDetails)'") }
            if (-not (Test-SameGuid $m.ExchangeGuid $OnPrem.OnPremExchangeGuid)) { $bad.Add('On-prem ExchangeGuid changed since Prep B - rerun stage 2') }
            if ([string](Get-Prop $m $Config.ScopingAttribute) -cne $Config.ScopingValue) { $bad.Add("$($Config.ScopingAttribute) no longer '$($Config.ScopingValue)'") }
            if ([string](Get-Prop $m 'LitigationHoldEnabled') -ieq 'True') { $bad.Add('LitigationHoldEnabled = True') }
            if ($bad.Count -gt 0) { Write-Log ("[{0}] Preflight FAILED: {1}" -f $alias, ($bad -join '; ')) -Level ERROR; return 'Fail' }
            Write-Log "[$alias] Preflight passed (UserMailbox, GUID unchanged, tag present, no litigation hold)." -Level OK
            return 'OK'
        }

        'C5' {
            $u = Get-User -Identity $id -DomainController $dc -ErrorAction Stop
            if ([string]$u.RecipientType -eq 'User') { Write-Log "[$alias] Already a plain User - C5 already done." -Level WARN; return 'OK' }
            $cmd = "Disable-Mailbox -Identity $id -Confirm:`$false -DomainController $dc"
            if (-not (Test-ChangeAllowed -Target $upn -Action 'Disable the on-prem mailbox (C5)' -CommandText $cmd)) { return 'NotExecuted' }
            if ($UserState) {
                # Durable marker BEFORE the irreversible call: if anything fails from here, stage 9 warns and stage 6 resumes.
                $UserState.CutoverStatus = 'InProgress'
                Add-UserHistory -UserState $UserState -Stage 'Cutover' -Result 'Started' -Detail 'C5 Disable-Mailbox issued'
                Save-State
            }
            $null = Disable-Mailbox -Identity $id -Confirm:$false -DomainController $dc -ErrorAction Stop
            $u = Get-User -Identity $id -DomainController $dc -ErrorAction Stop
            if ([string]$u.RecipientType -ne 'User') { Write-Log "[$alias] After C5 RecipientType is '$($u.RecipientType)', expected User." -Level ERROR; return 'Fail' }
            Write-Log "[$alias] C5 done - mailbox disconnected (content kept), AD user kept." -Level OK
            return 'OK'
        }

        'C5b' {
            $map = @{}
            $map[([string]$OnPrem.OnPremExchangeGuid).ToLowerInvariant()] = [string]$OnPrem.Database
            if ((Test-GuidValue $OnPrem.OnPremArchiveGuid) -and $OnPrem.ArchiveDatabase) {
                $map[([string]$OnPrem.OnPremArchiveGuid).ToLowerInvariant()] = [string]$OnPrem.ArchiveDatabase
            } elseif (Test-GuidValue $OnPrem.OnPremArchiveGuid) {
                Write-Log "[$alias] Archive database unknown - archive disconnect not checked (NotAssessed)." -Level WARN
            }
            $deadline = (Get-Date).AddMinutes($DisconnectWaitMinutes)
            $refreshed = $false
            do {
                $found = Find-DisconnectedMailbox -Map $map -Upn $upn
                $foundGuids = @($found | ForEach-Object { $_.MailboxGuid })
                $missing = @($map.Keys | Where-Object { $foundGuids -notcontains $_ })
                if ($missing.Count -eq 0) { break }
                if (-not $refreshed) {
                    foreach ($g in $missing) {
                        $cmd = "Update-StoreMailboxState -Database '$($map[$g])' -Identity $g -Confirm:`$false"
                        if (Test-ChangeAllowed -Target $upn -Action 'Synchronise store state of the disconnected mailbox' -CommandText $cmd) {
                            try { $null = Update-StoreMailboxState -Database $map[$g] -Identity $g -Confirm:$false -ErrorAction Stop }
                            catch { Write-ErrorDetail -Step 'Update-StoreMailboxState' -Item $upn -ErrorRecord $_ }
                        }
                    }
                    $refreshed = $true
                }
                Write-Log ("[{0}] Waiting for {1} disconnected mailbox(es) to appear... retry in {2}s" -f $alias, $missing.Count, $Config.DisconnectPollSeconds)
                Start-Sleep -Seconds $Config.DisconnectPollSeconds
            } while ((Get-Date) -lt $deadline)
            if ($found.Count -gt 0) { Save-DataCsv -Name 'Disconnected' -Rows (@(Import-DataCsv -Name 'Disconnected' | Where-Object { $_.Upn -ine $upn }) + @($found)) }
            foreach ($f in $found) { Write-Log ("[{0}] Disconnected: {1} in {2} ({3})" -f $alias, $f.MailboxGuid, $f.Database, $f.DisconnectReason) -Level OK }
            if ($missing.Count -eq 0) { return 'OK' }
            Write-Log ("[{0}] Not confirmed as disconnected after {1} min: {2}. Prep B backup and OnPremData.csv still hold the GUIDs." -f $alias, $DisconnectWaitMinutes, ($missing -join ', ')) -Level WARN
            Write-Host 'You are inside the C5 -> C6 window (identity half converted). Continuing is normally right;' -ForegroundColor Yellow
            Write-Host 'stopping leaves the user without a mailbox until you resume.' -ForegroundColor Yellow
            if (Read-Confirmation -Expected 'CONTINUE' -Prompt 'Type CONTINUE to go on to C6, anything else stops this user here (resume later from C6).') { return 'OK' }
            return 'Fail'
        }

        'C6' {
            if (Get-RemoteMailboxSafe -Id $id -Dc $dc) { Write-Log "[$alias] Already a RemoteMailbox - C6 already done." -Level WARN; return 'OK' }
            $cmd = "Enable-RemoteMailbox -Identity $id -Alias $alias -RemoteRoutingAddress $($Cloud.RemoteRouting) -DomainController $dc"
            if (-not (Test-ChangeAllowed -Target $upn -Action 'Convert to RemoteMailbox (C6)' -CommandText $cmd)) { return 'NotExecuted' }
            Enable-RemoteMailbox -Identity $id -Alias $alias -RemoteRoutingAddress $Cloud.RemoteRouting -DomainController $dc -Confirm:$false -ErrorAction Stop | Out-Null
            if (-not (Get-RemoteMailboxSafe -Id $id -Dc $dc)) { Write-Log "[$alias] RemoteMailbox not found after C6." -Level ERROR; return 'Fail' }
            Write-Log "[$alias] C6 done - RemoteMailbox created." -Level OK
            return 'OK'
        }

        'C7' {
            $r = Get-RemoteMailbox -Identity $id -DomainController $dc -ErrorAction Stop
            if (Test-SameGuid $r.ExchangeGuid $cloudEx) { Write-Log "[$alias] ExchangeGuid already matches the cloud." -Level OK; return 'OK' }
            $cmd = "Set-RemoteMailbox -Identity $id -ExchangeGuid $cloudEx -DomainController $dc"
            if (-not (Test-ChangeAllowed -Target $upn -Action 'Stamp the cloud ExchangeGuid (C7)' -CommandText $cmd)) { return 'NotExecuted' }
            $null = Set-RemoteMailbox -Identity $id -ExchangeGuid ([guid]$cloudEx) -DomainController $dc -Confirm:$false -ErrorAction Stop
            $r = Get-RemoteMailbox -Identity $id -DomainController $dc -ErrorAction Stop
            if (-not (Test-SameGuid $r.ExchangeGuid $cloudEx)) { Write-Log "[$alias] ExchangeGuid after C7 is $($r.ExchangeGuid), expected $cloudEx." -Level ERROR; return 'Fail' }
            Write-Log "[$alias] C7 done - ExchangeGuid = $cloudEx" -Level OK
            return 'OK'
        }

        'C8' {
            if (-not $hasCloudArchive) { Write-Log "[$alias] No cloud archive - C8 skipped." -Level WARN; return 'OK' }
            $r = Get-RemoteMailbox -Identity $id -DomainController $dc -ErrorAction Stop
            if (-not (Test-GuidValue $r.ArchiveGuid)) {
                $cmd = "Enable-RemoteMailbox -Identity $id -Archive -DomainController $dc"
                if (-not (Test-ChangeAllowed -Target $upn -Action 'Enable the remote archive (C8)' -CommandText $cmd)) { return 'NotExecuted' }
                Enable-RemoteMailbox -Identity $id -Archive -DomainController $dc -Confirm:$false -ErrorAction Stop | Out-Null
                $r = Get-RemoteMailbox -Identity $id -DomainController $dc -ErrorAction Stop
            }
            if (-not (Test-SameGuid $r.ArchiveGuid $cloudAr)) {
                $cmd = "Set-RemoteMailbox -Identity $id -ArchiveGuid $cloudAr -DomainController $dc"
                if (-not (Test-ChangeAllowed -Target $upn -Action 'Stamp the cloud ArchiveGuid (C8)' -CommandText $cmd)) { return 'NotExecuted' }
                $null = Set-RemoteMailbox -Identity $id -ArchiveGuid ([guid]$cloudAr) -DomainController $dc -Confirm:$false -ErrorAction Stop
                $r = Get-RemoteMailbox -Identity $id -DomainController $dc -ErrorAction Stop
            }
            if (-not (Test-SameGuid $r.ArchiveGuid $cloudAr)) { Write-Log "[$alias] ArchiveGuid after C8 is $($r.ArchiveGuid), expected $cloudAr." -Level ERROR; return 'Fail' }
            Write-Log "[$alias] C8 done - ArchiveGuid = $cloudAr" -Level OK
            return 'OK'
        }

        'C8b' {
            $r = Get-RemoteMailbox -Identity $id -DomainController $dc -ErrorAction Stop
            $bad = New-Object System.Collections.Generic.List[string]
            if ([string]$r.RecipientTypeDetails -ne 'RemoteUserMailbox') { $bad.Add("RecipientTypeDetails '$($r.RecipientTypeDetails)'") }
            if (-not (Test-SameGuid $r.ExchangeGuid $cloudEx)) { $bad.Add("ExchangeGuid $($r.ExchangeGuid) <> cloud $cloudEx") }
            if ($hasCloudArchive -and -not (Test-SameGuid $r.ArchiveGuid $cloudAr)) { $bad.Add("ArchiveGuid $($r.ArchiveGuid) <> cloud $cloudAr") }
            if ((ConvertTo-PlainAddress $r.RemoteRoutingAddress) -ine [string]$Cloud.RemoteRouting) { $bad.Add("RemoteRoutingAddress '$($r.RemoteRoutingAddress)' <> '$($Cloud.RemoteRouting)'") }
            if ((ConvertTo-PlainAddress $r.PrimarySmtpAddress) -ine [string]$OnPrem.PrimarySmtpAddress) { $bad.Add("PrimarySmtpAddress '$($r.PrimarySmtpAddress)' <> pre-cutover '$($OnPrem.PrimarySmtpAddress)'") }
            Write-Log ("[{0}] C8b  Type={1}  ExchangeGuid={2}  ArchiveGuid={3}  Routing={4}  Primary={5}" -f $alias, $r.RecipientTypeDetails, $r.ExchangeGuid, $r.ArchiveGuid, $r.RemoteRoutingAddress, $r.PrimarySmtpAddress)
            if ($bad.Count -gt 0) {
                Write-Log ("[{0}] C8b GATE FAILED: {1}. The scoping tag is NOT cleared. Fix, then resume (C8b re-runs)." -f $alias, ($bad -join '; ')) -Level ERROR
                return 'Fail'
            }
            Write-Log "[$alias] C8b gate passed - both GUIDs match the cloud, routing and primary correct." -Level OK
            return 'OK'
        }

        'C10' {
            $r = Get-RemoteMailbox -Identity $id -DomainController $dc -ErrorAction Stop
            if ([string]::IsNullOrEmpty([string](Get-Prop $r $Config.ScopingAttribute))) { Write-Log "[$alias] Scoping tag already empty." -Level OK; return 'OK' }
            $cmd = "Set-RemoteMailbox -Identity $id -$($Config.ScopingAttribute) `$null -DomainController $dc"
            if (-not (Test-ChangeAllowed -Target $upn -Action 'Clear the scoping tag (C10)' -CommandText $cmd)) { return 'NotExecuted' }
            $p = @{ Identity = $id; DomainController = $dc; ErrorAction = 'Stop'; Confirm = $false }
            $p[$Config.ScopingAttribute] = $null
            $null = Set-RemoteMailbox @p
            $r = Get-RemoteMailbox -Identity $id -DomainController $dc -ErrorAction Stop
            if (-not [string]::IsNullOrEmpty([string](Get-Prop $r $Config.ScopingAttribute))) { Write-Log "[$alias] Scoping tag still set after C10." -Level ERROR; return 'Fail' }
            Write-Log "[$alias] C10 done - scoping tag cleared (sync rules untouched)." -Level OK
            return 'OK'
        }

        'PostExport' {
            Export-OnPremPost -Rows @($OnPrem)
            return 'OK'
        }
    }
    throw "Unknown cutover step '$Step'."
}

function Export-OnPremPost {
    <#
    .SYNOPSIS  Writes the current RemoteMailbox state (GUIDs, tag, mail addresses) to OnPremPost.csv. Read-only.
    .PARAMETER Rows  OnPremData rows of the users to export.
    #>
    param([object[]]$Rows)
    $out = New-Object System.Collections.Generic.List[object]
    foreach ($o in @($Rows)) {
        try {
            $r = Get-RemoteMailbox -Identity $o.AdObjectGuid -DomainController $Script:DC -ErrorAction Stop
            $addrs = @($r.EmailAddresses | ForEach-Object { [string]$_ } | Where-Object { $_ -imatch $Config.MailAddressPattern })
            $out.Add([pscustomobject][ordered]@{
                Upn                  = $o.Upn
                Alias                = [string]$r.Alias
                RecipientTypeDetails = [string]$r.RecipientTypeDetails
                ExchangeGuid         = [string]$r.ExchangeGuid
                ArchiveGuid          = [string]$r.ArchiveGuid
                RemoteRoutingAddress = ConvertTo-PlainAddress $r.RemoteRoutingAddress
                PrimarySmtpAddress   = [string]$r.PrimarySmtpAddress
                ScopingTag           = [string](Get-Prop $r $Config.ScopingAttribute)
                EmailAddresses       = ($addrs -join '|')
                CollectedAt          = Get-IsoNow
                CollectedOn          = $env:COMPUTERNAME
            })
            Write-Log ("[{0}] On-prem state exported ({1} mail addresses)." -f $o.Alias, $addrs.Count) -Level OK
        } catch {
            Write-ErrorDetail -Step 'Export RemoteMailbox state' -Item $o.Upn -ErrorRecord $_
        }
    }
    if ($out.Count -gt 0) { Save-DataCsv -Name 'OnPremPost' -Rows $out.ToArray() }
}

function Invoke-UserCutover {
    <#
    .SYNOPSIS  Runs (or resumes) C5-C10 for one user with gates; returns Done, Failed or NotExecuted.
    .PARAMETER UserState  User state.
    .PARAMETER Cloud      CloudData row.
    .PARAMETER OnPrem     OnPremData row.
    #>
    param($UserState, $Cloud, $OnPrem)
    $upn = $UserState.Upn
    $last = [string]$UserState.CutoverStep
    # Nothing changed until C5: always (re)run the preflight for a user that has not passed C5.
    $startIndex = if (-not $last -or $last -in 'None','Preflight') { 0 } else { [array]::IndexOf($CutoverSteps, $last) + 1 }
    if ($startIndex -gt 0) { Write-Log ("[{0}] Resuming after step {1}." -f $OnPrem.Alias, $last) -Level WARN }
    if (-not $UserState.CutoverStartedAt) { $UserState.CutoverStartedAt = Get-IsoNow }
    for ($i = $startIndex; $i -lt $CutoverSteps.Count; $i++) {
        $step = $CutoverSteps[$i]
        Write-Log ("[{0}] --- {1} ---" -f $OnPrem.Alias, $step)
        $res = 'Fail'
        try { $res = [string](@(Invoke-CutoverStep -Step $step -Cloud $Cloud -OnPrem $OnPrem -UserState $UserState)[-1]) }
        catch { Write-ErrorDetail -Step $step -Item $upn -ErrorRecord $_; $UserState.LastError = "$step : $($_.Exception.Message)"; $res = 'Fail' }

        if ($res -eq 'NotExecuted') {
            Add-UserHistory -UserState $UserState -Stage 'Cutover' -Result 'NotExecuted' -Detail "Stopped before $step (report-only/WhatIf)"
            Save-State
            return 'NotExecuted'
        }
        if ($res -ne 'OK') {
            $UserState.CutoverStatus = $(if ($step -eq 'Preflight' -and $startIndex -eq 0) { 'NotStarted' } else { 'Failed' })
            if (-not $UserState.LastError) { $UserState.LastError = "$step gate failed (see log)" }
            Add-UserHistory -UserState $UserState -Stage 'Cutover' -Result 'Failed' -Detail ("At {0}. Last completed: {1}" -f $step, $UserState.CutoverStep)
            Save-State
            return 'Failed'
        }
        $UserState.CutoverStep = $step
        $UserState.LastError = $null
        if ($step -ne 'Preflight') { $UserState.CutoverStatus = 'InProgress' }
        Add-UserHistory -UserState $UserState -Stage 'Cutover' -Result 'OK' -Detail $step
        Save-State
    }
    $UserState.CutoverStatus = 'Done'
    $UserState.CutoverDoneAt = Get-IsoNow
    Save-State
    return 'Done'
}

function Get-CutoverGateFailure {
    <#
    .SYNOPSIS  Attestation gates for STARTING a user's cutover, evaluated at the moment of the start.
    .PARAMETER Upn  User, or '' for a batch-level preview (skips the per-user list check).
    #>
    param([string]$Upn)
    $bad = New-Object System.Collections.Generic.List[string]
    $g = $Script:State.Global
    if (-not (Test-SyncStopped)) { $bad.Add('Stage 4 (Entra Connect scheduler stopped) is not confirmed, or stage 9 was confirmed after it.') }
    if (-not $g.FirstPassConfirmedAt) { $bad.Add('Stage 3 (MigrationWiz first Full pass) is not confirmed.') }
    $stopAt  = ConvertFrom-Iso $g.SyncStoppedAt
    $finalAt = ConvertFrom-Iso $g.FinalPassConfirmedAt
    if (-not $finalAt) { $bad.Add('Stage 5 (final passes + Retry Errors) is not confirmed.') }
    elseif ($stopAt -and $finalAt -lt $stopAt) { $bad.Add('Stage 5 was confirmed BEFORE stage 4 - repeat stage 5 now that sync is stopped.') }
    else {
        $age = ((Get-Date) - $finalAt).TotalMinutes
        if ($age -gt $FinalPassMaxAgeMinutes) { $bad.Add(("Stage 5 was confirmed {0:N0} min ago (limit {1}). Mail since then would not be migrated - run the final passes again and re-confirm stage 5." -f $age, $FinalPassMaxAgeMinutes)) }
    }
    if ($Upn -and $finalAt -and -not (@($g.FinalPassUsers) | Where-Object { $_ -ieq $Upn })) {
        $bad.Add("$Upn was not in the user list confirmed at stage 5 - repeat stage 5.")
    }
    return ,$bad.ToArray()
}

function Get-CutoverDataFailure {
    <#
    .SYNOPSIS  Data gates checked before any cutover step: prep results, GUID/routing validity, data age.
    .PARAMETER UserState  User state.
    .PARAMETER Cloud      CloudData row.
    .PARAMETER OnPrem     OnPremData row.
    .PARAMETER Fresh      True for a new start (data age is checked only then).
    #>
    param($UserState, $Cloud, $OnPrem, [bool]$Fresh)
    $bad = New-Object System.Collections.Generic.List[string]
    if ($UserState.PrepCloud -ne 'Passed')  { $bad.Add("Prep A is '$($UserState.PrepCloud)', not Passed") }
    if ($UserState.PrepOnPrem -ne 'Passed') { $bad.Add("Prep B is '$($UserState.PrepOnPrem)', not Passed") }
    if (-not (Test-GuidValue $Cloud.CloudExchangeGuid)) { $bad.Add('Cloud ExchangeGuid missing or invalid in CloudData.csv') }
    if ([string]$Cloud.RemoteRouting -notmatch $Config.RoutingAddressPattern) { $bad.Add("Routing address '$($Cloud.RemoteRouting)' missing or invalid") }
    if (-not (Test-GuidValue $OnPrem.AdObjectGuid)) { $bad.Add('AD object GUID missing in OnPremData.csv') }
    if ($Fresh) {
        foreach ($pair in @(@('Prep A', [string]$Cloud.CollectedAt), @('Prep B', [string]$OnPrem.CollectedAt))) {
            $t = $null
            try { $t = ConvertFrom-Iso $pair[1] } catch { $t = $null }
            if (-not $t) { $bad.Add("$($pair[0]) collection time missing or unreadable") }
            elseif (((Get-Date) - $t).TotalHours -gt $PrepMaxAgeHours) {
                $bad.Add(("{0} data is {1:N0} h old (limit {2} h) - re-run stages 1 and 2" -f $pair[0], ((Get-Date) - $t).TotalHours, $PrepMaxAgeHours))
            }
        }
    }
    return ,$bad.ToArray()
}

function Invoke-Cutover {
    <#
    .SYNOPSIS  Stage 6: batch gates, user selection, per-user typed confirmation, then C5-C10.
    #>
    Show-Section ('Stage 6 - Cutover C5-C10  [{0}]' -f $(if ($Apply) { 'APPLY MODE' } else { 'REPORT ONLY - nothing will change' }))
    $cloud  = @(Import-DataCsv -Name 'CloudData')
    $onprem = @(Import-DataCsv -Name 'OnPremData')
    if ($cloud.Count -eq 0 -or $onprem.Count -eq 0) { Write-Log 'CloudData.csv / OnPremData.csv missing. Run stages 1 and 2 first.' -Level ERROR; Add-Result -Stage 'Cutover' -Upn '-' -Status 'Failed' -Detail 'Prep data missing'; return }
    $Script:DC = Get-OnPremDomainController
    Write-Log "All on-prem reads and writes pinned to: $($Script:DC)"

    # ---- candidates: new in-scope users that passed both preps, plus every started/failed user (resume) ----
    $cands = @($Script:State.Users | Where-Object {
        ($_.CutoverStatus -in 'InProgress','Failed') -or
        ((Test-InScope $_.Upn) -and $_.CutoverStatus -eq 'NotStarted' -and $_.PrepCloud -eq 'Passed' -and $_.PrepOnPrem -eq 'Passed') })
    if ($cands.Count -eq 0) { Write-Log 'No users eligible (Prep A + Prep B passed and not started, or a started user to resume).' -Level WARN; return }
    foreach ($g in @(Get-CutoverGateFailure -Upn '')) { Write-Log ("BATCH GATE: {0}" -f $g) -Level WARN }
    Write-Host ''
    for ($i = 0; $i -lt $cands.Count; $i++) {
        $c = $cands[$i]
        Write-Host ("  [{0}] {1,-42} Status={2,-10} LastStep={3}" -f ($i + 1), $c.Upn, $c.CutoverStatus, $c.CutoverStep)
    }
    $pick = Read-Host 'Users to process: numbers separated by commas, A for all, Enter to cancel'
    if ([string]::IsNullOrWhiteSpace($pick)) { Write-Log 'Cutover cancelled by operator.'; return }
    $selected = @(if ($pick.Trim() -ieq 'A') { $cands } else {
        $pick -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ -match '^\d+$' } |
          ForEach-Object { [int]$_ - 1 } | Where-Object { $_ -ge 0 -and $_ -lt $cands.Count } | Select-Object -Unique |
          ForEach-Object { $cands[$_] }
    })
    if ($selected.Count -eq 0) { Write-Log 'No valid selection.' -Level WARN; return }

    foreach ($s in $selected) {
        $upn = $s.Upn
        $c = Get-DataRow -Rows $cloud -Upn $upn
        $o = Get-DataRow -Rows $onprem -Upn $upn
        if (-not $c -or -not $o) { Write-Log "$upn : CloudData/OnPremData row missing - skipped." -Level ERROR; Add-Result -Stage 'Cutover' -Upn $upn -Status 'Failed' -Detail 'Prep data row missing'; continue }
        if ($s.CutoverStep -eq 'Invalid') { Write-Log "$upn : CutoverStep in State.json is invalid - fix State.json first." -Level ERROR; Add-Result -Stage 'Cutover' -Upn $upn -Status 'Failed' -Detail 'Invalid CutoverStep'; continue }

        # ---- live state: never trust the record alone for a user with nothing recorded after Preflight ----
        $fresh = $false
        if ($s.CutoverStep -in 'None','Preflight') {
            try { $liveType = [string](Get-User -Identity $o.AdObjectGuid -DomainController $Script:DC -ErrorAction Stop).RecipientTypeDetails }
            catch { Write-ErrorDetail -Step 'Live state check' -Item $upn -ErrorRecord $_; Add-Result -Stage 'Cutover' -Upn $upn -Status 'Failed' -Detail 'Live state could not be read'; continue }
            if ($liveType -eq 'UserMailbox') { $fresh = $true }
            else {
                Write-Log ("{0} : live object is '{1}' - C5 was already applied but not recorded. Handling as a RESUME from C5b." -f $upn, $liveType) -Level ERROR
                if ($Apply) {
                    $s.CutoverStep = 'C5'; $s.CutoverStatus = 'InProgress'
                    Add-UserHistory -UserState $s -Stage 'Cutover' -Result 'Recovered' -Detail "Live type $liveType; recorded C5 as done"
                    Save-State
                }
            }
        }

        # ---- gates: batch/attestation gates for a new start, data gates always ----
        $bad = New-Object System.Collections.Generic.List[string]
        if ($fresh) { foreach ($x in @(Get-CutoverGateFailure -Upn $upn)) { $bad.Add($x) } }
        elseif (-not (Test-SyncStopped)) { $bad.Add('Resume requires sync to be stopped (stage 4 confirmed, stage 9 not after it).') }
        foreach ($x in @(Get-CutoverDataFailure -UserState $s -Cloud $c -OnPrem $o -Fresh $fresh)) { $bad.Add($x) }

        Show-Section ("{0}  ({1})" -f $upn, $o.Alias)
        Write-Host ("  On-prem ExchangeGuid {0} -> cloud {1}" -f $o.OnPremExchangeGuid, $c.CloudExchangeGuid)
        Write-Host ("  On-prem ArchiveGuid  {0} -> cloud {1}" -f $o.OnPremArchiveGuid, $c.CloudArchiveGuid)
        Write-Host ("  Routing              {0}" -f $c.RemoteRouting)
        Write-Host ("  Databases            {0} / {1}" -f $o.Database, $o.ArchiveDatabase)
        Write-Host ("  Backup               {0}" -f $o.BackupFile)
        if (-not $fresh) { Write-Host ("  RESUME after step    {0}" -f $s.CutoverStep) -ForegroundColor Yellow }
        foreach ($x in $bad) { Write-Log ("{0} : GATE: {1}" -f $upn, $x) -Level $(if ($Apply) { 'ERROR' } else { 'WARN' }) }

        if (-not $Apply) {
            try {
                $pf = if ($fresh) { [string](@(Invoke-CutoverStep -Step 'Preflight' -Cloud $c -OnPrem $o)[-1]) } else { 'OK' }
            } catch { Write-ErrorDetail -Step 'Preflight' -Item $upn -ErrorRecord $_; $pf = 'Fail' }
            $skipN = if ($fresh) { 1 } elseif ($s.CutoverStep -in 'None','Preflight') { 2 } else { [array]::IndexOf($CutoverSteps, $s.CutoverStep) + 1 }
            Write-Log ("[REPORT ONLY] {0}: preflight={1}; gates={2}. Planned steps: {3}" -f $upn, $pf, $(if ($bad.Count -eq 0) {'pass'} else {'FAIL'}), (($CutoverSteps | Select-Object -Skip $skipN) -join ' > ')) -Level WARN
            Add-Result -Stage 'Cutover' -Upn $upn -Status 'Planned' -Detail ("Preflight {0}; gates {1}" -f $pf, $(if ($bad.Count -eq 0) {'pass'} else {($bad -join ' | ')}))
            continue
        }

        if ($bad.Count -gt 0) {
            Write-Log "$upn : gates not met - not started/resumed." -Level ERROR
            Add-Result -Stage 'Cutover' -Upn $upn -Status 'Failed' -Detail ($bad -join ' | ')
            continue
        }
        if (-not (Read-Confirmation -Expected $o.Alias -Prompt ("Type the alias '{0}' to start the cutover of this user." -f $o.Alias))) {
            Write-Log "$upn : operator did not confirm - skipped." -Level WARN
            Add-Result -Stage 'Cutover' -Upn $upn -Status 'Skipped' -Detail 'Not confirmed'
            continue
        }

        $res = Invoke-UserCutover -UserState $s -Cloud $c -OnPrem $o
        $stopBatch = $false
        if ($res -eq 'Done') {
            Add-Result -Stage 'Cutover' -Upn $upn -Status 'Done' -Detail 'C5-C10 completed'
            Write-Log "$upn : CUTOVER COMPLETE." -Level OK
        } elseif ($res -eq 'NotExecuted') {
            Add-Result -Stage 'Cutover' -Upn $upn -Status 'Skipped' -Detail 'WhatIf/declined'
        } else {
            Add-Result -Stage 'Cutover' -Upn $upn -Status 'Failed' -Detail ("Stopped; last completed step {0}; {1}" -f $s.CutoverStep, $s.LastError)
            Write-Log ("{0} : STOPPED. Last completed step: {1}. Keep sync STOPPED. Fix the cause, then choose stage 6 again to resume." -f $upn, $s.CutoverStep) -Level ERROR
            if ($selected.Count -gt 1 -and -not (Read-Confirmation -Expected 'NEXT' -Prompt 'A user failed. Type NEXT to continue with the next user, anything else stops the batch.')) { $stopBatch = $true }
        }
        if ($stopBatch) { Write-Log 'Batch stopped by operator after a failure.' -Level WARN; break }
    }
    Export-StageReport -StageKey 'Cutover'
    $next = @()
    if ($Apply) {
        $next += (Show-CopyInstruction 'your machine')
        $next += 'Then run stage 7 (address check) there. Sync must stay STOPPED until stage 9.'
    } else {
        $next += 'Report-only run finished. When ready, start the script again with -Apply and run stage 6.'
    }
    Show-NextAction $next
}

# =====================================================================================================
#  Stage R - Refresh on-prem state (OnPrem, read-only)
# =====================================================================================================

function Invoke-RefreshOnPrem {
    <#
    .SYNOPSIS  Re-exports the RemoteMailbox state of every cut-over user. Read-only.
    #>
    Show-Section 'Refresh on-prem RemoteMailbox state (read-only)'
    $Script:DC = Get-OnPremDomainController
    $done = @($Script:State.Users | Where-Object { $_.CutoverStatus -eq 'Done' } | ForEach-Object { $_.Upn })
    $rows = @(Import-DataCsv -Name 'OnPremData' | Where-Object { $done -contains $_.Upn })
    if ($rows.Count -eq 0) { Write-Log 'No cut-over users to refresh.' -Level WARN; return }
    Export-OnPremPost -Rows $rows
    foreach ($r in $rows) { Add-Result -Stage 'RefreshOnPrem' -Upn $r.Upn -Status 'Done' }
    Show-NextAction (Show-CopyInstruction 'your machine')
}

# =====================================================================================================
#  Stage 7 - Address check (Cloud, read-only)
# =====================================================================================================

function Invoke-AddressCheck {
    <#
    .SYNOPSIS  Lists cloud SMTP/X500 addresses missing on the RemoteMailbox; flags primary mismatches. Read-only.
    #>
    Show-Section 'Stage 7 - Address check cloud vs RemoteMailbox (read-only)'
    $post = @(Import-DataCsv -Name 'OnPremPost')
    if ($post.Count -eq 0) { Write-Log 'OnPremPost.csv not found. Run stage 6 (or R) on the Exchange server and copy the folder here.' -Level ERROR; Add-Result -Stage 'AddressCheck' -Upn '-' -Status 'Failed' -Detail 'OnPremPost.csv missing'; return }
    Connect-CloudSession
    $missingRows = New-Object System.Collections.Generic.List[object]
    $checked = New-Object System.Collections.Generic.List[object]
    foreach ($s in @($Script:State.Users | Where-Object { $_.CutoverStatus -eq 'Done' })) {
        $upn = $s.Upn
        $p = Get-DataRow -Rows $post -Upn $upn
        if (-not $p) { Write-Log "$upn : no OnPremPost row - run R on the Exchange server." -Level ERROR; Add-Result -Stage 'AddressCheck' -Upn $upn -Status 'Failed' -Detail 'No OnPremPost row'; continue }
        try {
            $m = Get-EXOMailbox -Identity $upn -Properties EmailAddresses -ErrorAction Stop
            $cloudAddrs  = @($m.EmailAddresses | ForEach-Object { [string]$_ } | Where-Object { $_ -imatch $Config.MailAddressPattern })
            $remoteAddrs = @(([string]$p.EmailAddresses) -split '\|' | Where-Object { $_ })
            $remoteSmtp  = @($remoteAddrs | Where-Object { $_ -imatch '^smtp:' } | ForEach-Object { (ConvertTo-PlainAddress $_).ToLowerInvariant() })
            $remoteX500  = @($remoteAddrs | Where-Object { $_ -imatch '^X500:' } | ForEach-Object { $_.Substring(5) })
            $miss = New-Object System.Collections.Generic.List[string]
            foreach ($a in $cloudAddrs) {
                if ($a -imatch '^X500:') { if ($remoteX500 -notcontains $a.Substring(5)) { $miss.Add($a) } }
                else { if ($remoteSmtp -notcontains (ConvertTo-PlainAddress $a).ToLowerInvariant()) { $miss.Add($a) } }
            }
            $cloudPrimary = @($m.EmailAddresses | ForEach-Object { [string]$_ } | Where-Object { $_ -cmatch '^SMTP:' } | ForEach-Object { ConvertTo-PlainAddress $_ }) | Select-Object -First 1
            $primaryOk = ($cloudPrimary -and ($cloudPrimary -ieq [string]$p.PrimarySmtpAddress))
            foreach ($a in $miss) {
                $missingRows.Add([pscustomobject][ordered]@{ Upn = $upn; Alias = $p.Alias; Address = $a; FoundAt = Get-IsoNow })
            }
            $checked.Add($upn)
            $detail = "Cloud {0} / on-prem {1} addresses; missing {2}; primary {3}" -f $cloudAddrs.Count, $remoteAddrs.Count, $miss.Count, $(if ($primaryOk) {'match'} else {"MISMATCH cloud '$cloudPrimary' vs on-prem '$($p.PrimarySmtpAddress)'"})
            $status = if (-not $primaryOk) { 'Failed' } elseif ($miss.Count -gt 0) { 'Failed' } else { 'Passed' }
            if (-not $primaryOk) { Write-Log "$upn : PRIMARY SMTP MISMATCH - investigate before anything else. Not auto-fixed." -Level ERROR }
            foreach ($a in $miss) { Write-Log "$upn : missing on-prem: $a" -Level WARN }
            if ($status -eq 'Passed') { Write-Log "$upn : address parity OK." -Level OK }
            $s.AddressCheck = $status; $s.AddressCheckAt = Get-IsoNow
            Add-UserHistory -UserState $s -Stage 'AddressCheck' -Result $status -Detail $detail
            Add-Result -Stage 'AddressCheck' -Upn $upn -Status $status -Detail $detail
        } catch {
            Write-ErrorDetail -Step 'Address check' -Item $upn -ErrorRecord $_
            Add-Result -Stage 'AddressCheck' -Upn $upn -Status 'Failed' -Detail $_.Exception.Message
        }
    }
    # replace the missing-address rows of every user checked in this run (users with none get cleared)
    $keep = @(Import-DataCsv -Name 'MissingAddresses' | Where-Object { $checked -notcontains $_.Upn })
    $all  = @($keep) + @($missingRows.ToArray())
    $path = Join-Path $Script:Paths.Data 'MissingAddresses.csv'
    if ($all.Count -gt 0) { $all | Export-Csv -LiteralPath $path -NoTypeInformation -Encoding UTF8 -WhatIf:$false -Confirm:$false }
    elseif (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Force -WhatIf:$false -Confirm:$false }
    Save-State
    Export-StageReport -StageKey 'AddressCheck'
    if ($missingRows.Count -gt 0) {
        Show-NextAction (@("{0} address(es) to add. MissingAddresses.csv written." -f $missingRows.Count) + (Show-CopyInstruction 'Exchange server') +
                         @('Run stage 8 there with -Apply, copy the folder back and run stage 7 again.'))
    } else {
        Show-NextAction @('No missing addresses. Next: stage 9 (start the Entra Connect scheduler + delta sync).')
    }
}

# =====================================================================================================
#  Stage 8 - Add missing addresses (OnPrem, changes only with -Apply)
# =====================================================================================================

function Invoke-AddressApply {
    <#
    .SYNOPSIS  Adds the addresses listed in MissingAddresses.csv with @{add=}; never removes, never changes the primary.
    #>
    Show-Section ('Stage 8 - Add missing addresses  [{0}]' -f $(if ($Apply) { 'APPLY MODE' } else { 'REPORT ONLY' }))
    $miss = @(Import-DataCsv -Name 'MissingAddresses')
    if ($miss.Count -eq 0) { Write-Log 'MissingAddresses.csv is empty or absent - nothing to add.' -Level OK; return }
    $Script:DC = Get-OnPremDomainController
    $onprem = @(Import-DataCsv -Name 'OnPremData')
    $touched = New-Object System.Collections.Generic.List[object]
    foreach ($grp in ($miss | Group-Object Upn)) {
        $upn = $grp.Name
        $o = Get-DataRow -Rows $onprem -Upn $upn
        $s = Get-UserState -Upn $upn
        if (-not $o) { Write-Log "$upn : no OnPremData row - skipped." -Level ERROR; Add-Result -Stage 'AddressApply' -Upn $upn -Status 'Failed' -Detail 'No OnPremData row'; continue }
        $ok = 0; $fail = 0; $skip = 0
        foreach ($row in $grp.Group) {
            $addr = [string]$row.Address
            $toAdd = if ($addr -imatch '^X500:') { 'X500:' + $addr.Substring(5) } else { 'smtp:' + (ConvertTo-PlainAddress $addr) }   # always secondary
            $cmd = "Set-RemoteMailbox -Identity $($o.AdObjectGuid) -EmailAddresses @{add='$toAdd'} -DomainController $($Script:DC)"
            if (-not (Test-ChangeAllowed -Target $upn -Action "Add proxy address $toAdd" -CommandText $cmd)) { $skip++; continue }
            try {
                $null = Set-RemoteMailbox -Identity $o.AdObjectGuid -EmailAddresses @{ add = $toAdd } -DomainController $Script:DC -Confirm:$false -ErrorAction Stop
                Write-Log "$upn : added $toAdd" -Level OK; $ok++
            } catch { Write-ErrorDetail -Step 'Add proxy address' -Item "$upn $toAdd" -ErrorRecord $_; $fail++ }
        }
        $status = if ($fail -gt 0) { 'Failed' } elseif ($skip -gt 0) { 'Skipped' } else { 'Done' }
        if ($s) { $s.AddressApply = $status; $s.AddressApplyAt = Get-IsoNow; Add-UserHistory -UserState $s -Stage 'AddressApply' -Result $status -Detail "added $ok, failed $fail, skipped $skip" }
        Add-Result -Stage 'AddressApply' -Upn $upn -Status $status -Detail "added $ok, failed $fail, skipped $skip"
        if ($ok -gt 0) { $touched.Add($o) }
    }
    if ($touched.Count -gt 0) { Export-OnPremPost -Rows $touched.ToArray() }
    Save-State
    Export-StageReport -StageKey 'AddressApply'
    Show-NextAction ((Show-CopyInstruction 'your machine') + @('Run stage 7 again to confirm parity, then stage 9.'))
}

# =====================================================================================================
#  Stage 10 - Validation (Cloud, read-only)
# =====================================================================================================

function Invoke-Validate {
    <#
    .SYNOPSIS  Checks recipient types, GUID match, archive status, tag; reports item counts. Read-only.
    #>
    Show-Section 'Stage 10 - Validation (read-only)'
    if (-not $Script:State.Global.SyncStartedAt) { Write-Log 'Stage 9 (sync started) not confirmed - run validation after the delta sync for meaningful results.' -Level WARN }
    $post = @(Import-DataCsv -Name 'OnPremPost')
    $cloud = @(Import-DataCsv -Name 'CloudData')
    Connect-CloudSession
    foreach ($s in @($Script:State.Users | Where-Object { $_.CutoverStatus -eq 'Done' })) {
        $upn = $s.Upn
        $p = Get-DataRow -Rows $post -Upn $upn
        $c = Get-DataRow -Rows $cloud -Upn $upn
        $bad = New-Object System.Collections.Generic.List[string]
        $info = New-Object System.Collections.Generic.List[string]
        try {
            $m = Get-EXOMailbox -Identity $upn -Properties RecipientTypeDetails,ExchangeGuid,ArchiveGuid,ArchiveStatus -ErrorAction Stop
            if ([string]$m.RecipientTypeDetails -ne 'UserMailbox') { $bad.Add("EXO type '$($m.RecipientTypeDetails)'") }
            if (-not $p) { $bad.Add('No OnPremPost row (run R on the Exchange server) - on-prem side NotAssessed') }
            else {
                if ([string]$p.RecipientTypeDetails -ne 'RemoteUserMailbox') { $bad.Add("On-prem type '$($p.RecipientTypeDetails)'") }
                if (-not (Test-SameGuid $p.ExchangeGuid $m.ExchangeGuid)) { $bad.Add("ExchangeGuid on-prem $($p.ExchangeGuid) <> EXO $($m.ExchangeGuid)") }
                if ($c -and (Test-GuidValue $c.CloudArchiveGuid)) {
                    if (-not (Test-SameGuid $p.ArchiveGuid $m.ArchiveGuid)) { $bad.Add("ArchiveGuid on-prem $($p.ArchiveGuid) <> EXO $($m.ArchiveGuid)") }
                    if ([string]$m.ArchiveStatus -ne 'Active') { $bad.Add("EXO ArchiveStatus '$($m.ArchiveStatus)'") }
                }
                if (-not [string]::IsNullOrEmpty([string]$p.ScopingTag)) { $bad.Add("Scoping tag still '$($p.ScopingTag)'") }
                $info.Add("on-prem state from $($p.CollectedAt)")
            }
            try {
                $ps = Get-EXOMailboxStatistics -Identity $upn -ErrorAction Stop
                $info.Add(("primary {0} items / {1}" -f $ps.ItemCount, $ps.TotalItemSize))
            } catch { $info.Add('primary stats NotAssessed'); Write-ErrorDetail -Step 'Primary statistics' -Item $upn -ErrorRecord $_ }
            if ($c -and (Test-GuidValue $c.CloudArchiveGuid)) {
                try {
                    $as = Get-EXOMailboxStatistics -Identity $upn -Archive -ErrorAction Stop
                    $info.Add(("main archive {0} items / {1} (auxiliary archives not included)" -f $as.ItemCount, $as.TotalItemSize))
                } catch { $info.Add('archive stats NotAssessed'); Write-ErrorDetail -Step 'Archive statistics' -Item $upn -ErrorRecord $_ }
            }
            $status = if ($bad.Count -eq 0) { 'Passed' } else { 'Failed' }
            $detail = (@($bad) + @($info)) -join '; '
            if ($status -eq 'Passed') { Write-Log "$upn : validation passed. $($info -join '; ')" -Level OK } else { Write-Log "$upn : validation FAILED - $detail" -Level ERROR }
        } catch {
            Write-ErrorDetail -Step 'Validation' -Item $upn -ErrorRecord $_
            $status = 'Failed'; $detail = $_.Exception.Message
        }
        $s.Validate = $status; $s.ValidateAt = Get-IsoNow
        Add-UserHistory -UserState $s -Stage 'Validate' -Result $status -Detail $detail
        Add-Result -Stage 'Validate' -Upn $upn -Status $status -Detail $detail
    }
    Save-State
    Export-StageReport -StageKey 'Validate'
    Show-NextAction @(
        'Item counts: compare with the final MigrationWiz statistics (this is the data-loss check).',
        'Manual tests per user: on-prem -> user, EXO -> user, external -> user, user -> internal/external,',
        'OWA shows mailbox AND archive.',
        'Then stage 11 (post-cutover) with -Apply.'
    )
}

# =====================================================================================================
#  Stage 11 - Post-cutover (Cloud, changes only with -Apply)
# =====================================================================================================

function Invoke-PostCutover {
    <#
    .SYNOPSIS  Re-enables retention processing (ElcProcessingDisabled=False) for validated users; prints the client checklist.
    #>
    Show-Section ('Stage 11 - Post-cutover  [{0}]' -f $(if ($Apply) { 'APPLY MODE' } else { 'REPORT ONLY' }))
    Connect-CloudSession
    foreach ($s in @($Script:State.Users | Where-Object { $_.CutoverStatus -eq 'Done' })) {
        $upn = $s.Upn
        if ($s.Validate -ne 'Passed') { Write-Log "$upn : validation not passed - skipped." -Level WARN; Add-Result -Stage 'PostCutover' -Upn $upn -Status 'Skipped' -Detail 'Validation not passed'; continue }
        try {
            $m = Get-EXOMailbox -Identity $upn -Properties ElcProcessingDisabled,RetentionPolicy -ErrorAction Stop
            $status = 'Done'
            if ([string]$m.ElcProcessingDisabled -ieq 'True') {
                $cmd = "Set-Mailbox -Identity $upn -ElcProcessingDisabled `$false"
                if (Test-ChangeAllowed -Target $upn -Action 'Re-enable retention processing' -CommandText $cmd) {
                    $null = Set-Mailbox -Identity $upn -ElcProcessingDisabled $false -Confirm:$false -ErrorAction Stop
                    $m = Get-EXOMailbox -Identity $upn -Properties ElcProcessingDisabled,RetentionPolicy -ErrorAction Stop
                    if ([string]$m.ElcProcessingDisabled -ieq 'True') { $status = 'Failed' }
                } else { $status = 'Skipped' }
            }
            $detail = "ElcProcessingDisabled={0}; RetentionPolicy={1}" -f $m.ElcProcessingDisabled, $m.RetentionPolicy
            Write-Log "$upn : $detail" -Level $(if ($status -eq 'Done') {'OK'} else {'WARN'})
        } catch {
            Write-ErrorDetail -Step 'Post-cutover' -Item $upn -ErrorRecord $_
            $status = 'Failed'; $detail = $_.Exception.Message
        }
        $s.PostCutover = $status; $s.PostCutoverAt = Get-IsoNow
        Add-UserHistory -UserState $s -Stage 'PostCutover' -Result $status -Detail $detail
        Add-Result -Stage 'PostCutover' -Upn $upn -Status $status -Detail $detail
    }
    Save-State
    Export-StageReport -StageKey 'PostCutover'
    Show-NextAction @(
        'Check RetentionPolicy above is the one the client wants (the on-prem policy does not follow).',
        'On each user PC, as the user (or remove it from the GPO if pushed by GPO):',
        '  reg delete "HKCU\Software\Microsoft\Office\16.0\Outlook\AutoDiscover" /v ExcludeExplicitO365Endpoint /f',
        'Recreate the Outlook profile and the mobile mail account.',
        'Do NOT purge the disconnected on-prem mailboxes. Do NOT delete the MigrationWiz items.',
        'Then stage 12 (report).'
    )
}

# =====================================================================================================
#  Stage 12 - Report, Stage 13 - Rollback info, H - Overview
# =====================================================================================================

function Invoke-Report {
    <#
    .SYNOPSIS  Writes a consolidated per-user status CSV and HTML. Read-only.
    #>
    Show-Section 'Stage 12 - Consolidated report'
    $cloud = @(Import-DataCsv -Name 'CloudData'); $onprem = @(Import-DataCsv -Name 'OnPremData'); $post = @(Import-DataCsv -Name 'OnPremPost')
    $rows = foreach ($s in $Script:State.Users) {
        $c = Get-DataRow -Rows $cloud -Upn $s.Upn; $o = Get-DataRow -Rows $onprem -Upn $s.Upn; $p = Get-DataRow -Rows $post -Upn $s.Upn
        [pscustomobject][ordered]@{
            Upn = $s.Upn; Alias = Get-Prop $o 'Alias'
            PrepA = $s.PrepCloud; PrepB = $s.PrepOnPrem; Cutover = $s.CutoverStatus; LastStep = $s.CutoverStep
            AddressCheck = $s.AddressCheck; AddressAdd = $s.AddressApply; Validation = $s.Validate; PostCutover = $s.PostCutover
            CloudExchangeGuid = Get-Prop $c 'CloudExchangeGuid'; OnPremStampedGuid = Get-Prop $p 'ExchangeGuid'
            CloudArchiveGuid = Get-Prop $c 'CloudArchiveGuid'; OnPremStampedArchive = Get-Prop $p 'ArchiveGuid'
            CutoverStarted = $s.CutoverStartedAt; CutoverDone = $s.CutoverDoneAt; LastError = $s.LastError
        }
    }
    $rows = @($rows)
    $ts = Get-Date -Format 'yyyyMMdd-HHmmss'
    $csv = Join-Path $Script:Paths.Reports "Summary-$ts.csv"
    $htm = Join-Path $Script:Paths.Reports "Summary-$ts.html"
    $rows | Export-Csv -LiteralPath $csv -NoTypeInformation -Encoding UTF8 -WhatIf:$false -Confirm:$false
    $g = $Script:State.Global
    $head = '<style>body{font-family:Segoe UI,Arial,sans-serif;font-size:12px;color:#222}table{border-collapse:collapse}th,td{border:1px solid #ccc;padding:4px 6px}th{background:#003659;color:#fff}</style>'
    $pre  = "<h2>Mailbox cutover - batch $Batch</h2><p>Generated $(Get-Date -Format 'dd/MM/yyyy HH:mm') on $env:COMPUTERNAME.<br/>" +
            "First pass confirmed: $($g.FirstPassConfirmedAt)<br/>Sync stopped: $($g.SyncStoppedAt)<br/>Final passes confirmed: $($g.FinalPassConfirmedAt)<br/>Sync started: $($g.SyncStartedAt)</p>"
    ($rows | Select-Object Upn,Alias,PrepA,PrepB,Cutover,LastStep,AddressCheck,AddressAdd,Validation,PostCutover,CutoverDone,LastError |
        ConvertTo-Html -Head $head -PreContent $pre -Title "Cutover $Batch") | Set-Content -LiteralPath $htm -Encoding UTF8 -WhatIf:$false -Confirm:$false
    $rows | Format-Table Upn,PrepA,PrepB,Cutover,LastStep,AddressCheck,Validation,PostCutover -AutoSize | Out-Host
    Write-Log "Report written: $csv"
    Write-Log "Report written: $htm"
    Add-Result -Stage 'Report' -Upn '-' -Status 'Done' -Detail $htm
}

function Invoke-RollbackInfo {
    <#
    .SYNOPSIS  Prints and saves each user's rollback data and the validated runbook commands. Never rolls back.
    #>
    Show-Section 'Stage 13 - Rollback information (read-only - nothing is executed)'
    $onprem = @(Import-DataCsv -Name 'OnPremData'); $disc = @(Import-DataCsv -Name 'Disconnected')
    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add("ROLLBACK DATA - batch $Batch - $(Get-Date -Format 'yyyy-MM-dd HH:mm') - manual procedure, severe failure only")
    $lines.Add('R1 stop user access to EXO; R2 export mail delivered to EXO since cutover; R3 re-apply the tag FIRST;')
    $lines.Add('R4 disable RemoteMailbox + reconnect primary; R5 restore addresses from the backup XML; R6 start sync + delta;')
    $lines.Add('R7 do not delete the EXO mailbox. NOTE: the validated runbook reconnects the PRIMARY only - the archive')
    $lines.Add('   (separate database) is not covered; verify the archive state before declaring rollback complete.')
    foreach ($o in $onprem) {
        $d = @($disc | Where-Object { $_.Upn -ieq $o.Upn })
        $lines.Add('')
        $lines.Add(('---- {0} ({1}) ----' -f $o.Upn, $o.Alias))
        $lines.Add(('On-prem ExchangeGuid {0}  Database {1}' -f $o.OnPremExchangeGuid, $o.Database))
        $lines.Add(('On-prem ArchiveGuid  {0}  ArchiveDatabase {1}' -f $o.OnPremArchiveGuid, $o.ArchiveDatabase))
        $lines.Add(('Disconnected found   {0}' -f $(if ($d.Count) { ($d | ForEach-Object { "$($_.MailboxGuid)@$($_.Database)" }) -join ', ' } else { 'not recorded' })))
        $lines.Add(('Backup XML           {0}' -f $o.BackupFile))
        $lines.Add(('Set-RemoteMailbox {0} -{1} "{2}" -DomainController <DC>' -f $o.AdObjectGuid, $Config.ScopingAttribute, $Config.ScopingValue))
        $lines.Add(('Disable-RemoteMailbox {0} -Confirm:$false -DomainController <DC>' -f $o.AdObjectGuid))
        $lines.Add(('Connect-Mailbox -Identity {0} -Database "{1}" -User {2} -DomainController <DC>' -f $o.OnPremExchangeGuid, $o.Database, $o.AdObjectGuid))
    }
    $lines | ForEach-Object { Write-Host $_ }
    $file = Join-Path $Script:Paths.Reports ("RollbackInfo-{0}.txt" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
    $lines | Set-Content -LiteralPath $file -Encoding UTF8 -WhatIf:$false -Confirm:$false
    Write-Log "Rollback information written: $file"
    Add-Result -Stage 'RollbackInfo' -Upn '-' -Status 'Done' -Detail $file
}

function Show-Overview {
    <#
    .SYNOPSIS  Prints the whole process: what to run, where and when.
    #>
    Show-Section 'Process overview'
    $t = @(
        'WORKING FOLDER (same path on both machines):',
        "  $($Script:Paths.Root)",
        '  Input\Users.csv  (one column: Upn)   Data\<Batch>  Backup\<Batch>  Reports\<Batch>  Logs',
        '',
        'BEFORE THE WINDOW (any day):',
        '  1  [Your machine]     Prep A                        -> copy folder to Exchange server',
        '  2  [Exchange server]  Prep B (hold + tag gates, backup)',
        '  3  [Exchange server]  Guide: MigrationWiz first Full pass, wait Completed, CONFIRM',
        '',
        'CUTOVER WINDOW (keep it short; sync is stopped for the whole tenant):',
        '  4  [Exchange server]  Guide: stop Entra Connect scheduler (you run it on the server), CONFIRM',
        '  5  [Exchange server]  Guide: final Full passes + Retry Errors, CONFIRM',
        '  6  [Exchange server]  Cutover with -Apply, one user at a time   -> copy folder to your machine',
        '  7  [Your machine]     Address check',
        '  8  [Exchange server]  Only if stage 7 found missing addresses (-Apply) -> copy back, re-run 7',
        '  9  [Either]           Guide: start scheduler + delta sync (you run it on the server), CONFIRM',
        '',
        'AFTER THE WINDOW:',
        ' 10  [Your machine]     Validation + manual mail-flow tests',
        ' 11  [Your machine]     Post-cutover with -Apply + client checklist (registry, Outlook profile)',
        ' 12  [Either]           Report',
        '',
        'RULES: without -Apply nothing changes. A failed cutover user keeps the tag and can be resumed',
        '       (stage 6 again). Never start sync (stage 9) while a user is half-converted.',
        '       Always copy the WHOLE folder, from the machine that ran the last stage.'
    )
    $t | ForEach-Object { Write-Host $_ }
}

# =====================================================================================================
#  Menu
# =====================================================================================================

function Show-StatusTable {
    <#
    .SYNOPSIS  Prints the batch status and the per-user table above the menu.
    #>
    $g = $Script:State.Global
    Write-Host ''
    Write-Host ("Batch: {0}   Machine: {1}   Context: {2}   Mode: {3}" -f $Batch, $env:COMPUTERNAME, $Script:Context, $(if ($Apply) { 'APPLY' } else { 'REPORT ONLY' })) -ForegroundColor White
    Write-Host ("State revision {0}, last saved {1} by {2}. Before running here, make sure this is the newest copy of the folder." -f $Script:State.Revision, $Script:State.Updated, $Script:State.UpdatedBy) -ForegroundColor DarkGray
    if (Test-SyncStopped) { Write-Host ("*** ENTRA CONNECT SYNC IS STOPPED (since {0}) - finish and do stage 9 ***" -f $g.SyncStoppedAt) -ForegroundColor Red }
    Write-Host ''
    Write-Host ('{0,-40} {1,-8} {2,-8} {3,-11} {4,-10} {5,-8} {6,-8} {7,-8}' -f 'User','PrepA','PrepB','Cutover','LastStep','Address','Valid','Post') -ForegroundColor DarkCyan
    foreach ($s in $Script:State.Users) {
        $color = if ($s.CutoverStatus -eq 'Failed' -or $s.CutoverStatus -eq 'InProgress') { 'Yellow' } elseif ($s.CutoverStatus -eq 'Done') { 'Green' } else { 'Gray' }
        Write-Host ('{0,-40} {1,-8} {2,-8} {3,-11} {4,-10} {5,-8} {6,-8} {7,-8}' -f $s.Upn, $s.PrepCloud, $s.PrepOnPrem, $s.CutoverStatus, $s.CutoverStep, $s.AddressCheck, $s.Validate, $s.PostCutover) -ForegroundColor $color
    }
}

function Invoke-StageByKey {
    <#
    .SYNOPSIS  Dispatches one stage with its own try/catch.
    .PARAMETER Key  Stage key.
    #>
    param([string]$Key)
    $info = $Stages | Where-Object { $_.Key -eq $Key } | Select-Object -First 1
    if (-not (Test-StageAllowed $info)) { $Script:PrereqFailure = $true; Add-Result -Stage $Key -Upn '-' -Status 'Failed' -Detail 'Wrong machine/context'; return }
    Write-Log ("=== Stage {0} {1} started ===" -f $info.Menu, $Key)
    try {
        switch ($Key) {
            'PrepCloud'      { Invoke-PrepCloud }
            'PrepOnPrem'     { Invoke-PrepOnPrem }
            'GuideFirstPass' { Invoke-GuideFirstPass }
            'GuideStopSync'  { Invoke-GuideStopSync }
            'GuideFinalPass' { Invoke-GuideFinalPass }
            'Cutover'        { Invoke-Cutover }
            'AddressCheck'   { Invoke-AddressCheck }
            'AddressApply'   { Invoke-AddressApply }
            'GuideStartSync' { Invoke-GuideStartSync }
            'Validate'       { Invoke-Validate }
            'PostCutover'    { Invoke-PostCutover }
            'Report'         { Invoke-Report }
            'RollbackInfo'   { Invoke-RollbackInfo }
            'RefreshOnPrem'  { Invoke-RefreshOnPrem }
            'Overview'       { Show-Overview }
        }
    } catch {
        Write-ErrorDetail -Step "Stage $Key" -Item $Batch -ErrorRecord $_
        Add-Result -Stage $Key -Upn '-' -Status 'Failed' -Detail $_.Exception.Message
        try { Save-State } catch { Write-ErrorDetail -Step 'Save-State after failure' -Item $Batch -ErrorRecord $_ }
    }
    Write-Log ("=== Stage {0} {1} finished ===" -f $info.Menu, $Key)
}

function Show-Menu {
    <#
    .SYNOPSIS  Interactive menu loop.
    #>
    while ($true) {
        Show-StatusTable
        Write-Host ''
        foreach ($st in $Stages) {
            $tag = switch ($st.Where) { 'Cloud' { '[Your machine]' } 'OnPrem' { '[Exchange server]' } default { '[Any]' } }
            $color = if ($st.Where -eq 'Any' -or $st.Where -eq $Script:Context) { 'White' } else { 'DarkGray' }
            Write-Host ('  {0,2}  {1,-62} {2}' -f $st.Menu, $st.Title, $tag) -ForegroundColor $color
        }
        Write-Host '   Q  Quit'
        $choice = (Read-Host 'Choose').Trim()
        if ($choice -ieq 'Q') { break }
        $st = $Stages | Where-Object { $_.Menu -ieq $choice } | Select-Object -First 1
        if (-not $st) { Write-Host 'Unknown choice.' -ForegroundColor Yellow; continue }
        Invoke-StageByKey -Key $st.Key
        [void](Read-Host 'Press Enter to return to the menu')
    }
}

# =====================================================================================================
#  Main
# =====================================================================================================

try {
    $Script:Paths.Root    = Join-Path $OutputPath $ScriptName
    $Script:Paths.Logs    = Join-Path $Script:Paths.Root 'Logs'
    Initialize-Folder -Path $Script:Paths.Root
    Initialize-Folder -Path $Script:Paths.Logs
    $Script:LogFile = Join-Path $Script:Paths.Logs ('{0}-{1}.log' -f $ScriptName, (Get-Date -Format 'yyyyMMdd-HHmmss'))
    foreach ($l in $Script:PendingLog) { Add-Content -LiteralPath $Script:LogFile -Value $l -Encoding UTF8 -WhatIf:$false -Confirm:$false }
    $Script:PendingLog.Clear()

    Write-Log ("{0} v{1} started {2}" -f $ScriptName, $ScriptVersion, $Script:StartTime.ToString('o'))
    Write-Log ("User {0}\{1} on {2}; PowerShell {3} ({4})" -f $env:USERDOMAIN, $env:USERNAME, $env:COMPUTERNAME, $PSVersionTable.PSVersion, $PSVersionTable.PSEdition)
    Write-Log ("Parameters: Batch='{0}' OutputPath='{1}' InputCsv='{2}' Stage={3} Apply={4} WhatIf={5} DomainController='{6}' DisconnectWaitMinutes={7} FinalPassMaxAgeMinutes={8} PrepMaxAgeHours={9}" -f `
        $Batch, $OutputPath, $InputCsv, $Stage, [bool]$Apply, [bool]$WhatIfPreference, $DomainController, $DisconnectWaitMinutes, $FinalPassMaxAgeMinutes, $PrepMaxAgeHours)
    Write-Log ("Log file: {0}" -f $Script:LogFile) -Level OK

    $Script:Context = Get-RunContext
    Write-Log ("Detected context: {0}" -f $Script:Context)
    if ($Script:Context -eq 'None') {
        Write-Log 'Neither the Exchange Management Shell cmdlets nor the ExchangeOnlineManagement module were found.' -Level WARN
        Write-Log 'On the Exchange server: run this from the Exchange Management Shell. On your machine: install ExchangeOnlineManagement.' -Level WARN
    }

    if (-not $Batch) {
        if (-not $Script:IsInteractive) { throw 'No -Batch given in a non-interactive session.' }
        do { $Batch = (Read-Host 'Batch name (letters, digits, - or _), e.g. Wave1').Trim() } while ($Batch -notmatch '^[A-Za-z0-9_-]+$')
        Write-Log "Batch chosen interactively: $Batch"
    }

    $Script:Paths.Input    = Join-Path $Script:Paths.Root 'Input'
    $Script:Paths.InputCsv = if ($InputCsv) { $InputCsv } else { Join-Path $Script:Paths.Input 'Users.csv' }
    $Script:Paths.Data     = Join-Path (Join-Path $Script:Paths.Root 'Data') $Batch
    $Script:Paths.Backup   = Join-Path (Join-Path $Script:Paths.Root 'Backup') $Batch
    $Script:Paths.Reports  = Join-Path (Join-Path $Script:Paths.Root 'Reports') $Batch
    foreach ($k in 'Input','Data','Backup','Reports') { Initialize-Folder -Path $Script:Paths[$k] }

    if ($Stage -ne 'Overview') {
        $upns = Get-InputUpns
        $Script:InputUpns = $upns
        Import-State -Upns $upns
        Save-State
    } else {
        Import-State -Upns @()
    }

    if ($Stage -eq 'Menu') {
        if (-not $Script:IsInteractive) { throw 'The menu needs an interactive session. Use -Stage for a single stage.' }
        Show-Menu
    } else {
        Invoke-StageByKey -Key $Stage
    }

    $Script:ExitCode = if ($Script:PrereqFailure -and $Script:Totals.Succeeded -eq 0) { 2 } elseif ($Script:Totals.Failed -gt 0) { 1 } else { 0 }
}
catch {
    if ($Script:LogFile) { Write-ErrorDetail -Step 'Fatal' -Item $ScriptName -ErrorRecord $_ }
    else { Write-Host ("FATAL before the log was opened: {0}" -f $_.Exception.Message) -ForegroundColor Red }
    $Script:ExitCode = 2
}
finally {
    if ($Script:LogFile) {
        $dur = (Get-Date) - $Script:StartTime
        Write-Log ("Totals: succeeded {0}, failed {1}, not assessed/skipped {2}" -f $Script:Totals.Succeeded, $Script:Totals.Failed, $Script:Totals.NotAssessed)
        Write-Log ("Finished {0}; duration {1:hh\:mm\:ss}; exit code {2}" -f (Get-Date).ToString('o'), $dur, $Script:ExitCode)
        Write-Log ("Log file: {0}" -f $Script:LogFile) -Level OK
        if ($Script:State -and (Test-SyncStopped)) { Write-Log 'REMINDER: Entra Connect sync is still STOPPED for this batch (stage 9 not confirmed).' -Level ERROR }
    }
}
exit $Script:ExitCode
